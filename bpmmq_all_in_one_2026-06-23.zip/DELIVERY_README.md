# Что лежит в этом комплекте

Комплект нужен для передачи проекта `bpmmq`, настройки MinIO audit webhook в
Logstash и, при необходимости, настройки Kibana-доступов для MinIO/S3 и BPMMQ.

## Главное правило по окружениям

Основной вариант сейчас — только `prod`, но `prod` явно оставлен в названиях
индексов, data views и ролей:

- MinIO audit: `app-minio-audit-prod*`;
- BPMMQ/RabbitMQ/HAProxy: `app-bpmmq-prod-*`;
- роли: `user_s3stor_prod`, `user_bpmmq_prod`;
- AD/SSO-группы: `sbl_kub_kibana_s3stor_prod`, `sbl_kub_kibana_bpmmq_prod`.

Если позже понадобятся `dev`, `ift` или `psi`, в комплекте есть отдельные
multi-env файлы. Основной и multi-env варианты не применять одновременно.

## Основные документы

- `SETUP.md` — основная инструкция по RabbitMQ + HAProxy.
- `AUDIT_LOGGING_CONFLUENCE.md` — аудит/логи для BPMMQ.
- `MINIO_AUDIT_LOGGING_CONFLUENCE.md` — аудит/логи для MinIO.
- `RABBITMQ_LOGSTASH_INTEGRATION.md` — передача логов RabbitMQ/HAProxy в ELK.
- `MINIO_LOGSTASH_PROD_INSTRUCTION.md` — пошаговая prod-инструкция MinIO audit webhook -> Logstash.
- `MINIO_LOGSTASH_INTEGRATION.md` — расширенное пояснение MinIO -> Logstash.
- `elk-logstash-runbook.md` — общая карта: Logstash, Terraform, роли, проверки и откат.
- `ZABBIX_MONITORING_TZ.md` — простое ТЗ на мониторинг Zabbix.

## Архив для владельцев Logstash

Отдельный готовый архив:

```text
logstash-minio-prod-package.zip
```

В общем all-in-one архиве этот же файл дополнительно лежит как:

```text
logstash/logstash-minio-prod-package.zip
```

Внутри основного Logstash-пакета:

- `MINIO_LOGSTASH_PROD_INSTRUCTION.md`;
- `MINIO_LOGSTASH_INTEGRATION.md`;
- `elk-logstash-runbook.md`;
- `logstash-minio-audit.conf`;
- `logstash-minio-audit.prod.conf`;
- `logstash-release-values.prepared.yaml`;
- `logstash-minio-prod.patch`;
- `check-logstash-values.sh`.

Для будущего разделения по окружениям там же лежат:

- `logstash-minio-audit.multi-env.conf`;
- `logstash-release-values.multi-env.prepared.yaml`;
- `logstash-minio-multi-env.patch`.

Архив распаковывать вне `fluxcd`. В GitOps-репозиторий коммитить только
изменение `infra/kub-sbl-mon/logstash/logstash-release-values.yaml`; zip-файлы
и временные распакованные файлы в `fluxcd` не добавлять.

## Как применить Logstash patch

В свежем clone `fluxcd`:

```bash
mkdir -p /tmp/logstash-minio-prod-package
unzip -o /path/to/logstash-minio-prod-package.zip -d /tmp/logstash-minio-prod-package

cd ~/devops/devops-repos/fluxcd
git status --short

git apply --check /tmp/logstash-minio-prod-package/logstash-minio-prod.patch
git apply /tmp/logstash-minio-prod-package/logstash-minio-prod.patch

git diff --check -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml
git diff -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml
```

В diff должен измениться только файл:

```text
infra/kub-sbl-mon/logstash/logstash-release-values.yaml
```

Если `git apply --check` падает, patch не применять через силу. Тогда сверить
живой файл с `elk/logstash-release-values.prepared.yaml` и перенести изменения
вручную по инструкции `MINIO_LOGSTASH_PROD_INSTRUCTION.md`.

## Что меняет prod Logstash patch

- добавляет отдельный HTTP-вход Logstash `8081` для MinIO audit webhook;
- добавляет pipeline `minio-audit.conf`;
- пишет MinIO audit-события в `app-minio-audit-prod`;
- оставляет два URL:
  - `https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod`;
  - `https://logstash.sbl-mon.kub.rdleas.ru/minio-audit`;
- исключает тег `minio-audit` из fallback-индекса `logstash`;
- не трогает Beats-вход `5044`;
- не трогает общий HTTP-вход `8080`;
- не создаёт новые Kubernetes-секреты.

## Важное про BPMMQ и порт 5044

Для RabbitMQ/HAProxy Filebeat отправляет события на:

```text
logstash.sbl-mon.kub.rdleas.ru:5044
```

В Logstash для этого недостаточно строк `containerPort: 5044` и
`service port: 5044`, но если Filebeat уже работает через этот порт, новый
`beats { port => 5044 }` добавлять не надо.

Причина: Logstash читает все `.conf` файлы из
`/usr/share/logstash/pipeline` как один pipeline. Beats input может приходить из
другого файла, например дефолтного `logstash.conf` внутри образа, а не из
`pipeline.conf`, который видно в HelmRelease.

Проверить live-конфиг:

```bash
kubectl -n logstash get pods
kubectl -n logstash exec <logstash-pod> -- sh -c 'ls -l /usr/share/logstash/pipeline && grep -R "beats" -n /usr/share/logstash/pipeline || true'
```

Если `filebeat test output` на RabbitMQ/HAProxy-сервере проходит до
`logstash.sbl-mon.kub.rdleas.ru:5044`, input `5044` не менять.

Существующий матчинг по `[app]` менять не нужно. BPMMQ-события маршрутизируются
по тегам из Filebeat: `rabbitmq-bpmmq`, `haproxy-bpmmq`, `keepalived-bpmmq`.
Готовые output-ветки лежат в `elk/logstash-bpmmq-routing.conf`; вставлять их
перед финальным fallback в индекс `logstash`.

## Главная проверка перед prod

На Ubuntu:

```bash
cd ~/devops/devops-repos/fluxcd

git diff --check -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml
kubectl kustomize infra/kub-sbl-mon/logstash > /tmp/logstash-rendered.yaml

bash /path/to/bpmmq/tools/check-logstash-values.sh \
  --values-file ./infra/kub-sbl-mon/logstash/logstash-release-values.yaml \
  --logstash-image docker.elastic.co/logstash/logstash:8.19.0
```

Ожидаемый результат Logstash-проверки:

```text
Logstash config validation passed.
```

## Что передавать владельцам Elastic/Kibana

Для Kibana spaces, data views и доступов добавлены готовые файлы.

Основной prod-вариант:

```text
terraform/elasticstack/s3stor.tf
terraform/elasticstack/bpmmq.tf
terraform-elasticstack-s3stor-bpmmq.patch
fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.snippet.yaml
fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.snippet.yaml
```

Multi-env вариант на будущее:

```text
terraform/elasticstack/s3stor.multi-env.tf
terraform/elasticstack/bpmmq.multi-env.tf
terraform-elasticstack-s3stor-bpmmq.multi-env.patch
fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.multi-env.snippet.yaml
fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.multi-env.snippet.yaml
```

Terraform-файлы копируются или применяются patch'ем в:

```text
~/devops/devops-repos/terraform/elasticstack/
```

Terraform запускать именно из этого каталога, не из `bpmmq` и не из `fluxcd`.
Там лежит `provider.tf`, который задаёт backend/state и адреса
Elasticsearch/Kibana.

Для основного prod-варианта:

```bash
cd ~/devops/devops-repos/terraform/elasticstack

git status --short
git apply --check /path/to/bpmmq/terraform-elasticstack-s3stor-bpmmq.patch
git apply /path/to/bpmmq/terraform-elasticstack-s3stor-bpmmq.patch

terraform init
terraform fmt -check s3stor.tf bpmmq.tf
terraform plan
```

Terraform нельзя применить "только к одному файлу": он читает всю директорию.
Перед применением обязательно смотреть plan. По этой задаче в plan должны быть
только новые `create` для `s3stor`, `bpmmq` и их prod data views. Любые `update`,
`delete` или `replace` по чужим объектам — стоп.

Если `terraform init` или `terraform plan` падают на backend/provider/DNS/auth,
это не проблема файлов `s3stor.tf`/`bpmmq.tf`: значит запуск идёт не из штатного
окружения или не переданы credentials. В таком случае использовать ваш обычный
Terraform/CI-процесс для репозитория `terraform/elasticstack`.

По текущему `terraform/elasticstack/.gitlab-ci.yml` обычный CI-процесс подключает
шаблон `DevOps/cicd/terraform/elasticstack.yaml`. В локальной копии этого
шаблона видно, что job `terraform_apply` на ветках `main/master` берёт секреты
из Vault и выполняет:

```bash
terraform init
terraform apply --auto-approve
```

Отдельного `terraform plan` job в этом шаблоне не видно. Поэтому merge в
`main/master` может сразу применить Terraform. Перед merge желательно получить
plan вручную в штатном окружении или согласовать изменение с владельцем
ELK/Terraform.

Осторожный ручной запуск, если нужно просто понять или проверить результат:

```bash
cd ~/devops/devops-repos/terraform/elasticstack

export PGUSER='<из Vault elasticstack/db-backend/PGUSER>'
export PGPASSWORD='<из Vault elasticstack/db-backend/PGPASSWORD>'
export KIBANA_USERNAME='elastic'
export KIBANA_PASSWORD='<из Vault elastic/elasticsearch/password>'
export ELASTICSEARCH_USERNAME='elastic'
export ELASTICSEARCH_PASSWORD='<из Vault elastic/elasticsearch/password>'

git status --short
terraform init
terraform fmt -check s3stor.tf bpmmq.tf
terraform plan -out=/tmp/elasticstack-s3stor-bpmmq.tfplan
terraform show -no-color /tmp/elasticstack-s3stor-bpmmq.tfplan | less
```

Вручную применять только после проверки plan:

```bash
terraform apply /tmp/elasticstack-s3stor-bpmmq.tfplan
rm -f /tmp/elasticstack-s3stor-bpmmq.tfplan
```

Не запускать ручной `terraform apply --auto-approve`, `terraform destroy` или
`terraform -target` для этой задачи. Секреты не записывать в файлы репозитория.

Точка подключения для ручного запуска:

- лучший вариант — GitLab runner `sbl-mon`, то есть штатный CI;
- с админской машины можно запускать только если она видит PostgreSQL backend
  `10.77.189.208:5555` и Elasticsearch/Kibana endpoints из `provider.tf`;
- если с админской машины есть только `kubectl`, Elasticsearch/Kibana можно
  временно пробросить через `kubectl port-forward`, но backend PostgreSQL всё
  равно должен быть доступен напрямую или через согласованный tunnel.

Проверки доступности:

```bash
getent hosts elasticsearch-es-http.elastic-stack.svc.cluster.local
getent hosts kibana-kb-http.elastic-stack.svc.cluster.local
nc -vz elasticsearch-es-http.elastic-stack.svc.cluster.local 9200
nc -vz kibana-kb-http.elastic-stack.svc.cluster.local 5601
nc -vz 10.77.189.208 5555
```

Вариант с `kubectl port-forward` для Elasticsearch/Kibana:

```bash
kubectl -n elastic-stack port-forward svc/elasticsearch-es-http 9200:9200
kubectl -n elastic-stack port-forward svc/kibana-kb-http 5601:5601
```

Так как `provider.tf` использует service DNS, на время проверки можно добавить в
`/etc/hosts`:

```bash
127.0.0.1 elasticsearch-es-http.elastic-stack.svc.cluster.local kibana-kb-http.elastic-stack.svc.cluster.local
```

Для PostgreSQL backend через bastion возможен tunnel:

```bash
ssh -L 127.0.0.1:5555:10.77.189.208:5555 <user>@<bastion>
terraform init -reconfigure \
  -backend-config='conn_str=postgres://127.0.0.1:5555/terraform_elasticstack?sslmode=disable'
```

Этот tunnel должен вести именно в штатный backend state. Если есть сомнения,
ручной запуск не делать и использовать CI.

Flux-сниппеты вставляются в существующие файлы:

```text
~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/elastic/elasticsearch-roles.yaml
~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/elastic/oicdproxy-release.yaml
```

Репозиторий с ролями Elasticsearch/Kibana для первичной доставки логов можно не
менять. Он нужен только если КБ или владелец ELK просит отдельные права
просмотра через Kibana.

## BPMMQ инструкции

BPMMQ/RabbitMQ + HAProxy инструкции уже готовы:

- `RABBITMQ_LOGSTASH_INTEGRATION.md`;
- `elk/filebeat-bpmmq.yml`;
- `elk/filebeat-bpmmq.docker.yml`;
- `elk/logstash-bpmmq-routing.conf`;
- `elk/docker-compose.filebeat.yml`.

В Filebeat-конфигах по умолчанию стоит `env: prod`. Если отдельные `dev`, `ift`
или `psi` не нужны, менять это не требуется.

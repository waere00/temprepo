#!/usr/bin/env bash
set -euo pipefail

values_file=""
out_dir=""
logstash_image="docker.rdleas.ru/elastic/logstash:8.19.0"
skip_docker=0

usage() {
  cat <<'USAGE'
Usage:
  check-logstash-values.sh --values-file PATH [--out-dir DIR] [--logstash-image IMAGE] [--skip-docker]

Examples:
  ./tools/check-logstash-values.sh --values-file ./infra/kub-sbl-mon/logstash/logstash-release-values.yaml

  ./tools/check-logstash-values.sh \
    --values-file ./infra/kub-sbl-mon/logstash/logstash-release-values.yaml \
    --logstash-image docker.elastic.co/logstash/logstash:8.19.0
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --values-file)
      values_file="${2:-}"
      shift 2
      ;;
    --out-dir)
      out_dir="${2:-}"
      shift 2
      ;;
    --logstash-image)
      logstash_image="${2:-}"
      shift 2
      ;;
    --skip-docker)
      skip_docker=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ -z "$values_file" ]]; then
  echo "--values-file is required" >&2
  usage >&2
  exit 2
fi

if [[ ! -f "$values_file" ]]; then
  echo "Values file not found: $values_file" >&2
  exit 1
fi

if [[ -z "$out_dir" ]]; then
  out_dir="$(mktemp -d)"
else
  rm -rf "$out_dir"
  mkdir -p "$out_dir"
fi

python3 - "$values_file" "$out_dir" <<'PY'
import pathlib
import re
import sys

values_path = pathlib.Path(sys.argv[1])
out_dir = pathlib.Path(sys.argv[2])
lines = values_path.read_text(encoding="utf-8").splitlines()

pipeline_files = {}
pattern = re.compile(r"^(\s*)([A-Za-z0-9_.-]+\.conf):\s*\|\s*$")

i = 0
while i < len(lines):
    match = pattern.match(lines[i])
    if not match:
        i += 1
        continue

    key_indent = len(match.group(1))
    file_name = match.group(2)
    content_indent = key_indent + 2
    content = []
    j = i + 1

    while j < len(lines):
        next_line = lines[j]
        if next_line.strip():
            next_indent = len(next_line) - len(next_line.lstrip(" "))
            if next_indent <= key_indent:
                break

        if len(next_line) >= content_indent:
            content.append(next_line[content_indent:])
        else:
            content.append("")
        j += 1

    pipeline_files[file_name] = "\n".join(content)
    i = j

if not pipeline_files:
    raise SystemExit(f"No '*.conf: |' blocks found in {values_path}")

out_dir.mkdir(parents=True, exist_ok=True)
for file_name, content in pipeline_files.items():
    (out_dir / file_name).write_text(content, encoding="utf-8")

print(f"Extracted Logstash pipeline files to: {out_dir}")
for file_name in pipeline_files:
    print(f" - {file_name}")
PY

if [[ "$skip_docker" -eq 1 ]]; then
  echo "Docker validation skipped."
  exit 0
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker was not found. Re-run with --skip-docker or install/start Docker." >&2
  exit 1
fi

echo "Running Logstash config validation with image: $logstash_image"

docker run --rm \
  -e username=precheck \
  -e password=precheck \
  -v "$out_dir:/usr/share/logstash/pipeline:ro" \
  "$logstash_image" \
  logstash --path.config /usr/share/logstash/pipeline --config.test_and_exit

echo "Logstash config validation passed."

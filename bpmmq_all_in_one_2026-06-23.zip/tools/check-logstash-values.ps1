param(
  [Parameter(Mandatory = $true)]
  [string]$ValuesFile,

  [string]$OutDir = "",

  [string]$LogstashImage = "docker.rdleas.ru/elastic/logstash:8.19.0",

  [switch]$SkipDocker
)

$ErrorActionPreference = "Stop"

$resolvedValuesFile = (Resolve-Path -LiteralPath $ValuesFile).Path

if ([string]::IsNullOrWhiteSpace($OutDir)) {
  $baseName = [IO.Path]::GetFileNameWithoutExtension($resolvedValuesFile)
  $OutDir = Join-Path ([IO.Path]::GetTempPath()) "logstash-pipeline-$baseName"
}

if (Test-Path -LiteralPath $OutDir) {
  Remove-Item -LiteralPath $OutDir -Recurse -Force
}
New-Item -ItemType Directory -Path $OutDir | Out-Null

$lines = Get-Content -LiteralPath $resolvedValuesFile
$pipelineFiles = [ordered]@{}

for ($i = 0; $i -lt $lines.Count; $i++) {
  $line = $lines[$i]

  if ($line -match '^(\s*)([A-Za-z0-9_.-]+\.conf):\s*\|\s*$') {
    $keyIndent = $matches[1].Length
    $fileName = $matches[2]
    $contentIndent = $keyIndent + 2
    $content = New-Object System.Collections.Generic.List[string]
    $j = $i + 1

    while ($j -lt $lines.Count) {
      $next = $lines[$j]

      if ($next.Trim().Length -gt 0) {
        $nextIndent = ($next -replace '^(\s*).*$', '$1').Length
        if ($nextIndent -le $keyIndent) {
          break
        }
      }

      if ($next.Length -ge $contentIndent) {
        $content.Add($next.Substring($contentIndent))
      } else {
        $content.Add("")
      }

      $j++
    }

    $pipelineFiles[$fileName] = ($content -join [Environment]::NewLine)
    $i = $j - 1
  }
}

if ($pipelineFiles.Count -eq 0) {
  throw "No '*.conf: |' blocks found in $resolvedValuesFile"
}

foreach ($entry in $pipelineFiles.GetEnumerator()) {
  $target = Join-Path $OutDir $entry.Key
  Set-Content -LiteralPath $target -Value $entry.Value -NoNewline
}

Write-Host "Extracted Logstash pipeline files to: $OutDir"
$pipelineFiles.Keys | ForEach-Object { Write-Host " - $_" }

if ($SkipDocker) {
  Write-Host "Docker validation skipped."
  exit 0
}

$docker = Get-Command docker -ErrorAction SilentlyContinue
if (-not $docker) {
  throw "Docker was not found. Re-run with -SkipDocker or install/start Docker."
}

$resolvedOutDir = (Resolve-Path -LiteralPath $OutDir).Path

Write-Host "Running Logstash config validation with image: $LogstashImage"

docker run --rm `
  -e username=precheck `
  -e password=precheck `
  -v "${resolvedOutDir}:/usr/share/logstash/pipeline:ro" `
  $LogstashImage `
  logstash --path.config /usr/share/logstash/pipeline --config.test_and_exit

if ($LASTEXITCODE -ne 0) {
  throw "Logstash config validation failed."
}

Write-Host "Logstash config validation passed."

# RabbitMQ 4.2.5 Cluster + HAProxy + Keepalived

Ubuntu 24.04 LTS, Erlang 26.2+ / 27.x, HAProxy 2.8 из репозитория.

## Архитектура

```
Клиенты → bpmmq.rdleas.ru (VIP / Keepalived)
              ├── dp-bpmmqbal01 (HAProxy preferred MASTER, priority 101)
              └── pp-bpmmqbal02 (HAProxy BACKUP, priority 100)
                      │  balance leastconn
                      ├── dp-bpmmqbrok01 (RabbitMQ node 1)
                      ├── pp-bpmmqbrok02 (RabbitMQ node 2)
                      └── cp-bpmmqbrok03 (RabbitMQ node 3)
```

---

## Обоснование ключевых решений

### Почему `balance leastconn`, а не `roundrobin`?

AMQP-соединения **долгоживущие** (часы, дни, недели). При `roundrobin` после
рестарта одной ноды распределение навсегда сбивается — старые коннекты
остаются на месте, а новые раздаются поровну. `leastconn` отправляет новые
соединения на наименее загруженную ноду, автоматически выравнивая нагрузку.

*Источник: [HAProxy docs](https://www.haproxy.com/documentation/), [RabbitMQ Networking](https://www.rabbitmq.com/docs/networking)*

### Почему HTTP healthcheck вместо TCP и почему там две проверки?

TCP check (`tcp-check connect`) только проверяет, что порт 5672 открыт. Нода может
быть выведена в maintenance/drain, не иметь AMQP listener или упереться в лимит
соединений. Поэтому HAProxy ходит в Management API на порт `15672`, а не просто
делает TCP connect к `5672`.

В конфиге deliberately используются **две** HTTP-проверки:

1. `/api/health/checks/ready-to-serve-clients` — локальная готовность конкретной
   RabbitMQ-ноды: нода не выведена из обслуживания, AMQP listener поднят, лимит
   соединений не исчерпан.
2. `/api/nodes?columns=name,running` — кластерная проверка: HAProxy считает
   backend живым только если в ответе видны минимум 2 running-ноды из 3.

Почему нельзя оставить только `ready-to-serve-clients`: на живой проверке
RabbitMQ `4.2.5` одиночная оставшаяся нода в 3-нодовом кластере продолжила
отвечать `HTTP 200 {"status":"ok"}`. Для quorum queues это недостаточно:
локально процесс RabbitMQ жив, но большинства кластера уже нет. Поэтому для
продового 3-нодового кластера HAProxy дополнительно проверяет большинство по
`/api/nodes`.

Resource alarms (`memory`/`disk`) лучше держать в мониторинге и алертах. Cluster-wide
alarm check может пометить DOWN все backend-ноды одновременно, что для AMQP хуже:
RabbitMQ и так блокирует publishers при alarm, а consumers/существующие соединения
лучше не рубить балансировщиком автоматически.

*Источники: [RabbitMQ HTTP API health checks](https://www.rabbitmq.com/docs/4.2/http-api-reference#health-checks),
[RabbitMQ `/api/nodes`](https://www.rabbitmq.com/docs/4.2/http-api-reference#get-api-nodes),
[HAProxy `http-check`](https://docs.haproxy.org/2.8/configuration.html#4.2-http-check%20expect)*

### Почему Management UI сессии закрываются при DOWN backend?

HAProxy healthcheck исключает DOWN-ноду из выбора для новых backend-сессий, но
уже открытый HTTP keep-alive к RabbitMQ Management UI может висеть на старой
ноде. Поэтому для `rabbitmq_mgmt` включены короткие HTTP timeout'ы,
`option http-server-close` и `on-marked-down shutdown-sessions`.

Это безопасно для веб-консоли/API: браузер или curl быстро переподключится к
живой ноде. Для AMQP backend fail-fast тоже включён, но там это означает
обязательный reconnect в клиентской библиотеке приложения.

### Насколько адекватен failover AMQP/AMQPS через HAProxy?

Адекватная модель для RabbitMQ HA такая: HAProxy балансирует новые TCP-соединения,
а приложения умеют обнаруживать обрыв AMQP/AMQPS-сессии и переподключаться к VIP.
HAProxy не переносит уже открытый AMQP channel/connection с одной RabbitMQ-ноды
на другую.

В этом конфиге выбран fail-fast подход: когда RabbitMQ-нода становится DOWN по
healthcheck, HAProxy закрывает существующие AMQP-сессии этой backend-ноды через
`on-marked-down shutdown-sessions`. При `inter 5s fall 3 timeout check 5s` это
обычно происходит примерно за 15-30 секунд после того, как healthcheck начал
стабильно падать: если проверка сразу получает отказ, быстрее; если ждёт сетевой
timeout, дольше.
Дальше клиент должен reconnect к VIP и попасть на живую ноду.

Что должно быть в приложениях:

- AMQP heartbeat включён и не слишком большой, обычно 30-60 секунд;
- automatic recovery/reconnect включён в клиентской библиотеке;
- reconnect идёт на DNS/VIP `bpmmq.rdleas.ru`, а не на конкретную broker-ноду;
- publishers используют publisher confirms, если важна гарантия записи;
- consumers корректно переживают redelivery после reconnect.

Обычный сценарий без ручного drain:

1. RabbitMQ-нода падает или уходит в reboot.
2. HAProxy healthcheck получает `fall 3` неудачных проверок и помечает backend
   DOWN.
3. `on-marked-down shutdown-sessions` закрывает старые AMQP-сессии этой ноды.
4. Клиенты переподключаются к VIP.
5. Новые соединения HAProxy отправляет только на живые RabbitMQ-ноды.

Drain для планового reboot всё ещё полезен, но не является условием failover:

```bash
# 1. На HAProxy заранее убрать ноду из новых подключений
echo "set server rabbitmq_amqp/brok01 state drain" | \
  socat stdio /run/haproxy/admin.sock

# 2. Дать приложениям время переподключиться/перераспределиться
echo "show stat" | socat stdio /run/haproxy/admin.sock | grep rabbitmq_amqp

# 3. Если окно обслуживания ограничено, можно принудительно закрыть
# оставшиеся сессии этой ноды, чтобы клиенты быстрее ушли на reconnect.
echo "shutdown sessions server rabbitmq_amqp/brok01" | \
  socat stdio /run/haproxy/admin.sock

# 4. После этого reboot/stop RabbitMQ-ноды
```

Цена такого подхода: если healthcheck ложно пометит ноду DOWN, клиенты к этой
ноде тоже будут разорваны и уйдут в reconnect. Поэтому healthcheck сделан не
просто TCP connect, а двумя HTTP-проверками: локальная готовность ноды плюс
проверка, что кластер видит большинство RabbitMQ-нод.

### Почему `check port 15672` на AMQP backend?

Трафик идёт на `:5672` (TCP mode), но healthcheck делается по HTTP на `:15672`
(Management API). HAProxy поддерживает `check port <N>` — проверка на другом порту.
Это позволяет совместить TCP-проксирование AMQP с семантическим HTTP healthcheck.

### Почему Keepalived `weight -50`, а не `weight 2`?

С `weight 2`: MASTER=101+2=103, BACKUP=100+2=102 при OK.
При падении HAProxy на MASTER: MASTER=101, BACKUP=102 → VIP переедет. Но!
При `weight +2`: если check fail → priority возвращается к base.
MASTER(fail)=101, BACKUP(ok)=100+2=102 → разница всего 1.
С `weight -50`: MASTER(fail)=101-50=51, BACKUP(ok)=100 → VIP гарантированно переедет.

### Почему unicast, а не multicast?

Multicast VRRP (224.0.0.18) часто блокируется на сетевом оборудовании.
Если пакеты пропадают — оба сервера считают себя MASTER → **split-brain**.
Unicast отправляет VRRP напрямую между двумя известными IP.

### Почему `pause_minority`?

`pause_minority` — официальный механизм RabbitMQ для автоматической реакции на
network partition. В 3-нодном кластере minority-сторона перестаёт обслуживать
клиентов до восстановления связи, что защищает metadata/schema-уровень от
split-brain. Quorum queues сами продолжают работу только на стороне большинства, но
это не заменяет partition handling для всего кластера.

Важный практический нюанс: `pause_minority` не является полноценным healthcheck
"кластер имеет большинство". При обычном stop/reboot двух RabbitMQ-нод
оставшаяся нода может продолжать отвечать локальным Management API и
`/api/health/checks/ready-to-serve-clients` как `ok`. Поэтому HAProxy отдельно
проверяет большинство через `/api/nodes?columns=name,running`.

*Источник: [RabbitMQ Partitions](https://www.rabbitmq.com/docs/4.2/partitions)*

### Почему `vm_memory_high_watermark = 0.6`, а не default 0.4?

0.4 (40% RAM) — консервативное значение. На выделенном сервере RabbitMQ можно
позволить использовать 60% RAM для сообщений. Оставшиеся 40% — для Erlang VM,
OS кэшей и WAL.

### Почему `disk_free_limit.relative = 1.5`?

Относительный лимит считается от RAM, а не от `vm_memory_high_watermark`.
При 32 ГБ RAM и `relative = 1.5` disk alarm включится примерно ниже 48 ГБ
свободного места. Это консервативно, но для quorum queues запас диска важен.
На серверах с очень большой RAM часто удобнее задать осознанный absolute-лимит.

### Почему `rabbitmq_peer_discovery_classic_config` убран из enabled_plugins?

Classic config peer discovery **встроен в ядро RabbitMQ** и не требует плагина.
Цитата из docs: "The following mechanisms are built into the core and always available: Config file".

*Источник: [RabbitMQ Cluster Formation](https://www.rabbitmq.com/docs/cluster-formation)*

### Mnesia или Khepri?

В этом проекте целимся в Khepri. Он использует Raft для metadata store, лучше
ведёт себя при сетевых разделениях и в RabbitMQ 4.2 уже считается зрелым
вариантом для новых кластеров.

Важный нюанс по RabbitMQ 4.2: общая документация называет Khepri backend по
умолчанию для новых развертываний, но практическая страница "How to Enable
Khepri" отдельно показывает способ включить его с самого первого старта через
`RABBITMQ_FEATURE_FLAGS=+khepri_db`. Поэтому в этом гайде мы задаём эту
переменную до первого штатного запуска RabbitMQ. Это не миграция и не ручная
возня с флагами после запуска, а часть начальной конфигурации.

Проверка после запуска seed-ноды и после сборки кластера:

```bash
rabbitmqctl list_feature_flags name state | grep khepri_db
```

Ожидаем `khepri_db enabled`. Если seed-нода показывает `disabled`, не
продолжайте запуск остальных нод. На новом пустом узле можно включить флаг:

```bash
rabbitmqctl enable_feature_flag khepri_db
rabbitmqctl list_feature_flags name state | grep khepri_db
```

На уже работающем кластере с данными это отдельная процедура, её нельзя делать
мимо регламента обслуживания.

Важно: путь `/var/lib/rabbitmq/mnesia` в командах очистки — это историческое
имя каталога данных RabbitMQ в Linux-пакетах. Само наличие такого пути не
означает, что новый кластер 4.2.x работает на Mnesia.

*Источник: [RabbitMQ Metadata Store](https://www.rabbitmq.com/docs/metadata-store),
[RabbitMQ How to Enable Khepri](https://www.rabbitmq.com/docs/4.2/metadata-store/how-to-enable-khepri)*

### Почему `quorum_queue.initial_cluster_size = 3`?

Параметр доступен в RabbitMQ 4.2.x.
При 3 нодах default и так 3, но указание явно документирует намерение.
Majority для записи = 2 из 3 → кластер переживает падение 1 ноды без потери данных.

### Почему `queue_leader_locator = balanced`?

По умолчанию лидер новой очереди выбирается рядом с клиентом, который её объявил.
Если один app instance при старте создаст много очередей через HAProxy и попадёт
на одну RabbitMQ-ноду, лидеры могут собраться на ней. `balanced` распределяет
лидеров новых очередей по кластеру равномернее.

### Erlang совместимость

| RabbitMQ | Min Erlang | Max Erlang |
|----------|------------|------------|
| 4.2.x    | 26.2       | 27.x       |
| 4.1.x    | 26.2       | 27.x       |
| 4.0.4+   | 26.2       | 27.x       |

**Рекомендация**: Erlang 27.x (latest patch).
Erlang 28 — только для новых кластеров (есть known issue с Khepri upgrade).

*Источник: [RabbitMQ Erlang Compatibility](https://www.rabbitmq.com/docs/which-erlang)*

### Quorum Queues: delivery limit = 20 (важно!)

В RabbitMQ 4.x у quorum queues **default delivery limit = 20**. Это значит:
если сообщение было redelivered 20 раз (consumer nack/reject + requeue),
оно будет удалено, если не настроен Dead Letter Exchange (DLX).

В `rabbitmq/definitions.json` DLX baseline уже задан заранее:

- exchange `dlx` в vhost `bpmmq`;
- quorum queue `dead_letters`;
- binding `dlx --routing_key dead_letters--> dead_letters`;
- policy `quorum-dlx` для всех quorum queues, кроме самой `dead_letters`;
- `dead-letter-strategy = at-least-once`, чтобы quorum queues подтверждали
  внутреннюю переотправку в DLQ;
- `delivery-limit = 20` явно зафиксирован для будущих quorum queues.

Это означает, что рабочих очередей ещё может не быть: когда разработчики позже
создадут durable quorum queue в vhost `bpmmq`, policy применится к ней
автоматически. Саму `dead_letters` policy не затрагивает, а для неё отключён
`x-delivery-limit`, чтобы сообщения в DLQ не исчезали при повторных requeue.

Важно: `delivery-limit` для quorum queues не является полностью динамическим
параметром. Для новых очередей policy применится при создании; очереди,
созданные до появления policy, надо проверять отдельно и при необходимости
пересоздавать по согласованию с разработчиками.

Если приложению нужна отдельная DLQ/маршрутизация для конкретной очереди,
разработчики могут переопределить DLX при объявлении очереди или дать отдельные
definitions. Но общий safety net уже есть.

*Источник: [RabbitMQ Dead Letter Exchanges](https://www.rabbitmq.com/docs/4.2/dlx),
[RabbitMQ Quorum Queues](https://www.rabbitmq.com/docs/4.2/quorum-queues)*

---

## Порядок развёртывания

### Этап 1: RabbitMQ Cluster (3 ноды)

#### 1.1. Hostname и DNS (на каждой ноде)

```bash
# Нода 1
hostnamectl set-hostname dp-bpmmqbrok01

# Нода 2
hostnamectl set-hostname pp-bpmmqbrok02

# Нода 3
hostnamectl set-hostname cp-bpmmqbrok03
```

Если DNS не резолвит — `/etc/hosts` на каждой ноде:

```
10.x.x.1  dp-bpmmqbrok01
10.x.x.2  pp-bpmmqbrok02
10.x.x.3  cp-bpmmqbrok03
```

#### 1.2. Установка Erlang + RabbitMQ

В целевом контуре установка предполагается из заранее подготовленных `.deb`
пакетов. Вариант с apt-репозиторием ниже нужен либо для online-установки, либо
для подготовки локального набора `.deb` на staging-машине с доступом в интернет.

**Из официального репозитория Team RabbitMQ:**

> Cloudsmith (ppa1.rabbitmq.com) закрыт с ноября 2025.
> Новые URL: `deb1.rabbitmq.com` / `deb2.rabbitmq.com`.
> Источник: [RabbitMQ Install Debian](https://www.rabbitmq.com/docs/install-debian)

```bash
apt-get update && apt-get install -y curl gnupg apt-transport-https

# Signing key
curl -1sLf "https://keys.openpgp.org/vks/v1/by-fingerprint/0A9AF2115F4687BD29803A206B73A36E6026DFCA" \
  | gpg --dearmor -o /usr/share/keyrings/com.rabbitmq.team.gpg

# Репозитории (Erlang + RabbitMQ)
tee /etc/apt/sources.list.d/rabbitmq.list <<EOF
## Modern Erlang/OTP releases
deb [arch=amd64 signed-by=/usr/share/keyrings/com.rabbitmq.team.gpg] https://deb1.rabbitmq.com/rabbitmq-erlang/ubuntu/noble noble main
deb [arch=amd64 signed-by=/usr/share/keyrings/com.rabbitmq.team.gpg] https://deb2.rabbitmq.com/rabbitmq-erlang/ubuntu/noble noble main

## RabbitMQ releases
deb [arch=amd64 signed-by=/usr/share/keyrings/com.rabbitmq.team.gpg] https://deb1.rabbitmq.com/rabbitmq-server/ubuntu/noble noble main
deb [arch=amd64 signed-by=/usr/share/keyrings/com.rabbitmq.team.gpg] https://deb2.rabbitmq.com/rabbitmq-server/ubuntu/noble noble main
EOF

apt-get update

# Зафиксировать RabbitMQ 4.2.5 и Erlang 27.x.
# Erlang 28 частично поддерживается только для brand new clusters, поэтому
# для предсказуемых rolling upgrades лучше держать 27.x.
tee /etc/apt/preferences.d/rabbitmq-erlang <<EOF
Package: erlang*
Pin: version 1:27.*
Pin-Priority: 1001
EOF

tee /etc/apt/preferences.d/rabbitmq-server <<EOF
Package: rabbitmq-server
Pin: version 4.2.5-1
Pin-Priority: 1001
EOF

# Erlang пакеты
apt-get install -y erlang-base erlang-asn1 erlang-crypto erlang-eldap \
  erlang-ftp erlang-inets erlang-mnesia erlang-os-mon erlang-parsetools \
  erlang-public-key erlang-runtime-tools erlang-snmp erlang-ssl \
  erlang-syntax-tools erlang-tftp erlang-tools erlang-xmerl

# RabbitMQ
apt-get install -y rabbitmq-server=4.2.5-1

# Проверка фактически выбранных версий
erl -eval 'erlang:display(erlang:system_info(otp_release)), halt().' -noshell
dpkg-query -W rabbitmq-server erlang-base
apt-mark hold rabbitmq-server
apt-mark hold $(dpkg-query -W -f='${binary:Package}\n' 'erlang-*')

# Пакет может стартовать сервис автоматически. Остановить до cookie/config.
systemctl stop rabbitmq-server
```

**Из локального набора .deb пакетов:**

Скопируйте на каждую RabbitMQ-ноду каталог с пакетами RabbitMQ `4.2.5`,
Erlang `27.x` и всеми системными зависимостями, собранными для Ubuntu 24.04
Noble. Пример каталога: `/opt/bpmmq-debs/rabbitmq/`.

```bash
cd /opt/bpmmq-debs/rabbitmq

# Каталог должен содержать ВСЕ зависимости. Не запускайте apt-get -f install,
# если сервер не должен ходить в внешние репозитории.
dpkg -i ./*.deb

# Проверка фактически установленных версий
erl -eval 'erlang:display(erlang:system_info(otp_release)), halt().' -noshell
dpkg-query -W rabbitmq-server erlang-base

# Зафиксировать версии
apt-mark hold rabbitmq-server
apt-mark hold $(dpkg-query -W -f='${binary:Package}\n' 'erlang-*')

# Пакет может стартовать сервис автоматически. Остановить до cookie/config.
systemctl stop rabbitmq-server
```

Если `dpkg` сообщает о нехватке зависимостей, это значит, что в локальном
наборе `.deb` не хватает пакетов. Добавьте недостающие `.deb` в каталог и
повторите `dpkg -i ./*.deb`.

#### 1.3. Erlang Cookie (КРИТИЧЕСКИ ВАЖНО)

Все 3 ноды ОБЯЗАНЫ иметь одинаковый cookie:

```bash
# На первой ноде — посмотреть cookie
cat /var/lib/rabbitmq/.erlang.cookie

# На остальных — записать такой же
systemctl stop rabbitmq-server
echo "СКОПИРОВАННЫЙ_COOKIE" > /var/lib/rabbitmq/.erlang.cookie
chown rabbitmq:rabbitmq /var/lib/rabbitmq/.erlang.cookie
chmod 400 /var/lib/rabbitmq/.erlang.cookie
```

#### 1.4. Подготовка definitions.json

`rabbitmq/rabbitmq.conf` загружает `/etc/rabbitmq/definitions.json` при старте,
поэтому файл должен быть подготовлен **до** первого запуска RabbitMQ. Значения
`CHANGE_ME_*_HASH` — это плейсхолдеры, а не пароли.

```bash
# Сгенерировать хэши на любой ноде после установки rabbitmq-server
rabbitmqctl hash_password 'STRONG_ADMIN_PASSWORD'
rabbitmqctl hash_password 'MONITOR_PASSWORD'
rabbitmqctl hash_password 'ZABBIX_PASSWORD'
rabbitmqctl hash_password 'APP_PASSWORD'
```

Скопируйте полученные хэши в `rabbitmq/definitions.json` для пользователей
`admin`, `haproxy_monitor`, `zbx_monitor`, `app_user`. В `bpmmq` уже задан
`default_queue_type = quorum`, а в `/` оставлен `classic`.

Этот же файл заранее создаёт инфраструктурный DLX baseline в `bpmmq`:
`dlx`, очередь `dead_letters`, binding и policy `quorum-dlx` для будущих
quorum queues. Рабочие очереди приложения в definitions не прописываем.

#### 1.5. Конфигурация (на каждой ноде)

```bash
cp rabbitmq/rabbitmq.conf    /etc/rabbitmq/rabbitmq.conf
cp rabbitmq/enabled_plugins  /etc/rabbitmq/enabled_plugins
cp rabbitmq/definitions.json /etc/rabbitmq/definitions.json
```

Для Khepri задать feature flag до первого штатного запуска RabbitMQ:

```bash
mkdir -p /etc/systemd/system/rabbitmq-server.service.d
tee /etc/systemd/system/rabbitmq-server.service.d/10-khepri.conf <<'EOF'
[Service]
Environment="RABBITMQ_FEATURE_FLAGS=+khepri_db"
EOF
systemctl daemon-reload
```

`RABBITMQ_FEATURE_FLAGS` учитывается только при первом старте нового узла. Если
пакет уже успел автоматически стартовать до настройки cookie/config, остановите
сервис и не продолжайте вслепую: после запуска seed-ноды обязательно проверьте
`khepri_db enabled` в разделе проверки ниже.

#### 1.6. Запуск кластера

Как ноды узнают друг друга:

- в `rabbitmq/rabbitmq.conf` задан `cluster_formation.peer_discovery_backend = classic_config`;
- там же перечислены все peer node names:
  `rabbit@dp-bpmmqbrok01`, `rabbit@pp-bpmmqbrok02`, `rabbit@cp-bpmmqbrok03`;
- при первом старте blank-нода читает этот список, пытается достучаться до
  peers по Erlang distribution и присоединяется к первому доступному кластеру;
- поэтому hostnames должны резолвиться одинаково на всех 3 нодах, cookie должен
  быть одинаковым, а порты `4369` и `25672` должны быть открыты между нодами.

Рекомендуемый порядок первого запуска — поочерёдно:

```bash
# 1. На seed-ноде dp-bpmmqbrok01
systemctl enable --now rabbitmq-server

# Проверить, что первая нода поднялась
rabbitmqctl await_startup
rabbitmq-diagnostics ping

# 2. На pp-bpmmqbrok02
systemctl enable --now rabbitmq-server

# 3. На cp-bpmmqbrok03
systemctl enable --now rabbitmq-server
```

После запуска нод 2 и 3 они должны сами присоединиться через peer discovery.
Проверить с любой RabbitMQ-ноды:

```bash
rabbitmqctl cluster_status
# В Running Nodes должны быть все 3 ноды
```

Технически blank-ноды можно стартовать параллельно: RabbitMQ попробует собрать
кластер по списку `classic_config.nodes`. Но для первого ручного развёртывания
последовательный запуск проще отлаживать: сначала появился seed, потом остальные
присоединились к уже существующему кластеру.

Fallback, если auto peer discovery не сработал:

```bash
# На pp-bpmmqbrok02 и cp-bpmmqbrok03
rabbitmqctl join_cluster rabbit@dp-bpmmqbrok01
rabbitmqctl cluster_status
```

В RabbitMQ 4.1+ `join_cluster` сам выполняет необходимые подготовки; для
fresh-ноды `stop_app` и `reset` больше не нужны.

#### 1.7. Проверка

```bash
rabbitmqctl cluster_status
# Все 3 ноды в Running Nodes

rabbitmqctl list_vhosts name default_queue_type
# bpmmq -> quorum

rabbitmqctl list_exchanges -p bpmmq name type durable | grep '^dlx'
rabbitmqctl list_queues -p bpmmq name type durable arguments | grep '^dead_letters'
rabbitmqctl list_policies -p bpmmq
```

Если на не-fresh ноде остался default user:

```bash
rabbitmqctl delete_user guest
```

#### 1.8. Пользователи (если не через definitions.json)

```bash
rabbitmqctl delete_user guest

rabbitmqctl add_user admin 'STRONG_PASSWORD'
rabbitmqctl set_user_tags admin administrator
rabbitmqctl set_permissions -p / admin ".*" ".*" ".*"

# Мониторинг-пользователь для HAProxy healthcheck (минимальные права)
rabbitmqctl add_user haproxy_monitor 'MONITOR_PASSWORD'
rabbitmqctl set_user_tags haproxy_monitor monitoring

rabbitmqctl add_vhost bpmmq --default-queue-type quorum

# Мониторинг-пользователь для Zabbix RabbitMQ template
rabbitmqctl add_user zbx_monitor 'ZABBIX_PASSWORD'
rabbitmqctl set_user_tags zbx_monitor monitoring
rabbitmqctl set_permissions -p / zbx_monitor "" "" ".*"
rabbitmqctl set_permissions -p bpmmq zbx_monitor "" "" ".*"

rabbitmqctl add_user app_user 'APP_PASSWORD'
rabbitmqctl set_permissions -p bpmmq app_user ".*" ".*" ".*"
rabbitmqctl set_permissions -p bpmmq admin ".*" ".*" ".*"
```

Если не используете `definitions.json`, создайте базовый DLX safety net вручную:

```bash
# DLX exchange
curl -u admin:STRONG_PASSWORD -H "content-type: application/json" \
  -X PUT http://localhost:15672/api/exchanges/bpmmq/dlx \
  -d '{"type":"direct","durable":true,"auto_delete":false,"internal":false,"arguments":{}}'

# Dead-letter queue. x-delivery-limit=-1 нужен, чтобы сама DLQ не теряла
# сообщения при повторных requeue.
curl -u admin:STRONG_PASSWORD -H "content-type: application/json" \
  -X PUT http://localhost:15672/api/queues/bpmmq/dead_letters \
  -d '{"durable":true,"auto_delete":false,"arguments":{"x-queue-type":"quorum","x-delivery-limit":-1}}'

# Binding dlx -> dead_letters
curl -u admin:STRONG_PASSWORD -H "content-type: application/json" \
  -X POST http://localhost:15672/api/bindings/bpmmq/e/dlx/q/dead_letters \
  -d '{"routing_key":"dead_letters","arguments":{}}'

# Policy для будущих quorum queues, кроме самой dead_letters
rabbitmqctl set_policy quorum-dlx "^(?!dead_letters$).*" \
  '{"dead-letter-exchange":"dlx","dead-letter-routing-key":"dead_letters","dead-letter-strategy":"at-least-once","overflow":"reject-publish","delivery-limit":20}' \
  --vhost bpmmq --apply-to quorum_queues --priority 10
```

#### 1.9. Если кластер уже запустили без rabbitmq.conf и definitions.json

Если в кластере уже есть полезные очереди/сообщения, **не делайте reset**.
Сначала остановите приложения, согласуйте миграцию с разработчиками и отдельно
решите, что делать с сообщениями. Definitions import переносит metadata/topology,
но не является способом сохранения сообщений.

Если это свежий ошибочный запуск без полезных данных, проще пересоздать кластер
как blank/fresh. `rabbitmqctl reset` удаляет данные узла: cluster membership,
users, vhosts, queues, exchanges, bindings, runtime parameters и локальные
message stores.

1. На всех RabbitMQ-нодах остановить RabbitMQ app и сбросить локальное состояние:

   ```bash
   rabbitmqctl stop_app
   rabbitmqctl reset
   systemctl stop rabbitmq-server
   ```

   Если нода не отвечает на `rabbitmqctl`, остановите сервис и отложите старый
   data dir в сторону:

   ```bash
   systemctl stop rabbitmq-server
   mv /var/lib/rabbitmq/mnesia /var/lib/rabbitmq/mnesia.before-recreate.$(date +%F-%H%M%S)
   ```

2. На всех 3 нодах выставить одинаковый Erlang cookie:

   ```bash
   echo "СКОПИРОВАННЫЙ_COOKIE" > /var/lib/rabbitmq/.erlang.cookie
   chown rabbitmq:rabbitmq /var/lib/rabbitmq/.erlang.cookie
   chmod 400 /var/lib/rabbitmq/.erlang.cookie
   ```

3. Подготовить `definitions.json`: заменить все `CHANGE_ME_*_HASH` на хэши,
   сгенерированные `rabbitmqctl hash_password`.

4. На всех 3 нодах скопировать конфиги до старта:

   ```bash
   cp rabbitmq/rabbitmq.conf    /etc/rabbitmq/rabbitmq.conf
   cp rabbitmq/enabled_plugins  /etc/rabbitmq/enabled_plugins
   cp rabbitmq/definitions.json /etc/rabbitmq/definitions.json
   chown root:rabbitmq /etc/rabbitmq/rabbitmq.conf /etc/rabbitmq/enabled_plugins /etc/rabbitmq/definitions.json
   chmod 640 /etc/rabbitmq/rabbitmq.conf /etc/rabbitmq/enabled_plugins /etc/rabbitmq/definitions.json
   ```

5. Запустить RabbitMQ seed-first:

   ```bash
   # На dp-bpmmqbrok01
   systemctl enable --now rabbitmq-server
   rabbitmqctl await_startup
   rabbitmq-diagnostics ping

   # Затем на pp-bpmmqbrok02
   systemctl enable --now rabbitmq-server

   # Затем на cp-bpmmqbrok03
   systemctl enable --now rabbitmq-server
   ```

   Если по какой-то причине auto peer discovery не собрал кластер, выполните
   ручное присоединение на нодах 2 и 3:

   ```bash
   rabbitmqctl join_cluster rabbit@dp-bpmmqbrok01
   ```

6. Проверить результат:

   ```bash
   rabbitmqctl cluster_status
   rabbitmqctl list_feature_flags name state | grep khepri_db
   rabbitmqctl list_vhosts name default_queue_type
   rabbitmqctl list_exchanges -p bpmmq name type durable | grep '^dlx'
   rabbitmqctl list_queues -p bpmmq name type durable arguments | grep '^dead_letters'
   rabbitmqctl list_policies -p bpmmq
   rabbitmqctl list_users
   rabbitmqctl list_permissions -p bpmmq
   ```

   Ожидаем 3 running nodes, `khepri_db enabled`, vhost `bpmmq` с
   `default_queue_type = quorum`, пользователей `admin`, `haproxy_monitor`,
   `zbx_monitor`, `app_user`, exchange `dlx`, queue `dead_letters` и policy
   `quorum-dlx`.

#### 1.10. Что передать разработчикам

После настройки кластера ваша задача как сисадмина выполнена.
Рабочие очереди, app-specific exchanges, bindings, TTL, delivery limits и
тонкая маршрутизация DLX — это бизнес-логика приложения. Их настраивают
разработчики (или вы по их ТЗ).

**Передайте команде разработки:**

```
AMQP подключение:  amqp://app_user:PASSWORD@bpmmq.rdleas.ru:5672/bpmmq
Management UI:     http://bpmmq.rdleas.ru:15672
                   Логин: admin / PASSWORD (или отдельный аккаунт)
```

**Что входит в вашу зону (инфраструктура):**
- Установка, кластеризация, HAProxy, Keepalived, firewall
- Пользователи (`admin`, `haproxy_monitor`, `zbx_monitor`, `app_user`), vhosts, права
- Базовый DLX safety net (`dlx`, `dead_letters`, policy `quorum-dlx`)
- Мониторинг (Prometheus на :15692 + Grafana)
- Бэкапы definitions (`rabbitmqctl export_definitions`)
- Rolling upgrades, обслуживание нод

**Что входит в зону разработчиков (бизнес-логика):**
- Создание очередей, exchange, bindings
- App-specific DLX/маршрутизация, если общего `dead_letters` недостаточно
- TTL, delivery limits, приоритеты
- Publish/consume логика в коде приложения

`definitions.json` создаёт пользователей, vhosts и один инфраструктурный DLX
baseline. Рабочие очереди приложения не прописывайте в definitions, если не
знаете бизнес-логику.

В vhost `bpmmq` default queue type = `quorum`: durable рабочие очереди,
объявленные без `x-queue-type`, станут quorum queues. Если приложению нужны
временные/RPC/reply очереди, разработчики должны явно объявлять их как `classic`
или использовать отдельный vhost с другим default queue type.

**Как разработчики создают очереди:**

1. **В коде приложения (стандартный способ)** — приложение при запуске
   само объявляет нужные очереди идемпотентно (если есть — ничего не делает):
   ```python
   channel.queue_declare(queue='orders', durable=True,
                         arguments={'x-queue-type': 'quorum'})
   ```

2. **Через Management UI** — зайти на http://bpmmq.rdleas.ru:15672,
   создать мышкой. Подходит для экспериментов.

3. **Через HTTP API** — `curl` к Management API на `:15672`.

4. **Через import definitions (вы по ТЗ)** — разработчик даёт JSON,
   вы импортируете без перезапуска:
   ```bash
   rabbitmqctl import_definitions /path/to/devs_definitions.json
   ```

#### 1.11. Firewall (между нодами кластера)

```bash
# Между нодами RabbitMQ
ufw allow from <ip-brok01> to any port 4369,25672,5672,15672,15692 proto tcp
ufw allow from <ip-brok02> to any port 4369,25672,5672,15672,15692 proto tcp
ufw allow from <ip-brok03> to any port 4369,25672,5672,15672,15692 proto tcp

# С балансировщиков
ufw allow from <ip-bal01> to any port 5672,15672 proto tcp
ufw allow from <ip-bal02> to any port 5672,15672 proto tcp

# Важно: из-за proxy_protocol = true прямой AMQP-доступ клиентов к broker
# nodes на 5672 запрещён. Клиенты должны ходить на VIP/HAProxy.

# С Zabbix server/proxy к Management API
ufw allow from <ip-zabbix> to any port 15672 proto tcp
```

| Порт  | Назначение              |
|-------|-------------------------|
| 4369  | epmd (Erlang discovery) |
| 25672 | Erlang distribution     |
| 5672  | AMQP                    |
| 15672 | Management UI/API       |
| 15692 | Prometheus metrics      |

---

### Аудит и централизованное логирование

RabbitMQ + HAProxy закрывают техническую часть аудита: предупреждения и ошибки,
подключения и отключения AMQP, неуспешную аутентификацию через Management API,
создание и удаление пользователей/vhosts, изменение user tags, permissions,
password и установку policies RabbitMQ, состояния кластера, ресурсные тревоги и
HAProxy healthcheck DOWN/UP. Queue/exchange/binding create/delete и явный
`clear_policy` обычным `rabbitmq.log` не заявляем; для них нужен отдельный
`rabbitmq_event_exchange`, если КБ потребует именно такой структурированный
аудит топологии.

Бизнес-аудит (карточки клиентов, ПДн, фискальные события, отчёты, старые/новые
значения бизнес-атрибутов) RabbitMQ/HAProxy не закрывает: эти события должны
логироваться приложением.

В конфиге включён реальный IP клиента для AMQP:

- `rabbitmq/rabbitmq.conf`: `proxy_protocol = true`;
- `haproxy/haproxy.cfg`: `send-proxy` на AMQP backend-серверах.

Это позволяет RabbitMQ писать в логи AMQP-соединений исходный IP клиента, а не
IP балансировщика. После включения PROXY protocol прямой доступ клиентов к
RabbitMQ `:5672` невозможен: broker ожидает PROXY-заголовок от HAProxy. Поэтому
firewall должен разрешать `5672/tcp` на broker-ноды только с HAProxy-серверов.

Логи HAProxy всё равно нужны:

- `tcplog` по AMQP показывает frontend/backend, выбранную backend-ноду,
  длительность сессии, байты и состояние завершения TCP-сессии;
- `httplog` по Management UI/API показывает HTTP-метод, URI, статус ответа и
  выбранную backend-ноду;
- переходы healthcheck (`DOWN`/`UP`, `no server available`) фиксируют
  недоступность компонентов.

### Передача логов в ELK

Рекомендуемая схема для этой АС:

```text
серверы RabbitMQ/HAProxy -> Filebeat -> logstash.sbl-mon.kub.rdleas.ru:5044 -> Logstash -> Elasticsearch/Kibana
```

Подробная пошаговая инструкция вынесена в отдельный файл:

```text
RABBITMQ_LOGSTASH_INTEGRATION.md
```

В ней есть:

- какие файлы смотреть в `devops`;
- какие блоки уже должны быть в Logstash и ingress-nginx;
- как установить Filebeat через `.deb`/systemd;
- как запустить Filebeat в Docker, если в контуре так принято;
- как проверить доставку событий в Kibana.

Коротко по готовым файлам:

- `elk/filebeat-bpmmq.yml` — основной Filebeat-конфиг для `.deb`/systemd;
- `elk/filebeat-bpmmq.docker.yml` и `elk/docker-compose.filebeat.yml` —
  Docker-вариант Filebeat;
- `elk/logstash-bpmmq-routing.conf` — локальный эталон output-маршрутов
  Logstash для тегов `rabbitmq-bpmmq`, `haproxy-bpmmq`, `keepalived-bpmmq`.

RabbitMQ и HAProxy не надо специально переводить в JSON или syslog: текущие
файловые логи подходят для Filebeat. Старый `log` input Filebeat не используем,
потому что в примерах уже используется актуальный `filestream`.

Если включается LDAP authentication + internal authorization:

```ini
auth_backends.1.authn = ldap
auth_backends.1.authz = internal
```

Тогда пароль проверяет LDAP, а RabbitMQ permissions/tags остаются внутренними.
Для аудита нужны и логи RabbitMQ, и логи LDAP или системы управления учётными
записями. Подробное LDAP-логирование включайте только точечно для диагностики;
не включайте режимы, которые могут вывести в журнал чувствительные данные
сетевого обмена.

Режимы LDAP-логирования в RabbitMQ:

```ini
auth_ldap.log = false          # по умолчанию
auth_ldap.log = true           # подробная логика решений LDAP, учетные данные скрываются
auth_ldap.log = network        # дополнительно сетевой LDAP-обмен, очень шумно
auth_ldap.log = network_unsafe # НЕ использовать в production: может писать пароли
```

Подробная матрица требований аудита лежит в `AUDIT_LOGGING_CONFLUENCE.md`.

ТЗ на базовый Zabbix-мониторинг RabbitMQ, HAProxy/Keepalived и MinIO лежит в
`ZABBIX_MONITORING_TZ.md`.

---

### Zabbix Monitoring

`definitions.json` создаёт отдельного пользователя `zbx_monitor` с тегом
`monitoring` и read-only permissions на `/` и `bpmmq`. Это покрывает Zabbix
RabbitMQ-шаблоны через Management API.

Для общей проверки кластера/VIP:

```text
{$RABBITMQ.API.SCHEME}=http
{$RABBITMQ.API.CLUSTER_HOST}=bpmmq.rdleas.ru
{$RABBITMQ.API.PORT}=15672
{$RABBITMQ.API.USER}=zbx_monitor
{$RABBITMQ.API.PASSWORD}=ZABBIX_PASSWORD
```

Для мониторинга каждой RabbitMQ-ноды отдельно указывайте FQDN конкретной ноды
на `:15672`, а не VIP:

```text
{$RABBITMQ.API.HOST}=dp-bpmmqbrok01.rdleas.ru
{$RABBITMQ.API.HOST}=pp-bpmmqbrok02.rdleas.ru
{$RABBITMQ.API.HOST}=cp-bpmmqbrok03.rdleas.ru
```

Подробное ТЗ на Zabbix-мониторинг лежит в `ZABBIX_MONITORING_TZ.md`.

---

### Этап 2: HAProxy (2 балансировщика)

#### 2.1. Установка

Из apt-репозитория:

```bash
apt-get update && apt-get install -y haproxy socat
# socat нужен для Keepalived healthcheck и управления через stats socket
```

Из локального набора `.deb` пакетов:

```bash
cd /opt/bpmmq-debs/haproxy
dpkg -i ./*.deb
haproxy -vv
```

Каталог должен содержать `haproxy`, `socat` и их зависимости под Ubuntu 24.04.

#### 2.2. Конфигурация (одинаковая на обоих)

```bash
cp haproxy/haproxy.cfg /etc/haproxy/haproxy.cfg
```

**Сгенерировать Base64 для healthcheck:**

```bash
# haproxy_monitor — пользователь с тегом monitoring (минимальные права)
printf 'haproxy_monitor:MONITOR_PASSWORD' | base64 -w0
```

Полученную строку вставить вместо `CHANGE_ME_BASE64` во все строки
`http-check send` в `/etc/haproxy/haproxy.cfg`.

В 3-нодовом prod-конфиге healthcheck состоит из двух HTTP-запросов:

```haproxy
http-check connect port 15672
http-check send meth GET uri /api/health/checks/ready-to-serve-clients ver HTTP/1.1 hdr Host rabbitmq-health.local hdr Authorization "Basic BASE64_ОТ_КОМАНДЫ_ВЫШЕ" hdr Accept application/json
http-check expect status 200
http-check connect port 15672
http-check send meth GET uri /api/nodes?columns=name,running ver HTTP/1.1 hdr Host rabbitmq-health.local hdr Authorization "Basic BASE64_ОТ_КОМАНДЫ_ВЫШЕ" hdr Accept application/json
```

Можно заменить автоматически:

```bash
B64="$(printf 'haproxy_monitor:MONITOR_PASSWORD' | base64 -w0)"
sed -i "s/CHANGE_ME_BASE64/${B64}/g" /etc/haproxy/haproxy.cfg
```

Отдельно замените `CHANGE_ME_STATS_PASSWORD` в `stats auth`; это обычный
plain-text пароль для HAProxy stats page, его не надо кодировать в base64.
Stats listener
по умолчанию слушает только `127.0.0.1:8404`; для просмотра используйте SSH
tunnel или открывайте его только в management-сети.

Строки `server ... send-proxy check port 15672` в AMQP backend должны
оставаться синхронизированными с `proxy_protocol = true` в RabbitMQ. Если
PROXY protocol отключить на одной стороне и оставить на другой, AMQP-клиенты
перестанут подключаться.

#### 2.3. Проверка и запуск

```bash
haproxy -c -f /etc/haproxy/haproxy.cfg   # проверить синтаксис
systemctl enable --now haproxy
```

#### 2.4. Firewall

```bash
ufw allow 5672/tcp    # AMQP
ufw allow 15672/tcp   # Management UI
# HAProxy stats по умолчанию bind 127.0.0.1:8404, наружу не открывать.
# Если нужен удалённый мониторинг: bind на mgmt-IP + ufw allow from <monitoring-ip> to any port 8404 proto tcp
```

---

### Этап 3: Keepalived (VIP)

#### 3.1. Установка

Из apt-репозитория:

```bash
apt-get install -y keepalived socat
```

Из локального набора `.deb` пакетов:

```bash
cd /opt/bpmmq-debs/keepalived
dpkg -i ./*.deb
keepalived --version
```

Каталог должен содержать `keepalived`, `socat` и их зависимости под Ubuntu 24.04.

#### 3.2. Health check скрипт (на обоих балансировщиках)

```bash
cp keepalived/check_haproxy.sh /etc/keepalived/check_haproxy.sh
chmod +x /etc/keepalived/check_haproxy.sh
```

#### 3.3. Конфигурация

```bash
# На dp-bpmmqbal01 (preferred MASTER)
cp keepalived/keepalived-master.conf /etc/keepalived/keepalived.conf

# На pp-bpmmqbal02 (BACKUP)
cp keepalived/keepalived-backup.conf /etc/keepalived/keepalived.conf
```

**Заменить плейсхолдеры:**

| Placeholder | Описание | Как узнать |
|---|---|---|
| `interface eth0` | Сетевой интерфейс | `ip a` |
| `unicast_src_ip 10.x.x.BAL01` | IP этого балансировщика | `ip a` |
| `unicast_peer 10.x.x.BAL02` | IP другого балансировщика | `ip a` |
| `10.x.x.VIP/24` | VIP (bpmmq.rdleas.ru) | DNS / network team |
| `CHANGEME` | Пароль VRRP (макс 8 символов) | Придумать |

#### 3.4. Sysctl

```bash
cat >/etc/sysctl.d/99-bpmmq-vip.conf <<EOF
net.ipv4.ip_nonlocal_bind = 1
EOF
sysctl --system
```

#### 3.5. Firewall для VRRP unicast

VRRP использует IP protocol 112, это не TCP/UDP порт.

```bash
# На dp-bpmmqbal01
ufw allow proto 112 from <ip-bal02> to any

# На pp-bpmmqbal02
ufw allow proto 112 from <ip-bal01> to any
```

#### 3.6. Запуск

```bash
systemctl enable --now keepalived
```

#### 3.7. Проверка VIP

```bash
ip addr show   # На active MASTER должен быть VIP
ping bpmmq.rdleas.ru
```

---

## Проверка всей связки

```bash
# 1. Кластер RabbitMQ
rabbitmqctl cluster_status

# 2. Management API через VIP
curl -u admin:PASSWORD http://bpmmq.rdleas.ru:15672/api/overview

# 3. Локальная готовность RabbitMQ-ноды
curl -u haproxy_monitor:PASSWORD http://bpmmq.rdleas.ru:15672/api/health/checks/ready-to-serve-clients
# Ожидаем: {"status":"ok"}

# 4. Кластерная часть healthcheck: минимум 2 running-ноды из 3.
# Эту проверку полезно выполнять напрямую на broker-ноде, а не через VIP,
# чтобы увидеть реальный ответ конкретного RabbitMQ.
curl -u haproxy_monitor:PASSWORD \
  'http://dp-bpmmqbrok01.rdleas.ru:15672/api/nodes?columns=name,running'
# Ожидаем: минимум две строки/записи с "running":true.
# При одной живой ноде из трёх HAProxy должен пометить backend DOWN.

# 5. HAProxy stats локально на балансировщике
curl -u admin:STATS_PASSWORD http://127.0.0.1:8404/stats

# 6. Тест topology/publish/get через Management HTTP API.
# Используем admin, потому что app_user без management-тега не обязан иметь
# доступ к HTTP API.
curl -u admin:PASSWORD -H "content-type: application/json" \
  -X PUT http://bpmmq.rdleas.ru:15672/api/queues/bpmmq/test_q \
  -d '{"durable":true,"arguments":{"x-queue-type":"quorum"}}'

curl -u admin:PASSWORD -H "content-type: application/json" \
  -X POST http://bpmmq.rdleas.ru:15672/api/exchanges/bpmmq/amq.default/publish \
  -d '{"properties":{},"routing_key":"test_q","payload":"hello","payload_encoding":"string"}'

curl -u admin:PASSWORD -H "content-type: application/json" \
  -X POST http://bpmmq.rdleas.ru:15672/api/queues/bpmmq/test_q/get \
  -d '{"count":1,"ackmode":"ack_requeue_false","encoding":"auto","truncate":50000}'

# 6. Проверка реального AMQP-подключения app_user через VIP.
# Выполняется клиентом приложения или любой AMQP 0-9-1 утилитой, если она есть
# в вашем стандартном наборе пакетов.
```

### Тест failover HAProxy

```bash
# На active MASTER (обычно dp-bpmmqbal01)
systemctl stop haproxy

# Проверить: VIP переехал на BACKUP
# На pp-bpmmqbal02:
ip addr show   # VIP здесь

# AMQP продолжает работать через VIP
curl -u admin:PASSWORD http://bpmmq.rdleas.ru:15672/api/overview
```

### Тест failover RabbitMQ

```bash
# Остановить одну ноду
systemctl stop rabbitmq-server   # на любой из 3 нод

# Проверить: кластер работает (2/3), quorum queues доступны
rabbitmqctl cluster_status       # на оставшейся ноде
```

---

## Операции обслуживания

### rabbitmqadmin не обязателен

`rabbitmqadmin` — это отдельная CLI-утилита поверх RabbitMQ Management HTTP API.
Она удобна для ручных операций, но не нужна для развёртывания кластера:
в этом гайде все обязательные действия выполняются через `rabbitmqctl`,
`rabbitmq-diagnostics`, config files, definitions import и `curl`.

Если всё же нужна эта утилита:

- `rabbitmqadmin` v1 можно скачать с любой ноды, где включён management plugin:
  `http://<rabbitmq-host>:15672/cli/rabbitmqadmin`;
- для RabbitMQ 4.x предпочтительнее `rabbitmqadmin` v2 из официальной
  документации RabbitMQ Management CLI;
- в offline-контуре её надо заранее положить в ваш пакетный/утилитный набор.

### Rolling upgrade / обслуживание ноды RabbitMQ

```bash
# 1. Drain нода в HAProxy (новые соединения не приходят, старые доживают)
echo "set server rabbitmq_amqp/brok01 state drain" | \
  socat stdio /run/haproxy/admin.sock

# 2. Дождаться пока соединения уйдут (мониторить stats)
echo "show stat" | socat stdio /run/haproxy/admin.sock | grep rabbitmq_amqp

# 3. Остановить / обновить RabbitMQ
systemctl stop rabbitmq-server
# ... upgrade ...
systemctl start rabbitmq-server

# 4. Вернуть ноду в балансировку
echo "set server rabbitmq_amqp/brok01 state ready" | \
  socat stdio /run/haproxy/admin.sock
# slowstart 60s — нагрузка будет нарастать плавно
```

---

## Опциональный локальный тестовый стенд (Docker)

Это **не способ развёртывания**. Все production/dev инструкции выше рассчитаны
на установку из `.deb` пакетов на Ubuntu 24.04.

Docker Compose в `test-docker/` оставлен только как локальная проверочная песочница:
быстро поднять 3x RabbitMQ 4.2.5 + HAProxy 2.8 и проверить синтаксис/healthcheck
без доступа к реальным серверам. На боевые серверы Docker устанавливать не нужно.

| Тест | Результат |
|---|---|
| Формирование кластера (3 ноды) | Проверить `rabbitmqctl cluster_status` |
| HAProxy backends (L7 health check) | Проверить `/stats`, `check=L7OK` |
| Локальный health endpoint `/api/health/checks/ready-to-serve-clients` | HTTP 200, `{"status":"ok"}` |
| Кластерная часть HAProxy healthcheck `/api/nodes?columns=name,running` | При 3/3 и 2/3 живых нодах backend `UP`; при 1/3 живой ноде backend `DOWN` |
| Реальный IP клиента в AMQP | Лог RabbitMQ показывает IP клиента из PROXY protocol, а не IP HAProxy |
| Quorum queue (3 реплики) | Проверить members `[rabbit1, rabbit2, rabbit3]` |
| Publish/consume через HAProxy | Проверить через Management HTTP API или штатный AMQP-клиент |
| Failover: stop leader node | Проверить переезд leader и отсутствие потерь при confirms |

---

## Dev-профиль для одной ноды

Для dev-окружения добавлен профиль `dev/` под схему **1 HAProxy server +
1 RabbitMQ server**:

Пакеты ставятся так же из `.deb`: на RabbitMQ-сервере используйте набор
`/opt/bpmmq-debs/rabbitmq`, на HAProxy-сервере — `/opt/bpmmq-debs/haproxy`.

```bash
# На dev RabbitMQ server
cp dev/rabbitmq.conf   /etc/rabbitmq/rabbitmq.conf
cp dev/enabled_plugins /etc/rabbitmq/enabled_plugins
cp dev/definitions.json /etc/rabbitmq/definitions.json

# Чтобы dev был ближе к prod по metadata store
mkdir -p /etc/systemd/system/rabbitmq-server.service.d
tee /etc/systemd/system/rabbitmq-server.service.d/10-khepri.conf <<'EOF'
[Service]
Environment="RABBITMQ_FEATURE_FLAGS=+khepri_db"
EOF
systemctl daemon-reload

# На dev HAProxy server
cp dev/haproxy.cfg     /etc/haproxy/haproxy.cfg
```

В этом профиле RabbitMQ слушает стандартные порты `:5672` и `:15672` на
отдельном RabbitMQ-сервере. HAProxy тоже слушает стандартные `:5672` и
`:15672` на отдельном HAProxy-сервере и проксирует на RabbitMQ.
AMQP backend использует PROXY protocol, поэтому приложения должны ходить
только на dev HAProxy, а не напрямую на dev RabbitMQ `:5672`.

Перед стартом замените:

```text
DEV_RABBITMQ_HOST
CHANGE_ME_ADMIN_HASH
CHANGE_ME_MONITOR_HASH
CHANGE_ME_ZABBIX_HASH
CHANGE_ME_APP_HASH
CHANGE_ME_BASE64
CHANGE_ME_STATS_PASSWORD
```

`DEV_RABBITMQ_HOST` — DNS name или IP dev RabbitMQ-сервера, доступный с dev
HAProxy-сервера. Между HAProxy и RabbitMQ откройте TCP `5672` и `15672`; если
Zabbix ходит напрямую на RabbitMQ, откройте ему TCP `15672`.

Dev-профиль сохраняет `bpmmq` как quorum-default vhost, но
`quorum_queue.initial_cluster_size = 1`. Это нужно только для совместимости
приложений в single-node dev и не даёт production HA-гарантий.

# Terraform для Kibana spaces и data views

Эта папка содержит готовые файлы для репозитория:

```text
~/devops/devops-repos/terraform/elasticstack/
```

Terraform здесь нужен только для объектов Kibana/Elastic: пространства Kibana,
data views, index templates и похожие сохранённые объекты. Logstash pipeline и
роли доступа через OIDC здесь не настраиваются.

## Основной вариант: только prod

Сейчас основной комплект сделан только для prod, но слово `prod` оставлено в
именах. Это нужно, чтобы потом без переименования добавить `dev`, `ift` или
`psi`, если они всё-таки понадобятся.

| Файл | Что создаёт |
|---|---|
| `s3stor.tf` | Kibana space `s3stor` и data view `app-minio-audit-prod`. |
| `bpmmq.tf` | Kibana space `bpmmq` и data view `app-bpmmq-prod`. |

Индексы, которые будут видны через эти data views:

- `app-minio-audit-prod*`;
- `app-bpmmq-prod-*`.

## Альтернатива: dev/ift/psi/prod

Если позже понадобятся отдельные окружения, использовать не основной файл, а
multi-env варианты:

| Файл | Что создаёт |
|---|---|
| `s3stor.multi-env.tf` | Space `s3stor` и data views `app-minio-audit-dev`, `app-minio-audit-ift`, `app-minio-audit-psi`, `app-minio-audit-prod`. |
| `bpmmq.multi-env.tf` | Space `bpmmq` и data views `app-bpmmq-dev`, `app-bpmmq-ift`, `app-bpmmq-psi`, `app-bpmmq-prod`. |

Основной и multi-env варианты не надо применять одновременно: выбрать один.

## Как применить основной prod-вариант

Запускать нужно из Terraform-репозитория Elastic, а не из `bpmmq` и не из
`fluxcd`:

```bash
cd ~/devops/devops-repos/terraform/elasticstack
```

Этот каталог уже содержит `provider.tf`. В нём описано:

- где хранится Terraform state: backend `pg`;
- куда Terraform ходит в Elasticsearch;
- куда Terraform ходит в Kibana;
- какой provider используется.

Перед запуском убедиться, что текущая машина или CI-runner имеет доступ к
PostgreSQL backend, Elasticsearch/Kibana service DNS и нужным credentials.

Дальше применить patch и построить plan:

```bash
git status --short
git apply --check /path/to/bpmmq/terraform-elasticstack-s3stor-bpmmq.patch
git apply /path/to/bpmmq/terraform-elasticstack-s3stor-bpmmq.patch

terraform init
terraform fmt -check s3stor.tf bpmmq.tf
terraform plan
```

Если `terraform init` падает на backend или provider, значит окружение запуска
не подготовлено: нет доступа к backend `pg`, не настроен provider mirror для
`local/elasticstack` или не хватает сетевого доступа.

Если `terraform plan` падает с ошибкой DNS, connection refused или auth, значит
Terraform не может попасть в Elasticsearch/Kibana или ему не передали учётные
данные.

## Как работает GitLab CI в этом репозитории

В текущем `terraform/elasticstack/.gitlab-ci.yml` подключён общий шаблон:

```yaml
include:
  - project: DevOps/cicd
    file: terraform/elasticstack.yaml
    ref: main
```

В локальной копии `DevOps/cicd` этот шаблон лежит здесь:

```text
devops-repos/cicd/terraform/elasticstack.yaml
```

Он наследует базовый Terraform job из `terraform/_base.yaml` и запускается для
веток `main` или `master`. Job называется `terraform_apply`, использует runner с
тегом `sbl-mon`, забирает из Vault:

- `PGUSER` и `PGPASSWORD` для PostgreSQL backend;
- `KIBANA_PASSWORD`;
- `ELASTICSEARCH_PASSWORD`.

Потом job выставляет пользователей:

```bash
export KIBANA_USERNAME=elastic
export ELASTICSEARCH_USERNAME=elastic
```

И выполняет:

```bash
terraform init
terraform apply --auto-approve
```

То есть в текущем CI нет отдельного безопасного `terraform plan` job перед
apply. Merge или commit в `main/master` может сразу применить изменения.

Практический порядок такой:

1. В отдельной ветке добавить `s3stor.tf` и `bpmmq.tf`.
2. Проверить diff и, если есть доступ к штатному окружению, вручную получить
   `terraform plan`.
3. Перед merge убедиться, что ожидаются только новые `create` для `s3stor`, `bpmmq`
   и prod data views.
4. Понимать, что после merge в `main/master` GitLab job, скорее всего, выполнит
   `terraform apply --auto-approve`.

Если нет возможности посмотреть `plan` до merge, лучше согласовать запуск с
владельцем ELK/Terraform, потому что CI применяет изменения без ручного
подтверждения.

## Ручной запуск по аналогии с CI

Ручной запуск нужен только для проверки или согласованного применения. Команды
выполнять из Terraform-репозитория Elastic:

```bash
cd ~/devops/devops-repos/terraform/elasticstack
```

Не запускать из `bpmmq`, `fluxcd` или распакованного архива.

Перед запуском должны быть доступны те же секреты, которые CI берёт из Vault:

```bash
export PGUSER='<значение из Vault elasticstack/db-backend/PGUSER>'
export PGPASSWORD='<значение из Vault elasticstack/db-backend/PGPASSWORD>'
export KIBANA_USERNAME='elastic'
export KIBANA_PASSWORD='<значение из Vault elastic/elasticsearch/password>'
export ELASTICSEARCH_USERNAME='elastic'
export ELASTICSEARCH_PASSWORD='<значение из Vault elastic/elasticsearch/password>'
```

Секреты не записывать в `.tf`, `.tfvars`, shell history, README или commit.

Осторожный ручной порядок:

```bash
cd ~/devops/devops-repos/terraform/elasticstack

git status --short
git diff

terraform init
terraform fmt -check s3stor.tf bpmmq.tf
terraform plan -out=/tmp/elasticstack-s3stor-bpmmq.tfplan
terraform show -no-color /tmp/elasticstack-s3stor-bpmmq.tfplan | less
```

В `plan` по этой задаче должны быть только `create` для `s3stor`, `bpmmq` и prod
data views. Если есть `update`, `delete` или `replace` по чужим объектам,
останавливаться.

Apply вручную делать только после проверки plan:

```bash
terraform apply /tmp/elasticstack-s3stor-bpmmq.tfplan
```

После этого удалить локальный plan-файл:

```bash
rm -f /tmp/elasticstack-s3stor-bpmmq.tfplan
```

Не использовать `terraform apply --auto-approve` вручную. Не использовать
`terraform destroy`. Не использовать `terraform -target` для обычного применения.

## Как реализовать точку подключения для ручного запуска

Штатная точка запуска — GitLab runner `sbl-mon`. Он уже находится там, где есть
доступ к backend, Elasticsearch/Kibana и Vault.

Для ручного запуска есть три варианта.

### Вариант 1. Админская машина уже видит все адреса

Проверить:

```bash
getent hosts elasticsearch-es-http.elastic-stack.svc.cluster.local
getent hosts kibana-kb-http.elastic-stack.svc.cluster.local
nc -vz elasticsearch-es-http.elastic-stack.svc.cluster.local 9200
nc -vz kibana-kb-http.elastic-stack.svc.cluster.local 5601
nc -vz 10.77.189.208 5555
```

Если всё доступно, можно запускать Terraform с этой машины из каталога:

```bash
cd ~/devops/devops-repos/terraform/elasticstack
```

### Вариант 2. Elasticsearch/Kibana доступны через kubectl port-forward

Этот вариант подходит, если на админской машине есть рабочий `kubectl`, но
service DNS `*.svc.cluster.local` с хоста не резолвится.

Проверить service:

```bash
kubectl -n elastic-stack get svc elasticsearch-es-http kibana-kb-http
```

В двух отдельных терминалах поднять port-forward:

```bash
kubectl -n elastic-stack port-forward svc/elasticsearch-es-http 9200:9200
```

```bash
kubectl -n elastic-stack port-forward svc/kibana-kb-http 5601:5601
```

Так как `provider.tf` использует имена
`elasticsearch-es-http.elastic-stack.svc.cluster.local` и
`kibana-kb-http.elastic-stack.svc.cluster.local`, на время проверки можно
направить эти имена на localhost:

```bash
sudo cp /etc/hosts "/etc/hosts.$(date +%Y%m%d-%H%M%S).bak"
echo '127.0.0.1 elasticsearch-es-http.elastic-stack.svc.cluster.local kibana-kb-http.elastic-stack.svc.cluster.local' | sudo tee -a /etc/hosts
```

Проверить доступ:

```bash
curl -u "elastic:${ELASTICSEARCH_PASSWORD}" http://elasticsearch-es-http.elastic-stack.svc.cluster.local:9200
curl -u "elastic:${KIBANA_PASSWORD}" http://kibana-kb-http.elastic-stack.svc.cluster.local:5601/api/status
```

После работы убрать добавленную строку из `/etc/hosts` или вернуть backup.

Важно: это решает только доступ к Elasticsearch/Kibana. Доступ к PostgreSQL
backend `10.77.189.208:5555` всё равно нужен отдельно.

### Вариант 3. PostgreSQL backend доступен только через bastion

Если `10.77.189.208:5555` с админской машины не доступен, лучше использовать CI.
Если всё-таки согласован ручной запуск через bastion, можно поднять SSH tunnel
до того же backend:

```bash
ssh -L 127.0.0.1:5555:10.77.189.208:5555 <user>@<bastion>
```

Тогда Terraform init выполнять с временным backend config:

```bash
terraform init -reconfigure \
  -backend-config='conn_str=postgres://127.0.0.1:5555/terraform_elasticstack?sslmode=disable'
```

Так делать можно только если tunnel ведёт в тот же самый PostgreSQL backend.
Иначе Terraform будет работать не с тем state.

### Чего не делать

- Не заходить ради Terraform на Kubernetes master/worker без отдельной причины.
- Не коммитить изменения `provider.tf` только ради локального запуска.
- Не оставлять секреты в shell history, файлах или документации.
- Не запускать apply, пока не проверен сохранённый plan.

## Можно ли применить только один файл

Нет. Terraform не применяет отдельный `.tf` файл как самостоятельную единицу. Он
читает все `.tf` файлы в рабочей директории, сравнивает их с текущим state и
строит общий plan.

Флага "только создать и ничего не удалять" для обычного `terraform apply` нет.
Защита здесь — проверенный plan и применение именно этого plan через принятую у
вас процедуру Terraform/CI.

## Что должно быть в plan

Для основного prod-варианта ожидаются только новые `create`:

- `elasticstack_kibana_space.s3stor`;
- `elasticstack_kibana_space.bpmmq`;
- data view `app-minio-audit-prod`;
- data view `app-bpmmq-prod`.

Если в plan есть `update`, `delete` или `replace` по чужим объектам, plan не
применять. Сначала разобраться, почему Terraform хочет менять существующий
объект.

## Если space уже создан вручную

Если `s3stor` или `bpmmq` уже есть в Kibana, Terraform может попытаться создать
дубликат и получить ошибку. Тогда правильный путь — импортировать существующий
объект в Terraform state по вашей штатной процедуре, а не создавать его второй
раз.

Не удалять ручной объект без согласования с владельцем ELK.

resource "elasticstack_kibana_space" "bpmmq" {
  space_id          = "bpmmq"
  name              = "BPMMQ / RabbitMQ + HAProxy"
  disabled_features = ["enterpriseSearch","logs","infrastructure","apm","uptime","observabilityCases","slo","siem","securitySolutionCases","dev_tools","advancedSettings","indexPatterns","filesManagement","filesSharedImage","savedObjectsManagement","savedObjectsTagging","osquery","actions","generalCases","guidedOnboardingFeature","rulesSettings","maintenanceWindow","stackAlerts","fleetv2","fleet","monitoring"]
}

resource "elasticstack_kibana_data_view" "app-bpmmq-dev" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-bpmmq-dev-*"
    name = "app-bpmmq-dev"
    namespaces = [
      "bpmmq"
    ]
  }
}

resource "elasticstack_kibana_data_view" "app-bpmmq-ift" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-bpmmq-ift-*"
    name = "app-bpmmq-ift"
    namespaces = [
      "bpmmq"
    ]
  }
}

resource "elasticstack_kibana_data_view" "app-bpmmq-psi" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-bpmmq-psi-*"
    name = "app-bpmmq-psi"
    namespaces = [
      "bpmmq"
    ]
  }
}

resource "elasticstack_kibana_data_view" "app-bpmmq-prod" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-bpmmq-prod-*"
    name = "app-bpmmq-prod"
    namespaces = [
      "bpmmq"
    ]
  }
}

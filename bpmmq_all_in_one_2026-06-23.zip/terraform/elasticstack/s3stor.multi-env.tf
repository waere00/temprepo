resource "elasticstack_kibana_space" "s3stor" {
  space_id          = "s3stor"
  name              = "S3STOR / MinIO Audit"
  disabled_features = ["enterpriseSearch","logs","infrastructure","apm","uptime","observabilityCases","slo","siem","securitySolutionCases","dev_tools","advancedSettings","indexPatterns","filesManagement","filesSharedImage","savedObjectsManagement","savedObjectsTagging","osquery","actions","generalCases","guidedOnboardingFeature","rulesSettings","maintenanceWindow","stackAlerts","fleetv2","fleet","monitoring"]
}

resource "elasticstack_kibana_data_view" "app-minio-audit-dev" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-minio-audit-dev*"
    name = "app-minio-audit-dev"
    namespaces = [
      "s3stor"
    ]
  }
}

resource "elasticstack_kibana_data_view" "app-minio-audit-ift" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-minio-audit-ift*"
    name = "app-minio-audit-ift"
    namespaces = [
      "s3stor"
    ]
  }
}

resource "elasticstack_kibana_data_view" "app-minio-audit-psi" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-minio-audit-psi*"
    name = "app-minio-audit-psi"
    namespaces = [
      "s3stor"
    ]
  }
}

resource "elasticstack_kibana_data_view" "app-minio-audit-prod" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-minio-audit-prod*"
    name = "app-minio-audit-prod"
    namespaces = [
      "s3stor"
    ]
  }
}

resource "elasticstack_kibana_space" "bpmmq" {
  space_id          = "bpmmq"
  name              = "BPMMQ / RabbitMQ + HAProxy"
  disabled_features = ["enterpriseSearch","logs","infrastructure","apm","uptime","observabilityCases","slo","siem","securitySolutionCases","dev_tools","advancedSettings","indexPatterns","filesManagement","filesSharedImage","savedObjectsManagement","savedObjectsTagging","osquery","actions","generalCases","guidedOnboardingFeature","rulesSettings","maintenanceWindow","stackAlerts","fleetv2","fleet","monitoring"]
}

resource "elasticstack_kibana_data_view" "app-bpmmq-prod" {
  data_view = {
    allow_no_index = true
    time_field_name = "@timestamp"
    title = "app-bpmmq-prod-*"
    name = "app-bpmmq-prod"
    namespaces = [
      "bpmmq"
    ]
  }
}

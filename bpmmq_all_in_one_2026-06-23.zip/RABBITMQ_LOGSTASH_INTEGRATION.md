# Передача логов RabbitMQ + HAProxy в ELK

Документ описывает практическое внедрение логов BPMMQ: RabbitMQ, HAProxy и при
необходимости Keepalived.

## Текущая схема

Основной вариант сейчас — prod:

```text
RabbitMQ/HAProxy servers -> Filebeat -> logstash.sbl-mon.kub.rdleas.ru:5044 -> Logstash -> app-bpmmq-prod-<component> -> Kibana
```

Индексы:

```text
app-bpmmq-prod-rabbitmq
app-bpmmq-prod-haproxy
```

`elk/logstash-bpmmq-routing.conf` технически поддерживает `dev`, `ift`, `psi` и
`prod`, но текущие Filebeat-конфиги отправляют `env: prod`. Если отдельные
окружения не нужны, ничего менять не требуется.

## Почему Filebeat и порт 5044

RabbitMQ и HAProxy установлены из `.deb` пакетов и пишут обычные файловые логи.
Для них используем Filebeat:

- RabbitMQ: `/var/log/rabbitmq/*.log`;
- HAProxy: `/var/log/haproxy.log`;
- Keepalived/systemd при необходимости: фильтрованный `/var/log/syslog`.

Порт `5044` — это Beats/Filebeat input в Logstash.

Порты `8080` и `8081` здесь не используются:

- `8080` — общий HTTP input Logstash для других JSON-событий;
- `8081` — отдельный HTTP input для MinIO audit webhook.

## Готовые файлы

| Файл | Назначение |
|---|---|
| `elk/filebeat-bpmmq.yml` | Основной Filebeat-конфиг для установки через `.deb`/systemd. |
| `elk/filebeat-bpmmq.docker.yml` | Альтернативный Filebeat-конфиг для запуска в Docker. |
| `elk/docker-compose.filebeat.yml` | Пример Docker Compose для Filebeat. |
| `elk/logstash-bpmmq-routing.conf` | Ветки output для существующего Logstash pipeline. |
| `RABBITMQ_LOGSTASH_INTEGRATION.md` | Эта инструкция. |

## Что должно быть в Logstash

В центральном Logstash уже должен работать Beats/Filebeat-вход на `5044`.
Если Filebeat уже успешно отправляет события на
`logstash.sbl-mon.kub.rdleas.ru:5044`, этот вход не менять и второй
`beats { port => 5044 }` не добавлять.

Почему в `pipeline.conf` можно не увидеть `beats`: Logstash читает все `.conf`
файлы из `/usr/share/logstash/pipeline` как один pipeline. Вход `5044` может
приходить из другого файла в этом каталоге, например из дефолтного
`logstash.conf` внутри образа.

В `output` перед финальным fallback в индекс `logstash` должны быть маршруты из
файла:

```text
elk/logstash-bpmmq-routing.conf
```

Смысл маршрутов:

- тег `rabbitmq-bpmmq` -> `app-bpmmq-%{[env]}-rabbitmq`;
- тег `haproxy-bpmmq` или `keepalived-bpmmq` -> `app-bpmmq-%{[env]}-haproxy`;
- если `env` не `dev`, `ift`, `psi` или `prod`, событие не уходит в отдельный
  индекс и попадает в fallback `logstash`. Так проще заметить ошибку настройки.

Для текущей prod-настройки фактические индексы будут:

```text
app-bpmmq-prod-rabbitmq
app-bpmmq-prod-haproxy
```

## Что должно быть в ingress-nginx

Для внешнего доступа Filebeat к Logstash должен быть TCP-проброс:

```yaml
spec:
  values:
    controller:
      service:
        loadBalancerIP: "10.77.189.119"
    tcp:
      "5044": "logstash/logstash-logstash:5044"
```

Обычно это находится здесь:

```text
~/devops/devops-repos/fluxcd/infra-prerequisites/kub-sbl-mon/ingress-nginx/ingress-nginx-release-values.yaml
```

Если этого блока нет, `logstash.sbl-mon.kub.rdleas.ru:5044` может быть
недоступен с серверов.

## Filebeat через deb/systemd

Установить Filebeat из вашего репозитория пакетов или mirror.

Скопировать конфиг:

```bash
sudo cp /path/to/bpmmq/elk/filebeat-bpmmq.yml /etc/filebeat/filebeat.yml
sudo filebeat test config
sudo filebeat test output
sudo systemctl enable --now filebeat
sudo systemctl status filebeat --no-pager
```

В prod менять `env` не нужно: в конфиге уже стоит:

```yaml
fields:
  project: bpmmq
  env: prod
```

Если позже появится `dev`, `ift` или `psi`, заменить `env: prod` на нужное
значение на серверах соответствующего окружения и добавить data views/роли из
multi-env комплекта.

## Filebeat через Docker

Docker-вариант нужен только если в вашем контуре Filebeat обычно запускают в
контейнере. Основной вариант для серверов с `.deb` RabbitMQ/HAProxy — systemd.

Минимальная схема:

```bash
mkdir -p /opt/filebeat-bpmmq
cp /path/to/bpmmq/elk/filebeat-bpmmq.docker.yml /opt/filebeat-bpmmq/filebeat.yml
cp /path/to/bpmmq/elk/docker-compose.filebeat.yml /opt/filebeat-bpmmq/docker-compose.yml

cd /opt/filebeat-bpmmq
docker compose up -d
docker compose logs -f
```

В Docker Compose должны быть volume mount'ы:

- `/var/log:/var/log:ro`;
- отдельный volume для `/usr/share/filebeat/data`.

## Какие логи собираются

RabbitMQ:

```text
/var/log/rabbitmq/*.log
```

HAProxy:

```text
/var/log/haproxy.log
```

RabbitMQ Management HTTP access log:

```text
/var/log/rabbitmq/management-http/access.log*
```

Это не обычный лог RabbitMQ, а отдельный HTTP access log плагина
`rabbitmq_management`. Он относится только к RabbitMQ Management UI/API
на 15672/15671 и не описывает AMQP-трафик на 5672/5671.

По умолчанию RabbitMQ такие HTTP-запросы в отдельный access log не пишет.
Поэтому в `rabbitmq/rabbitmq.conf` параметра `management.http_log_dir` нет:
мы не включаем дополнительный per-node access log без явной потребности.
Базово достаточно HAProxy `httplog`, потому что Management UI/API ходит через
HAProxy и там видны клиентский IP, URI, HTTP-статус и backend-нода.

Filebeat input для `/var/log/rabbitmq/management-http/access.log*` оставлен как
готовая опция: если КБ попросит видеть именно access log на стороне RabbitMQ,
то включаем его на каждой RabbitMQ-ноде и Filebeat начнёт забирать эти файлы.

Включать только при необходимости:

```bash
sudo install -o rabbitmq -g rabbitmq -m 0750 -d /var/log/rabbitmq/management-http

sudo tee /etc/rabbitmq/conf.d/30-management-http-log.conf >/dev/null <<'EOF'
management.http_log_dir = /var/log/rabbitmq/management-http
EOF

sudo systemctl restart rabbitmq-server
sudo ls -l /var/log/rabbitmq/management-http
```

После включения отдельно проверьте ротацию этого каталога. Стандартный
`logrotate` из deb-пакета RabbitMQ обычно покрывает базовый каталог
`/var/log/rabbitmq`, но новую подпапку лучше проверить явно в
`/etc/logrotate.d/rabbitmq-server`.

Keepalived/systemd:

```text
/var/log/syslog
```

Этот input выключен по умолчанию и снабжён `include_lines`, чтобы не отправлять
весь syslog. Включать только на HAProxy/Keepalived-нодах, если нужны события
VRRP и состояния сервисов.

## Что проверить в центральном Logstash

В `devops-repos/fluxcd/infra/kub-sbl-mon/logstash/logstash-release-values.yaml`
для BPMMQ нужны две вещи.

Первое: убедиться, что Beats input на `5044` уже реально есть в live Logstash.
Не добавлять второй `beats { port => 5044 }` вслепую.

Почему это важно: Logstash читает все `.conf` файлы из
`/usr/share/logstash/pipeline` как один pipeline. В текущем chart/образе Beats
input может приходить не из `pipeline.conf`, а из другого файла в этом каталоге,
например дефолтного `logstash.conf` из образа. Тогда Filebeat уже работает на
`5044`, хотя в `pipeline.conf` виден только HTTP input `8080`.

Проверка в live-кластере:

```bash
kubectl -n logstash get pods
kubectl -n logstash exec <logstash-pod> -- sh -c 'ls -l /usr/share/logstash/pipeline && grep -R "beats" -n /usr/share/logstash/pipeline || true'
```

Если `filebeat test output` с RabbitMQ/HAProxy-сервера уже проходит до
`logstash.sbl-mon.kub.rdleas.ru:5044`, вход `5044` не трогать.

Второе: существующие ветки `else if [app] == ...` менять не нужно. Это старые
маршруты для приложений. BPMMQ-события лучше маршрутизировать по тегам
Filebeat, как уже сделано для похожих `rabbit-crm` / `haproxy-crm`:

```logstash
} else if "rabbitmq-bpmmq" in [tags] and [env] =~ "^(dev|ift|psi|prod)$" {
  elasticsearch {
    hosts => ["http://elasticsearch-es-http.elastic-stack.svc.cluster.local:9200"]
    user => '${username}'
    password => '${password}'
    index => "app-bpmmq-%{[env]}-rabbitmq"
    action => "create"
  }
} else if ("haproxy-bpmmq" in [tags] or "keepalived-bpmmq" in [tags]) and [env] =~ "^(dev|ift|psi|prod)$" {
  elasticsearch {
    hosts => ["http://elasticsearch-es-http.elastic-stack.svc.cluster.local:9200"]
    user => '${username}'
    password => '${password}'
    index => "app-bpmmq-%{[env]}-haproxy"
    action => "create"
  }
}
```

Эти ветки вставляются до финального fallback в индекс `logstash`.

## Проверка на серверах

На RabbitMQ-ноде:

```bash
sudo ls -l /var/log/rabbitmq/*.log
sudo filebeat test config
sudo filebeat test output
sudo systemctl status filebeat --no-pager
```

На HAProxy-ноде:

```bash
sudo ls -l /var/log/haproxy.log
sudo filebeat test config
sudo filebeat test output
sudo systemctl status filebeat --no-pager
```

Проверить доступ до Logstash:

```bash
nc -vz logstash.sbl-mon.kub.rdleas.ru 5044
```

## Проверка в Kibana

Для prod:

- RabbitMQ: `app-bpmmq-prod-rabbitmq*`;
- HAProxy/Keepalived: `app-bpmmq-prod-haproxy*`.

Поля, которые должны быть заполнены:

- `host.name`;
- `project=bpmmq`;
- `env=prod`;
- `component=rabbitmq`, `haproxy`, `rabbitmq-management` или `keepalived`;
- `tags` содержит `bpmmq` и один из тегов `rabbitmq-bpmmq`,
  `haproxy-bpmmq`, `keepalived-bpmmq`.

Если BPMMQ-события попадают в индекс `logstash`, проверить:

1. теги в Filebeat;
2. поле `env`;
3. наличие BPMMQ output routes в Logstash;
4. что Logstash принял события именно через Beats input `5044`.

## Kibana space и доступы

Для доставки логов новые роли Kibana не нужны. Logstash пишет существующим
пользователем из секрета `elastic-connection`.

Если нужен отдельный доступ на просмотр:

- `terraform/elasticstack/bpmmq.tf` создаёт space `bpmmq` и data view `app-bpmmq-prod`;
- `fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.snippet.yaml` содержит роль `user_bpmmq_prod`;
- `fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.snippet.yaml` содержит AD/SSO-группу `sbl_kub_kibana_bpmmq_prod`.

Multi-env варианты для будущего:

- `terraform/elasticstack/bpmmq.multi-env.tf`;
- `fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.multi-env.snippet.yaml`;
- `fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.multi-env.snippet.yaml`.

## Что проверять функционально

Минимальные тестовые события:

1. Перезапустить RabbitMQ на одной ноде в тестовом окне и проверить, что событие
   появилось в `app-bpmmq-prod-rabbitmq*`.
2. Остановить RabbitMQ на одной ноде и проверить HAProxy healthcheck DOWN/UP в
   `app-bpmmq-prod-haproxy*`.
3. Сделать неуспешный вход в RabbitMQ Management UI через VIP и проверить
   HAProxy access log.
4. Если включён RabbitMQ Management HTTP access log, проверить событие в
   RabbitMQ management input.

## Что не делать

- Не отправлять RabbitMQ/HAProxy файловые логи на `8080` или `8081`.
- Не переводить RabbitMQ/HAProxy в JSON только ради ELK.
- Не тащить весь `/var/log/syslog` без фильтра.
- Не применять Terraform как часть настройки Filebeat/Logstash route.
- Не менять `env: prod`, если отдельные окружения пока не нужны.

# MinIO audit webhook -> Logstash: prod-инструкция

Эта инструкция нужна для передачи MinIO audit-событий в prod Logstash.

Основной вариант сейчас только prod:

```text
MinIO -> https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod -> Logstash 8081 -> app-minio-audit-prod -> Kibana
```

Старый совместимый URL тоже оставлен и пишет туда же:

```text
https://logstash.sbl-mon.kub.rdleas.ru/minio-audit
```

`dev`, `ift` и `psi` в основной prod-инструкции не настраиваются. Если они позже
понадобятся, использовать отдельные multi-env файлы:

- `elk/logstash-minio-audit.multi-env.conf`;
- `elk/logstash-release-values.multi-env.prepared.yaml`;
- `logstash-minio-multi-env.patch`.

Основной prod-вариант и multi-env вариант не применять одновременно.

## Что меняется в Logstash

В `fluxcd` меняется один файл:

```text
infra/kub-sbl-mon/logstash/logstash-release-values.yaml
```

Prod patch делает следующее:

- добавляет отдельный HTTP input `8081` для MinIO audit webhook;
- добавляет pipeline `minio-audit.conf`;
- пишет события в индекс `app-minio-audit-prod`;
- добавляет ingress paths `/minio-audit/prod` и `/minio-audit`;
- исключает тег `minio-audit` из fallback-индекса `logstash`;
- не трогает общий HTTP input `8080`;
- не трогает Beats input `5044`;
- не заводит новые Kubernetes-секреты.

Почему отдельный `8081`: так MinIO audit не смешивается с текущим общим HTTP
input `8080`. При этом сортировка всё равно дополнительно идёт по тегу
`minio-audit`.

## Как применить готовый patch

В Ubuntu-среде распаковать архив вне `fluxcd`:

```bash
mkdir -p /tmp/logstash-minio-prod-package
unzip -o /path/to/logstash-minio-prod-package.zip -d /tmp/logstash-minio-prod-package
```

Зайти в свежий clone `fluxcd`:

```bash
cd ~/devops/devops-repos/fluxcd
git status --short
```

Проверить, что patch применится:

```bash
git apply --check /tmp/logstash-minio-prod-package/logstash-minio-prod.patch
```

Если команда ничего не вывела и завершилась без ошибки, применить patch:

```bash
git apply /tmp/logstash-minio-prod-package/logstash-minio-prod.patch
```

Проверить diff:

```bash
git diff --check -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml
git diff -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml
```

В diff должен измениться только файл:

```text
infra/kub-sbl-mon/logstash/logstash-release-values.yaml
```

Если `git apply --check` падает, patch не применять через силу. Значит живой
prod values уже отличается от файла, на котором готовился patch. Тогда открыть
для сравнения:

```text
/tmp/logstash-minio-prod-package/logstash-release-values.prepared.yaml
/tmp/logstash-minio-prod-package/logstash-minio-prod.patch
```

И перенести изменения вручную по разделам ниже.

## Что должно быть в values

### 1. Fallback-индекс

В существующем `pipeline.conf` есть общий output, который пишет неизвестные
события в индекс `logstash`. В его условие нужно добавить тег `minio-audit`.

Было примерно так:

```logstash
if !("dwh" in [tags] or "dwh-pp" in [tags]) {
```

Должно стать так:

```logstash
if !("dwh" in [tags] or "dwh-pp" in [tags] or "minio-audit" in [tags]) {
```

Смысл: MinIO audit должен попадать только в `app-minio-audit-prod`, а не
дублироваться в общий индекс `logstash`.

### 2. Pipeline `minio-audit.conf`

В `spec.values.logstashPipeline` добавить `minio-audit.conf`. Готовый полный
вариант лежит в файле:

```text
elk/logstash-minio-audit.conf
```

Ключевые признаки правильного prod-варианта:

```logstash
tags => ["minio-audit"]
```

```logstash
mutate {
  add_field => {
    "event_source" => "minio_audit"
    "component" => "minio"
    "env" => "prod"
  }
}
```

```logstash
index => "app-minio-audit-prod"
```

Pipeline намеренно удаляет `event.original`, полный `requestHeader`,
`responseHeader` и подписанные query-параметры `X-Amz-*`. Остальные
диагностические поля MinIO, включая `requestQuery`, `tags`, `rx/tx` и
`timeToResponse`, остаются в событии.

В prod-варианте не должно быть ветвления по `/minio-audit/dev`,
`/minio-audit/ift` или `/minio-audit/psi`.

Строку ниже не убирать:

```logstash
additional_codecs => { "application/json" => "plain" }
```

Она нужна, чтобы Logstash HTTP input принял JSON от MinIO как plain text, а
разбор JSON выполнил наш filter в поле `minio`.

### 3. Порт внутри pod

В `spec.values.extraPorts` добавить:

```yaml
      - name: minio-audit
        containerPort: 8081
```

Если рядом уже есть `http-input: 8080` и `beats-input: 5044`, их не менять.

### 4. Порт на Kubernetes Service

В `spec.values.service.ports` добавить:

```yaml
        - name: minio-audit
          port: 8081
          protocol: TCP
          targetPort: 8081
```

### 5. Ingress paths

В `spec.values.ingress.hosts[].paths` добавить пути перед общим `/`:

```yaml
            - path: /minio-audit/prod
              servicePort: '8081'
            - path: /minio-audit
              servicePort: '8081'
            - path: /
              servicePort: '8080'
```

Пути `/minio-audit/prod` и `/minio-audit` должны стоять выше `/`, чтобы запрос
не ушёл в общий HTTP input `8080`.

## Предчек перед commit

Редактировать Logstash pipeline опаснее обычного YAML: если в любом `.conf`
появится синтаксическая ошибка, новый pod Logstash может не стартовать.

Проверить YAML/Kustomize:

```bash
cd ~/devops/devops-repos/fluxcd

kubectl kustomize infra/kub-sbl-mon/logstash > /tmp/logstash-rendered.yaml
kubectl apply --dry-run=client -f /tmp/logstash-rendered.yaml
```

Проверить синтаксис Logstash:

```bash
cd ~/devops/devops-repos/fluxcd

bash /path/to/bpmmq/tools/check-logstash-values.sh \
  --values-file ./infra/kub-sbl-mon/logstash/logstash-release-values.yaml \
  --logstash-image docker.elastic.co/logstash/logstash:8.19.0
```

Успешный результат:

```text
Logstash config validation passed.
```

Если внутренний registry доступен, можно использовать образ из вашего контура:

```bash
bash /path/to/bpmmq/tools/check-logstash-values.sh \
  --values-file ./infra/kub-sbl-mon/logstash/logstash-release-values.yaml \
  --logstash-image docker.rdleas.ru/elastic/logstash:8.19.0
```

Если Docker недоступен, хотя бы извлечь pipeline-файлы и передать владельцам
ELK для проверки:

```bash
bash /path/to/bpmmq/tools/check-logstash-values.sh \
  --values-file ./infra/kub-sbl-mon/logstash/logstash-release-values.yaml \
  --skip-docker
```

## Как применить через Flux

Команды выполнять в настоящем рабочем репозитории Flux:

```bash
cd ~/devops/devops-repos/fluxcd

git status --short
git diff -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml

git add infra/kub-sbl-mon/logstash/logstash-release-values.yaml
git commit -m "Add MinIO audit webhook pipeline to Logstash"
git push
```

Если принято вручную ускорять Flux:

```bash
flux -n flux-system reconcile source git flux-system
flux -n flux-system reconcile kustomization infra --with-source
```

Если `flux` не установлен, дождаться штатной синхронизации или попросить
владельцев кластера выполнить reconcile.

## Проверка в Kubernetes

Read-only команды:

```bash
kubectl -n logstash get pods
kubectl -n logstash get svc logstash-logstash -o yaml
kubectl -n logstash get ingress logstash-logstash -o yaml
kubectl -n logstash logs statefulset/logstash-logstash --tail=200
```

Что должно быть видно:

- service содержит порт `8081`;
- ingress содержит paths `/minio-audit/prod` и `/minio-audit`;
- в логах Logstash нет ошибок компиляции pipeline;
- pod Logstash находится в рабочем состоянии.

Если namespace, имя `HelmRelease`, service или ingress отличаются:

```bash
kubectl get helmrelease -A | grep -i logstash
kubectl get svc -A | grep -i logstash
kubectl get ingress -A | grep -i logstash
```

## Smoke test endpoint

С машины, которой доступен ingress:

```bash
curl -k -X POST 'https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod' \
  -H 'Content-Type: application/json' \
  -d '{"version":"1","deploymentid":"smoke","time":"2026-06-08T09:00:00Z","api":{"name":"PutObject","status":"OK","statusCode":200,"bucket":"audit-smoke","object":"smoke.txt"},"remotehost":"10.10.10.10","requestID":"smoke-1","accessKey":"minio-smoke"}'
```

Ожидаемо:

- HTTP-ответ от Logstash без ошибки соединения;
- в Kibana появляется событие в `app-minio-audit-prod*`;
- событие не появляется в общем индексе `logstash`;
- у события есть поля `event_source=minio_audit`, `component=minio`,
  `env=prod`, `minio_api_name=PutObject`, `minio_bucket=audit-smoke`.

## Настройка MinIO

На каждой MinIO-ноде, если MinIO установлен как systemd-сервис через `.deb`,
добавить в `/etc/default/minio`:

```bash
MINIO_AUDIT_WEBHOOK_ENABLE=on
MINIO_AUDIT_WEBHOOK_ENDPOINT=https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod
MINIO_AUDIT_WEBHOOK_QUEUE_DIR=/var/lib/minio/audit-webhook-queue
MINIO_AUDIT_WEBHOOK_QUEUE_SIZE=100000
```

Создать каталог очереди:

```bash
sudo install -o minio-user -g minio-user -m 0750 -d /var/lib/minio/audit-webhook-queue
```

Если пользователь или группа сервиса MinIO называются иначе, вместо
`minio-user` указать фактические значения из unit-файла.

Перезапустить MinIO:

```bash
sudo systemctl restart minio
sudo systemctl status minio --no-pager
```

Проверить, что процесс получил переменные:

```bash
sudo sh -c 'tr "\0" "\n" < /proc/$(pidof minio)/environ | grep MINIO_AUDIT_WEBHOOK'
```

После этого выполнить обычные S3-действия через `mc` или приложение: создать
bucket, положить объект, прочитать объект, удалить объект. Эти действия должны
появиться в `app-minio-audit-prod*`.

Если audit включён на двух MinIO-нодах, разделять индексы по нодам не нужно.
Обе ноды пишут в один индекс `app-minio-audit-prod*`, а источник события
смотреть по полям:

- `minio_webhook_sender` — IP, с которого MinIO отправил webhook в Logstash;
- `minio_deployment_id` — deployment id MinIO;
- `host.name`, если он добавлен принимающей стороной или агентом;
- `minio_remotehost` — клиент, который обращался к MinIO.

`minio_webhook_sender` и `minio_remotehost` не одно и то же.

## Нужно ли создавать роли ELK

Для доставки событий в Logstash новые роли просмотра Kibana не нужны. Logstash
пишет в индекс `app-minio-audit-prod`, используя уже существующие `${username}`
и `${password}` из секрета Logstash `elastic-connection`.

Роли нужны только если надо выдать отдельный доступ пользователям в Kibana. Для
этого в комплекте есть:

- `terraform/elasticstack/s3stor.tf` — space `s3stor` и data view `app-minio-audit-prod`;
- `fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.snippet.yaml` — роль `user_s3stor_prod`;
- `fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.snippet.yaml` — маппинг AD/SSO-группы `sbl_kub_kibana_s3stor_prod`.

Terraform не запускать как часть Logstash-правки. Это отдельное изменение для
Kibana/Elastic объектов.

## Как откатить

Правильный откат — откатить GitOps commit в `fluxcd`. Не править руками live
ConfigMap, Service или Ingress: Flux/Helm вернёт их к состоянию из Git.

Если commit был отдельным:

```bash
cd ~/devops/devops-repos/fluxcd

git status --short
git log --oneline -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml
git revert <commit_sha_с_MinIO_pipeline>

git diff --check
kubectl kustomize infra/kub-sbl-mon/logstash > /tmp/logstash-rendered.yaml
kubectl apply --dry-run=client -f /tmp/logstash-rendered.yaml

git push
flux -n flux-system reconcile source git flux-system
flux -n flux-system reconcile kustomization infra --with-source
```

Если MinIO начал слать слишком много событий, можно сначала остановить отправку
на MinIO-нодах:

```bash
sudo cp /etc/default/minio "/etc/default/minio.$(date +%Y%m%d-%H%M%S).bak"
sudo sed -i 's/^MINIO_AUDIT_WEBHOOK_ENABLE=.*/MINIO_AUDIT_WEBHOOK_ENABLE=off/' /etc/default/minio
sudo systemctl restart minio
```

Новые audit-события за время отключения в Logstash не попадут.

## Что сказать владельцам Logstash

Короткий текст для передачи:

```text
Нужно добавить MinIO audit webhook в prod Logstash.
Готовый patch: logstash-minio-prod.patch.
Меняется только fluxcd/infra/kub-sbl-mon/logstash/logstash-release-values.yaml.

Endpoint для MinIO:
https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod

Индекс:
app-minio-audit-prod

Просьба перед commit выполнить:
git diff --check,
kubectl kustomize/apply --dry-run=client,
tools/check-logstash-values.sh с Logstash 8.19.0.

Terraform и роли Kibana не применять как часть Logstash-правки.
Они нужны только если отдельно требуется space/data view/доступы на просмотр.
```

## Источники

- MinIO audit webhook: https://docs.min.io/aistor/operations/monitoring/audit-logging/webhook-audit-logging/
- MinIO webhook audit settings: https://docs.min.io/aistor/reference/aistor-server/settings/metrics-and-logging/webhook-audit-logs/
- Logstash HTTP input: https://www.elastic.co/guide/en/logstash/current/plugins-inputs-http.html
- Logstash Beats input: https://www.elastic.co/docs/reference/logstash/plugins/plugins-inputs-beats

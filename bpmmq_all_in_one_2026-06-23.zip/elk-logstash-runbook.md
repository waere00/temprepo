# ELK и Logstash: рабочая карта

Этот runbook нужен, чтобы не смешивать три разные задачи:

1. доставка логов в Logstash;
2. создание Kibana spaces/data views;
3. выдача прав пользователям через роли и AD/SSO-группы.

## Текущее решение по окружениям

Основной вариант сейчас — только `prod`, но с явным `prod` в именах:

| Система | Индексы | Kibana space | Роль просмотра | AD/SSO-группа |
|---|---|---|---|---|
| MinIO/S3 audit | `app-minio-audit-prod*` | `s3stor` | `user_s3stor_prod` | `sbl_kub_kibana_s3stor_prod` |
| BPMMQ/RabbitMQ/HAProxy | `app-bpmmq-prod-*` | `bpmmq` | `user_bpmmq_prod` | `sbl_kub_kibana_bpmmq_prod` |

Если позже понадобятся `dev`, `ift` или `psi`, использовать файлы с суффиксом
`.multi-env`. Не смешивать prod-only и multi-env варианты в одном изменении.

## Где что настраивается

| Что нужно сделать | Где править | Комментарий |
|---|---|---|
| Logstash pipeline MinIO | `devops-repos/fluxcd/infra/kub-sbl-mon/logstash/logstash-release-values.yaml` | Добавляется HTTP input `8081`, pipeline `minio-audit.conf`, service port и ingress paths. |
| Logstash route BPMMQ | `devops-repos/fluxcd/infra/kub-sbl-mon/logstash/logstash-release-values.yaml` | Используется существующий Beats input `5044`; добавляются только маршруты по тегам `rabbitmq-bpmmq`, `haproxy-bpmmq`, `keepalived-bpmmq`. |
| Filebeat на ВМ | На самих RabbitMQ/HAProxy серверах | Отправляет host-логи в `logstash.sbl-mon.kub.rdleas.ru:5044`. |
| Kibana spaces/data views | `devops-repos/terraform/elasticstack/` | Terraform-правка, отдельная от Logstash. |
| Роли Kibana/Elasticsearch | `devops-repos/fluxcd/infra/kub-sbl-mon/elastic/elasticsearch-roles.yaml` | Роли вида `user_s3stor_prod`, `user_bpmmq_prod`. |
| AD/SSO-маппинг | `devops-repos/fluxcd/infra/kub-sbl-mon/elastic/oicdproxy-release.yaml` | Группы вида `sbl_kub_kibana_s3stor_prod` маппятся на роли. |

## Входы Logstash

| Порт | Для чего | Используем |
|---|---|---|
| `5044` | Beats/Filebeat | RabbitMQ/HAProxy host-логи. |
| `8080` | Общий HTTP JSON-вход | Не трогаем для MinIO. |
| `8081` | Отдельный HTTP-вход MinIO audit webhook | Добавляем для MinIO. |

Для MinIO не использовать `5044`: MinIO audit webhook — это HTTP POST, а не
Beats-протокол.

Важно по `5044`: не добавлять новый Beats input вслепую. Если `5044` уже
работает для Filebeat, значит Logstash уже слушает Beats-протокол. В этой схеме
input может быть не в `pipeline.conf`, а в другом `.conf` файле внутри
`/usr/share/logstash/pipeline`, например в дефолтном `logstash.conf` из образа.

Проверка live-конфига:

```bash
kubectl -n logstash get pods
kubectl -n logstash exec <logstash-pod> -- sh -c 'ls -l /usr/share/logstash/pipeline && grep -R "beats" -n /usr/share/logstash/pipeline || true'
```

Если `filebeat test output` проходит до
`logstash.sbl-mon.kub.rdleas.ru:5044`, input не менять. Для BPMMQ добавить
только output route по тегам `rabbitmq-bpmmq`, `haproxy-bpmmq`,
`keepalived-bpmmq`, как в файле `elk/logstash-bpmmq-routing.conf`. Поле `[app]`
для BPMMQ не задавать.

## Основные prod-файлы

Logstash/MinIO:

```text
elk/logstash-minio-audit.conf
elk/logstash-minio-audit.prod.conf
elk/logstash-release-values.prepared.yaml
logstash-minio-prod.patch
MINIO_LOGSTASH_PROD_INSTRUCTION.md
```

BPMMQ:

```text
RABBITMQ_LOGSTASH_INTEGRATION.md
elk/filebeat-bpmmq.yml
elk/filebeat-bpmmq.docker.yml
elk/logstash-bpmmq-routing.conf
```

Kibana/Elastic prod:

```text
terraform/elasticstack/s3stor.tf
terraform/elasticstack/bpmmq.tf
terraform-elasticstack-s3stor-bpmmq.patch
fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.snippet.yaml
fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.snippet.yaml
```

## Multi-env файлы на будущее

```text
elk/logstash-minio-audit.multi-env.conf
elk/logstash-release-values.multi-env.prepared.yaml
logstash-minio-multi-env.patch
terraform/elasticstack/s3stor.multi-env.tf
terraform/elasticstack/bpmmq.multi-env.tf
terraform-elasticstack-s3stor-bpmmq.multi-env.patch
fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.multi-env.snippet.yaml
fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.multi-env.snippet.yaml
```

## Проверка Logstash перед commit

В `fluxcd`:

```bash
cd ~/devops/devops-repos/fluxcd

git diff --check -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml
kubectl kustomize infra/kub-sbl-mon/logstash > /tmp/logstash-rendered.yaml
kubectl apply --dry-run=client -f /tmp/logstash-rendered.yaml
```

Проверка синтаксиса Logstash:

```bash
bash /path/to/bpmmq/tools/check-logstash-values.sh \
  --values-file ./infra/kub-sbl-mon/logstash/logstash-release-values.yaml \
  --logstash-image docker.elastic.co/logstash/logstash:8.19.0
```

Ожидаемый результат:

```text
Logstash config validation passed.
```

## Проверка MinIO после деплоя

```bash
curl -k -X POST 'https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod' \
  -H 'Content-Type: application/json' \
  -d '{"version":"1","deploymentid":"smoke","time":"2026-06-08T09:00:00Z","api":{"name":"PutObject","status":"OK","statusCode":200,"bucket":"audit-smoke","object":"smoke.txt"},"remotehost":"10.10.10.10","requestID":"smoke-1","accessKey":"minio-smoke"}'
```

Потом в Kibana:

- открыть data view `app-minio-audit-prod`;
- проверить событие smoke test;
- убедиться, что событие не попало в общий индекс `logstash`.

## Проверка BPMMQ после настройки Filebeat

В Kibana:

- RabbitMQ: `app-bpmmq-prod-rabbitmq*`;
- HAProxy/Keepalived: `app-bpmmq-prod-haproxy*`.

Проверить поля:

- `host.name`;
- `project=bpmmq`;
- `env=prod`;
- `component=rabbitmq`, `haproxy` или `keepalived`;
- `tags` содержит `rabbitmq-bpmmq`, `haproxy-bpmmq` или `keepalived-bpmmq`.

## Terraform для Kibana

Terraform-репозиторий:

```text
~/devops/devops-repos/terraform/elasticstack/
```

Запускать Terraform нужно из этого каталога. Не из `bpmmq`, не из `fluxcd`.
Именно здесь лежит `provider.tf`, который задаёт backend/state и адреса
Elasticsearch/Kibana.

Основной prod patch:

```bash
cd ~/devops/devops-repos/terraform/elasticstack

git status --short
git apply --check /path/to/bpmmq/terraform-elasticstack-s3stor-bpmmq.patch
git apply /path/to/bpmmq/terraform-elasticstack-s3stor-bpmmq.patch

terraform init
terraform fmt -check s3stor.tf bpmmq.tf
terraform plan
```

В plan должны быть только новые `create`:

- space `s3stor`;
- space `bpmmq`;
- data view `app-minio-audit-prod`;
- data view `app-bpmmq-prod`.

Если есть `update`, `delete` или `replace` по чужим объектам, plan не применять.

Если `terraform init` не может подключиться к backend `pg` или найти provider
`local/elasticstack`, запускать нужно из штатного CI/runner'а или с машины, где
уже настроены доступы и provider mirror. Если `plan` не может подключиться к
Elasticsearch/Kibana, значит нет сетевого доступа до сервисов кластера или не
переданы credentials.

По текущему `.gitlab-ci.yml` репозитория `terraform/elasticstack` подключается
шаблон:

```yaml
project: DevOps/cicd
file: terraform/elasticstack.yaml
```

В локальной копии `devops-repos/cicd/terraform/elasticstack.yaml` job
`terraform_apply` запускается на `main/master`, берёт секреты из Vault и делает:

```bash
terraform init
terraform apply --auto-approve
```

Это не plan-only pipeline. После merge в `main/master` изменения могут сразу
примениться. Поэтому до merge нужно отдельно убедиться, что Terraform создаст
только ожидаемые объекты.

Осторожный ручной запуск повторяет CI-переменные, но сначала сохраняет plan:

```bash
cd ~/devops/devops-repos/terraform/elasticstack

export PGUSER='<из Vault elasticstack/db-backend/PGUSER>'
export PGPASSWORD='<из Vault elasticstack/db-backend/PGPASSWORD>'
export KIBANA_USERNAME='elastic'
export KIBANA_PASSWORD='<из Vault elastic/elasticsearch/password>'
export ELASTICSEARCH_USERNAME='elastic'
export ELASTICSEARCH_PASSWORD='<из Vault elastic/elasticsearch/password>'

git status --short
terraform init
terraform fmt -check s3stor.tf bpmmq.tf
terraform plan -out=/tmp/elasticstack-s3stor-bpmmq.tfplan
terraform show -no-color /tmp/elasticstack-s3stor-bpmmq.tfplan | less
```

Если plan содержит только ожидаемые `create`, можно применить именно этот plan:

```bash
terraform apply /tmp/elasticstack-s3stor-bpmmq.tfplan
rm -f /tmp/elasticstack-s3stor-bpmmq.tfplan
```

Не запускать вручную `terraform apply --auto-approve`, `terraform destroy` или
`terraform -target` для этой задачи.

Точка подключения для ручного запуска:

1. Штатно — GitLab runner `sbl-mon`.
2. С админской машины — только если доступны:
   - PostgreSQL backend `10.77.189.208:5555`;
   - `elasticsearch-es-http.elastic-stack.svc.cluster.local:9200`;
   - `kibana-kb-http.elastic-stack.svc.cluster.local:5601`;
   - секреты из Vault.
3. Если service DNS недоступен с хоста, но есть `kubectl`, Elasticsearch/Kibana
   можно пробросить через port-forward:

```bash
kubectl -n elastic-stack port-forward svc/elasticsearch-es-http 9200:9200
kubectl -n elastic-stack port-forward svc/kibana-kb-http 5601:5601
```

И временно направить service DNS на localhost через `/etc/hosts`:

```text
127.0.0.1 elasticsearch-es-http.elastic-stack.svc.cluster.local kibana-kb-http.elastic-stack.svc.cluster.local
```

PostgreSQL backend этим не решается. Если backend доступен только через bastion:

```bash
ssh -L 127.0.0.1:5555:10.77.189.208:5555 <user>@<bastion>
terraform init -reconfigure \
  -backend-config='conn_str=postgres://127.0.0.1:5555/terraform_elasticstack?sslmode=disable'
```

Если tunnel не согласован или непонятно, куда он ведёт, ручной запуск не делать:
лучше использовать CI.

## Роли и AD/SSO-группы

Роли вставляются во `fluxcd`:

```text
infra/kub-sbl-mon/elastic/elasticsearch-roles.yaml
```

Группы вставляются во `fluxcd`:

```text
infra/kub-sbl-mon/elastic/oicdproxy-release.yaml
```

Смысл связки:

- `space:s3stor` или `space:bpmmq` — технический идентификатор Kibana space;
- `space_all` — набор прав внутри выбранного space;
- `user_s3stor_prod` и `user_bpmmq_prod` — внутренние роли Elasticsearch/Kibana;
- `sbl_kub_kibana_s3stor_prod` и `sbl_kub_kibana_bpmmq_prod` — внешние AD/SSO-группы.

AD/SSO-группы должны реально существовать во внешнем каталоге. Если их имена
будут другими, в `oicdproxy-release.yaml` указывать фактические имена.

## Откат Logstash-правки

Правильный откат — через Git:

```bash
cd ~/devops/devops-repos/fluxcd

git log --oneline -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml
git revert <commit_sha>
git diff --check
kubectl kustomize infra/kub-sbl-mon/logstash > /tmp/logstash-rendered.yaml
kubectl apply --dry-run=client -f /tmp/logstash-rendered.yaml
git push
```

Не править руками live ConfigMap, Service или Ingress: Flux/Helm вернёт их к
состоянию из Git.

## Чего не делать

- Не отправлять MinIO webhook на `5044`.
- Не переделывать общий HTTP input `8080` ради MinIO.
- Не применять Terraform как часть Logstash-правки.
- Не вставлять одновременно prod-only и multi-env snippets.
- Не коммитить zip-файлы в `fluxcd`.
- Не применять patch через силу, если `git apply --check` падает.

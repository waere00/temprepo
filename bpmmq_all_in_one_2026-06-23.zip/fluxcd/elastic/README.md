# Flux snippets для ролей Kibana

Эта папка содержит только сниппеты для вставки в текущие Flux-файлы:

```text
~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/elastic/elasticsearch-roles.yaml
~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/elastic/oicdproxy-release.yaml
```

Это не полные Kubernetes-манифесты. Не заменять ими существующие файлы целиком.

## Основной вариант: только prod

| Файл | Куда вставлять |
|---|---|
| `elasticsearch-roles.s3stor-bpmmq.snippet.yaml` | Внутрь `stringData.roles.yml` рядом с ролями `user_bprint_dev` / `user_bprint_prod`. |
| `oicdproxy-groups.s3stor-bpmmq.snippet.yaml` | Внутрь `values.kibana.rbac.adGroups` рядом с группами `sbl_kub_kibana_bprint_dev` / `sbl_kub_kibana_bprint_prod`. |

В основном варианте создаются только prod-роли:

- `user_s3stor_prod` читает `app-minio-audit-prod*` и даёт доступ к Kibana space `s3stor`;
- `user_bpmmq_prod` читает `app-bpmmq-prod-*` и даёт доступ к Kibana space `bpmmq`;
- AD/SSO-группа `sbl_kub_kibana_s3stor_prod` маппится на `user_s3stor_prod`;
- AD/SSO-группа `sbl_kub_kibana_bpmmq_prod` маппится на `user_bpmmq_prod`.

Названия AD/SSO-групп слева должны совпадать с фактическими группами во внешнем
каталоге. Если группы в AD назовут иначе, в `oicdproxy-release.yaml` нужно
указать фактические имена групп.

## Альтернатива: dev/ift/psi/prod

Если позже понадобятся отдельные права по окружениям, использовать multi-env
сниппеты:

- `elasticsearch-roles.s3stor-bpmmq.multi-env.snippet.yaml`;
- `oicdproxy-groups.s3stor-bpmmq.multi-env.snippet.yaml`.

Основной и multi-env варианты не надо вставлять одновременно: выбрать один.

## Где создаются spaces и data views

Spaces и data views создаются не здесь, а в Terraform:

```text
terraform/elasticstack/s3stor.tf
terraform/elasticstack/bpmmq.tf
```

Роли и AD/SSO-маппинг остаются во `fluxcd`, потому что текущая схема в
репозитории устроена именно так.

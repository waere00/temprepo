# ТЗ на Zabbix-мониторинг MinIO и BPMMQ

Актуализация: 2026-06-09.

Документ описывает простой достаточный мониторинг для:

- BPMMQ: RabbitMQ + HAProxy + Keepalived;
- MinIO;
- серверов, на которых эти компоненты работают.

Цель мониторинга - быстро увидеть недоступность сервиса, деградацию кластера,
проблемы с backend-нодами HAProxy, нехватку места и остановку системных
сервисов. Это не аудит действий пользователей и не глубокая аналитика
производительности. Аудит и журналы описаны отдельно в `AUDIT_LOGGING_CONFLUENCE.md`,
`MINIO_AUDIT_LOGGING_CONFLUENCE.md`, `RABBITMQ_LOGSTASH_INTEGRATION.md` и
`MINIO_LOGSTASH_INTEGRATION.md`.

## Короткая версия для заявки

Необходимо настроить базовый мониторинг в Zabbix:

1. На все серверы установить Zabbix agent 2 и подключить стандартный шаблон
   Linux.
2. Для системных сервисов использовать официальный шаблон
   `Systemd by Zabbix agent 2` и отслеживать только нужные службы:
   `rabbitmq-server.service`, `haproxy.service`, `keepalived.service`,
   `minio.service`.
3. Для RabbitMQ использовать официальный Zabbix-шаблон RabbitMQ через
   Management API. В проекте уже предусмотрен пользователь `zbx_monitor`.
4. Для HAProxy использовать официальный шаблон `HAProxy by Zabbix agent`.
   HAProxy stats page уже включена на `127.0.0.1:8404/stats`, поэтому ее лучше
   опрашивать локально через агент, не открывая наружу.
5. Для MinIO использовать web monitoring и healthcheck-адреса. Для
   продуктивного контура добавить несколько метрик из
   `/minio/metrics/v3/cluster/health`: отключенные ноды, отключенные диски и
   свободную полезную емкость.
6. Не включать на первом этапе сложные бизнес-проверки по очередям RabbitMQ,
   bucket-ам MinIO и синтетические S3-проверки `PUT/GET/DELETE`, пока нет
   понятных порогов и отдельной тестовой учетной записи.

## Общие требования

### Агент на серверах

На каждый Linux-сервер ставится `zabbix-agent2`.

Обязательные шаблоны для всех серверов:

- `Linux by Zabbix agent` или `Linux by Zabbix agent active` - выбрать вариант,
  который принят в текущем контуре Zabbix;
- `Systemd by Zabbix agent 2` - если в контуре уже используется agent 2.

Для шаблона `Systemd by Zabbix agent 2` рекомендуется ограничить discovery
только нужными службами, чтобы не создавать лишний шум:

```text
{$SYSTEMD.NAME.SERVICE.MATCHES}=^(rabbitmq-server|haproxy|keepalived|minio)\.service$
{$SYSTEMD.UNITFILESTATE.SERVICE.MATCHES}=^enabled$
```

Если в вашей версии Zabbix шаблон Systemd уже настроен централизованно и
фильтрует только enabled-сервисы, можно оставить существующую настройку.

### Периодичность проверок

Базовые значения:

- обычные проверки доступности: 1 раз в минуту;
- timeout HTTP/TCP проверок: 5 секунд;
- срабатывание аварии: после 3 неудачных проверок подряд или по условию шаблона;
- сбор ресурсных метрик: как в стандартном Linux-шаблоне;
- сбор MinIO-метрик в формате Prometheus: 1 раз в минуту или 1 раз в 5 минут.

Смысл этих значений: не ловить единичный сетевой чих, но увидеть реальную
проблему в течение нескольких минут.

### Секреты

Пароли и токены не записывать в файлы проекта и не вставлять в описание хостов
открытым текстом. В Zabbix хранить их в макросах хоста или шаблона с типом
`Secret`, если такая возможность включена в вашей версии.

## Объекты BPMMQ

### RabbitMQ-ноды

В текущем проекте используются:

```text
dp-bpmmqbrok01.rdleas.ru
pp-bpmmqbrok02.rdleas.ru
cp-bpmmqbrok03.rdleas.ru
```

Для каждой RabbitMQ-ноды создать отдельный host в Zabbix.

Шаблоны:

- `Linux by Zabbix agent` или `Linux by Zabbix agent active`;
- `Systemd by Zabbix agent 2`;
- `RabbitMQ node by HTTP`.

Макросы на каждой RabbitMQ-ноде:

```text
{$RABBITMQ.API.SCHEME}=http
{$RABBITMQ.API.HOST}=<FQDN конкретной RabbitMQ-ноды>
{$RABBITMQ.API.PORT}=15672
{$RABBITMQ.API.USER}=zbx_monitor
{$RABBITMQ.API.PASSWORD}=<пароль zbx_monitor>
{$RABBITMQ.CLUSTER.NAME}=rabbit
```

Пример для первой ноды:

```text
{$RABBITMQ.API.HOST}=dp-bpmmqbrok01.rdleas.ru
```

В `rabbitmq/definitions.json` пользователь `zbx_monitor` уже описан с тегом
`monitoring` и read-only permissions на `/` и `bpmmq`. Этого достаточно для
Zabbix-шаблонов через RabbitMQ Management API.

Что должны давать эти проверки:

| Что проверяем | Как проверяем | Авария |
| --- | --- | --- |
| Management API конкретной ноды доступен | официальный RabbitMQ-шаблон | API не отвечает несколько минут |
| RabbitMQ-нода запущена | элемент данных шаблона `rabbitmq.node.running` | нода не работает |
| Сетевое разделение кластера | элемент данных шаблона `rabbitmq.node.partitions` | partitions больше 0 |
| Memory alarm RabbitMQ | элемент данных шаблона `rabbitmq.node.mem_alarm` | RabbitMQ включил memory alarm |
| Disk free alarm RabbitMQ | элемент данных шаблона `rabbitmq.node.disk_free_alarm` | RabbitMQ включил disk alarm |
| Виртуальные хосты работают | healthcheck-проверки RabbitMQ из шаблона | есть неработающие vhost |
| Сервис ОС работает | `Systemd by Zabbix agent 2` | `rabbitmq-server.service` не в состоянии active |

### RabbitMQ-кластер и VIP

Для общей проверки кластера создать отдельный host, например:

```text
bpmmq-cluster
```

Шаблоны:

- `RabbitMQ cluster by HTTP`.

Макросы:

```text
{$RABBITMQ.API.SCHEME}=http
{$RABBITMQ.API.CLUSTER_HOST}=bpmmq.rdleas.ru
{$RABBITMQ.API.PORT}=15672
{$RABBITMQ.API.USER}=zbx_monitor
{$RABBITMQ.API.PASSWORD}=<пароль zbx_monitor>
```

Дополнительно создать простые внешние проверки через VIP:

| Проверка | Адрес | Ожидаемый результат |
| --- | --- | --- |
| AMQP порт доступен клиентам | `bpmmq.rdleas.ru:5672` | TCP connect успешен |
| Management API через балансировщик доступен | `http://bpmmq.rdleas.ru:15672/api/health/checks/ready-to-serve-clients` | HTTP 200 |
| Большинство RabbitMQ-нод доступно | `http://<broker-node>:15672/api/nodes?columns=name,running` | Минимум 2 записи с `"running":true` |

Для проверки Management API через VIP использовать basic-аутентификацию с пользователем
`zbx_monitor` или `haproxy_monitor`.

Важно: `/api/health/checks/ready-to-serve-clients` проверяет локальную готовность
конкретной RabbitMQ-ноды и сам по себе не доказывает, что 3-нодовый quorum-кластер
сохранил большинство. Поэтому для RabbitMQ-кластера отдельно контролируем
`/api/nodes?columns=name,running` и/или состояние backend-серверов HAProxy.

Прямую AMQP-проверку `:5672` на broker-ноды делать не надо. В проекте включен
`proxy_protocol = true`, поэтому нормальный путь клиента - только через
`bpmmq.rdleas.ru:5672`.

### Очереди RabbitMQ

На первом этапе не задавать жесткие триггеры на размер всех очередей.

Причина простая: без знания нормальной нагрузки легко получить шумные аварии.
Официальный RabbitMQ-шаблон умеет видеть очереди и сообщения, но пороги по
очередям нужно включать только для известных критичных очередей.

Минимально достаточно:

- видеть общее количество сообщений;
- видеть, что потребители сообщений не пропали, если для конкретной очереди это
  известно;
- включать отдельные триггеры по очередям только после согласования порогов с
  владельцами приложения.

## Объекты HAProxy и Keepalived

### HAProxy-серверы

В текущем проекте используются:

```text
dp-bpmmqbal01.rdleas.ru
pp-bpmmqbal02.rdleas.ru
```

Для каждого HAProxy-сервера создать отдельный host в Zabbix.

Шаблоны:

- `Linux by Zabbix agent` или `Linux by Zabbix agent active`;
- `Systemd by Zabbix agent 2`;
- `HAProxy by Zabbix agent`.

Макросы для `HAProxy by Zabbix agent`:

```text
{$HAPROXY.STATS.SCHEME}=http
{$HAPROXY.STATS.HOST}=127.0.0.1
{$HAPROXY.STATS.PORT}=8404
{$HAPROXY.STATS.PATH}=stats
{$HAPROXY.USERNAME}=admin
{$HAPROXY.PASSWORD}=<пароль из stats auth>
```

В `haproxy/haproxy.cfg` stats page уже настроена так:

```text
http://127.0.0.1:8404/stats
```

Поэтому рекомендуемый вариант - опрашивать stats локально через Zabbix agent 2.
Открывать `8404` наружу не требуется.

Что должны давать эти проверки:

| Что проверяем | Как проверяем | Авария |
| --- | --- | --- |
| HAProxy работает | `Systemd by Zabbix agent 2` | `haproxy.service` не active |
| HAProxy stats доступны | официальный HAProxy-шаблон | stats page не отвечает |
| RabbitMQ backend-нода в состоянии DOWN | официальный HAProxy-шаблон | один backend-сервер DOWN |
| Все RabbitMQ backend-ноды недоступны | официальный HAProxy-шаблон или отдельный триггер по backend | нет доступных backend-серверов |
| HAProxy был перезапущен | официальный HAProxy-шаблон | информационное событие |

Важные backend-ы из текущего HAProxy-конфига:

```text
rabbitmq_amqp
rabbitmq_mgmt
```

Для одной backend-ноды в состоянии DOWN достаточно уровня `Warning` или
`Average`. Если все backend-ноды в `rabbitmq_amqp` или `rabbitmq_mgmt`
недоступны, это уже `High`, потому что сервис недоступен через балансировщик.

### Keepalived и VIP

Для Keepalived не нужен сложный мониторинг VRRP-состояний на первом этапе.

Достаточно:

| Что проверяем | Как проверяем | Авария |
| --- | --- | --- |
| Keepalived service работает | `Systemd by Zabbix agent 2` | `keepalived.service` не active |
| VIP доступен клиентам | внешняя TCP/HTTP проверка `bpmmq.rdleas.ru` | VIP не отвечает |

Не надо делать триггер "VIP отсутствует на резервном балансировщике". Для
резервного балансировщика это нормальное состояние. Важнее, чтобы сам VIP был
доступен извне.

## Объекты MinIO

В этом репозитории нет фактических MinIO-адресов, поэтому ниже используются
плейсхолдеры. При внедрении заменить их на реальные значения:

```text
<minio-vip-or-dns>
<minio-node1>
<minio-node2>
<minio-node3>
...
```

Обычно MinIO API слушает порт `9000`. Если в вашем контуре другой порт или TLS,
заменить `http` на `https` и указать реальный порт.

### MinIO-серверы

Для каждого MinIO-сервера создать отдельный host в Zabbix.

Шаблоны:

- `Linux by Zabbix agent` или `Linux by Zabbix agent active`;
- `Systemd by Zabbix agent 2`.

Сервис:

```text
minio.service
```

Web monitoring на каждой MinIO-ноде:

| Проверка | URL | Ожидаемый результат |
| --- | --- | --- |
| Нода доступна | `http://<minio-node>:9000/minio/health/live` | HTTP 200 |
| Нода готова обслуживать запросы | `http://<minio-node>:9000/minio/health/ready` | HTTP 200 |

Смысл:

- `/live` показывает, что процесс MinIO на конкретной ноде жив;
- `/ready` показывает, что конкретная нода готова обслуживать запросы.

### MinIO-кластер

Создать отдельный host, например:

```text
minio-cluster
```

Web monitoring через балансировщик или общий DNS:

| Проверка | URL | Ожидаемый результат | Уровень в Zabbix |
| --- | --- | --- | --- |
| Готовность кластера к записи | `http://<minio-vip-or-dns>:9000/minio/health/cluster` | HTTP 200 | High |
| Готовность кластера к чтению | `http://<minio-vip-or-dns>:9000/minio/health/cluster/read` | HTTP 200 | High |

Смысл:

- `/cluster` проверяет, хватает ли online-нод и здоровых дисков для записи;
- `/cluster/read` проверяет, хватает ли online-нод и здоровых дисков для чтения.

HTTP 429 означает критическую нагрузку на сервер. HTTP 503 означает, что
недостаточно online-нод или здоровых дисков для соответствующей операции.

Параметр `?distributed=true` в базовый мониторинг не включаем. Он полезен для
ручной диагностики, когда нужно проверить взгляд всех нод на состояние кластера,
но для простого постоянного мониторинга достаточно обычных healthcheck-адресов
и отдельных проверок каждой ноды.

### Метрики MinIO в формате Prometheus

Для продуктивного контура рекомендуется добавить несколько MinIO-метрик через
элемент данных типа `HTTP agent` и обработку Prometheus-формата в Zabbix. Это не
усложняет схему, но закрывает важный случай: кластер может еще отвечать HTTP
200, хотя один диск или одна нода уже в состоянии offline.

Основной элемент данных:

```text
URL: http://<minio-vip-or-dns>:9000/minio/metrics/v3/cluster/health
Метод: GET
```

Если MinIO использует TLS:

```text
URL: https://<minio-vip-or-dns>:9000/minio/metrics/v3/cluster/health
```

По умолчанию MinIO требует авторизацию для адресов метрик. Не использовать
учетные данные root или администратора. Создать отдельный access key только с
правом `admin:Prometheus` и сгенерировать bearer token:

```bash
mc admin prometheus generate <minio-prometheus-alias> --api-version v3
```

В элемент данных Zabbix добавить HTTP-заголовок:

```text
Authorization: Bearer <TOKEN>
```

Минимальные зависимые элементы данных:

| Метрика | Что означает | Триггер |
| --- | --- | --- |
| `minio_cluster_health_nodes_offline_count` | Сколько MinIO-нод в состоянии offline | `> 0` = Average |
| `minio_cluster_health_drives_offline_count` | Сколько дисков в состоянии offline | `> 0` = Average |
| `minio_cluster_health_capacity_usable_free_bytes` | Свободная полезная емкость | участвует в расчете процента |
| `minio_cluster_health_capacity_usable_total_bytes` | Общая полезная емкость | участвует в расчете процента |

Для процента свободной емкости добавить вычисляемый элемент данных:

```text
usable_free_percent = usable_free_bytes / usable_total_bytes * 100
```

Триггеры:

| Условие | Уровень в Zabbix |
| --- | --- |
| `usable_free_percent < 15` | Warning |
| `usable_free_percent < 10` | Average или High |

В dev-окружении можно ограничиться healthcheck-адресами и проверками дисков
через Linux-шаблон.
В продуктивном контуре лучше добавить эти четыре MinIO-метрики.

### Что не включаем для MinIO на первом этапе

Не включаем без отдельной договоренности:

- синтетические S3-проверки `PUT/GET/DELETE` через тестовый bucket;
- проверки по каждому bucket;
- пороги по задержке и количеству запросов;
- проверки replication, lifecycle, object-lock, если эти функции не используются
  в конкретном контуре.

Причина: для этого нужны бизнес-пороги, отдельная учетная запись и понимание,
какие bucket-ы действительно критичны.

## Рекомендуемые уровни в Zabbix

| Событие | Уровень в Zabbix |
| --- | --- |
| Zabbix agent недоступен на сервере | Average |
| ОС почти без свободного места | Warning/Average по стандартному Linux-шаблону |
| `rabbitmq-server.service`, `haproxy.service`, `keepalived.service`, `minio.service` остановлен | Average |
| RabbitMQ-нода не работает | Average |
| Сетевое разделение RabbitMQ-кластера | High |
| RabbitMQ memory alarm или disk alarm | Average |
| RabbitMQ VIP `:5672` недоступен | High |
| RabbitMQ Management API через VIP недоступен | Average |
| HAProxy backend-нода DOWN, но есть другие живые backend-ноды | Warning |
| HAProxy backend полностью недоступен | High |
| VIP BPMMQ недоступен | High |
| MinIO-нода не отвечает на `/live` или `/ready` | Average |
| MinIO-кластер не готов к чтению или записи | High |
| В MinIO есть offline-диски | Average |
| В MinIO есть offline-ноды | Average |
| Свободная полезная емкость MinIO ниже 15% | Warning |
| Свободная полезная емкость MinIO ниже 10% | Average или High |

## Порядок внедрения

1. Установить и зарегистрировать `zabbix-agent2` на всех RabbitMQ, HAProxy и
   MinIO-серверах.
2. Создать или проверить группы хостов:
   - `BPMMQ/RabbitMQ`;
   - `BPMMQ/HAProxy`;
   - `BPMMQ/Synthetic`;
   - `MinIO`;
   - `MinIO/Synthetic`.
3. Подключить Linux-шаблон ко всем серверам.
4. Подключить `Systemd by Zabbix agent 2` и ограничить discovery нужными
   сервисами.
5. На RabbitMQ-ноды подключить `RabbitMQ node by HTTP` и задать макросы
   `{$RABBITMQ.*}`.
6. На отдельный host `bpmmq-cluster` подключить `RabbitMQ cluster by HTTP`.
7. На HAProxy-ноды подключить `HAProxy by Zabbix agent` и задать макросы
   `{$HAPROXY.*}`.
8. Добавить web/TCP проверки для `bpmmq.rdleas.ru:5672`,
   `http://bpmmq.rdleas.ru:15672/api/health/checks/ready-to-serve-clients` и
   `/api/nodes?columns=name,running` на broker-нодах или cluster host.
9. На MinIO-ноды добавить web-сценарии `/minio/health/live` и
   `/minio/health/ready`.
10. На хост `minio-cluster` добавить web-сценарии `/minio/health/cluster` и
    `/minio/health/cluster/read`.
11. Для продуктивного MinIO добавить элемент данных типа `HTTP agent` на
    `/minio/metrics/v3/cluster/health` и четыре зависимых элемента данных из
    раздела выше.
12. Проверить, что первые данные появились в разделе `Latest data`
    ("Последние данные") и что нет неподдерживаемых элементов данных.

## Приемка

Минимальная приемка считается выполненной, если:

1. Все RabbitMQ, HAProxy и MinIO-серверы видны в Zabbix, агент доступен.
2. По каждому серверу собираются метрики CPU, RAM, файловых систем и сети.
3. Zabbix видит состояние сервисов `rabbitmq-server`, `haproxy`, `keepalived`,
   `minio`.
4. RabbitMQ-шаблон получает данные с каждой broker-ноды.
5. RabbitMQ VIP проверяется по `5672/tcp`, Management API healthcheck и
   проверке большинства `/api/nodes?columns=name,running`.
6. HAProxy-шаблон видит frontend/backend и backend-серверы RabbitMQ.
7. MinIO healthcheck-адреса возвращают данные по каждой ноде и по кластеру.
8. Для продуктивного MinIO видны значения offline-nodes, offline-drives и
   свободной полезной емкости.
9. При остановке тестовой службы или временном закрытии healthcheck-адреса Zabbix
   создает ожидаемую проблему и закрывает ее после восстановления.

## Источники

- Zabbix RabbitMQ integration: https://www.zabbix.com/integrations/rabbitmq
- Zabbix HAProxy integration: https://www.zabbix.com/integrations/haproxy
- Zabbix Systemd by Zabbix agent 2: https://www.zabbix.com/integrations/systemd
- Zabbix web monitoring: https://www.zabbix.com/documentation/8.0/en/manual/web_monitoring
- Zabbix Prometheus check: https://www.zabbix.com/documentation/current/en/manual/config/items/itemtypes/http/prometheus
- MinIO healthcheck probes: https://docs.min.io/aistor/operations/monitoring/healthcheck-probe/
- MinIO metrics v3: https://docs.min.io/aistor/operations/monitoring/metrics-and-alerts/
- MinIO `mc admin prometheus generate`: https://docs.min.io/aistor/reference/cli/admin/mc-admin-prometheus/mc-admin-prometheus-generate/

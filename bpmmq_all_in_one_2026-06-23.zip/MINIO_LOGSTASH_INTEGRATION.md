# Интеграция MinIO audit webhook с Logstash

Документ объясняет схему MinIO audit webhook -> Logstash -> Elasticsearch/Kibana
и показывает, какие файлы использовать.

## Принятое решение

Основная схема сейчас prod-only:

```text
MinIO node 1/2 -> https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod -> Logstash HTTP 8081 -> app-minio-audit-prod -> Kibana data view app-minio-audit-prod
```

Совместимый URL:

```text
https://logstash.sbl-mon.kub.rdleas.ru/minio-audit
```

Он тоже пишет в `app-minio-audit-prod`.

`dev`, `ift` и `psi` пока не включаем в основную схему. Чтобы сохранить
возможность расширения, рядом лежат отдельные multi-env файлы. Их использовать
только если реально понадобится разделение окружений.

## Почему отдельный вход 8081

В текущем Logstash уже есть общий HTTP input `8080` для других JSON-событий.
MinIO audit webhook лучше принимать на отдельный HTTP input `8081`, потому что:

- проще проверить, что MinIO-события не попали в чужой pipeline;
- проще не задеть существующие события на `8080`;
- можно явно исключить `minio-audit` из fallback-индекса `logstash`;
- troubleshooting становится понятнее: MinIO приходит на `/minio-audit/prod` и `8081`.

Beats input `5044` не используется для MinIO audit webhook. Он нужен для
Filebeat, например для RabbitMQ/HAProxy host-логов.

## Какие файлы относятся к prod-варианту

| Файл | Назначение |
|---|---|
| `elk/logstash-minio-audit.conf` | Чистый Logstash pipeline для prod. |
| `elk/logstash-minio-audit.prod.conf` | То же самое, сохранено с явным суффиксом prod. |
| `elk/logstash-release-values.prepared.yaml` | Полный подготовленный values-файл из актуального `fluxcd` после prod-правки. |
| `logstash-minio-prod.patch` | Patch для `devops-repos/fluxcd`. |
| `tools/check-logstash-values.sh` | Проверка синтаксиса Logstash pipeline из values-файла. |
| `MINIO_LOGSTASH_PROD_INSTRUCTION.md` | Пошаговая инструкция применения. |

Prod-вариант пишет только в:

```text
app-minio-audit-prod
```

## Какие файлы относятся к multi-env варианту

| Файл | Назначение |
|---|---|
| `elk/logstash-minio-audit.multi-env.conf` | Pipeline с выбором окружения по URL `/minio-audit/dev`, `/ift`, `/psi`, `/prod`. |
| `elk/logstash-release-values.multi-env.prepared.yaml` | Полный values-файл для multi-env варианта. |
| `logstash-minio-multi-env.patch` | Patch для multi-env варианта. |

Multi-env вариант пишет в:

```text
app-minio-audit-dev
app-minio-audit-ift
app-minio-audit-psi
app-minio-audit-prod
```

Основной и multi-env варианты не надо применять одновременно.

## Что уже должно быть в devops

Проверяемые места:

| Файл | Что проверить |
|---|---|
| `~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/logstash/logstash-release-values.yaml` | Основной файл Logstash Helm values. Здесь добавляется pipeline, порт `8081`, service port и ingress paths. |
| `~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/logstash/kustomization.yaml` | Проверить, что `logstash-release-values.yaml` подключён как patch. |
| `~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/kustomization.yaml` | Проверить, что каталог `logstash` входит в overlay `kub-sbl-mon`. |
| `~/devops/devops-repos/terraform/elasticstack/` | Отдельный репозиторий для Kibana spaces/data views. Для Logstash pipeline не нужен. |
| `~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/elastic/elasticsearch-roles.yaml` | Роли просмотра Kibana. Для доставки событий в Logstash не нужен. |
| `~/devops/devops-repos/fluxcd/infra/kub-sbl-mon/elastic/oicdproxy-release.yaml` | Маппинг AD/SSO-групп на роли. Для доставки событий в Logstash не нужен. |

## Что именно делает prod pipeline

1. Принимает HTTP POST от MinIO на `8081`.
2. Разбирает JSON в поле `minio`.
3. Добавляет поля:
   - `event_source=minio_audit`;
   - `component=minio`;
   - `env=prod`.
4. Выносит часто нужные поля наверх:
   - `minio_access_key`;
   - `minio_api_name`;
   - `minio_api_status`;
   - `minio_api_status_code`;
   - `minio_bucket`;
   - `minio_object`;
   - `minio_parent_user`;
   - `minio_remotehost`;
   - `minio_request_host`;
   - `minio_request_path`;
   - `minio_request_id`;
   - `minio_trigger`;
   - `minio_user_agent`;
   - `minio_webhook_sender`.
5. Убирает чувствительные и шумные части:
   - `event.original`, то есть полный сырой JSON события;
   - `requestHeader`;
   - `responseHeader`;
   - подписанные query-параметры `X-Amz-Signature`, `X-Amz-Security-Token`,
     `X-Amz-Credential`.
6. Берёт `@timestamp` из `minio.time`.
7. Пишет событие в `app-minio-audit-prod`.

Этого достаточно для заявлений в Confluence: кто обращался, каким ключом, к
какому bucket/object, какая операция, какой статус, откуда пришёл клиент и когда
это произошло.

## Две MinIO-ноды

Обе MinIO-ноды отправляют audit webhook в один endpoint:

```text
https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod
```

Разделять индексы по нодам не нужно. Источник события можно смотреть по полям:

- `minio_webhook_sender` — IP отправителя webhook, то есть MinIO-ноды;
- `minio_deployment_id` — deployment id MinIO;
- `minio_remotehost` — клиент, который обращался к MinIO.

Если одна реплика почти простаивает, это нормально: событий от неё будет меньше.
В одном индексе всё равно видно, какая нода отправила конкретное событие.

## Насколько подробные будут логи

MinIO audit webhook достаточно подробный для базового аудита S3-операций:

- операция API;
- bucket/object;
- access key;
- статус и HTTP-код;
- request id;
- время;
- клиентский адрес;
- user agent;
- нода, отправившая webhook.

Мы сознательно не сохраняем полный `event.original`, `requestHeader` и
`responseHeader`, потому что там могут быть подписи и авторизационные данные.
Но диагностические поля MinIO оставляем: `requestQuery` без подписанных
параметров, `tags`, `rx`, `tx`, `txHeaders`, `timeToFirstByte`,
`timeToResponse`. Если потом понадобится разбирать странное поведение MinIO,
смотреть будет где.

Увеличивать подробность сейчас не нужно. Уменьшать сильнее тоже не стоит:
если убрать `accessKey`, `api.name`, `bucket`, `object`, `remotehost` или
`statusCode`, станет сложнее отвечать на базовые вопросы аудита.

События вроде `SiteReplicationMetaInfo` не фильтруем. Для обычного аудита они
шумные, потому что это служебные запросы MinIO site replication, а не действие
прикладного пользователя. Но для диагностики они полезны: по ним видно, что
репликационный служебный ключ обращался к metadata endpoint, с какого узла
пришёл запрос, к какому bucket/entity он относился и с каким статусом завершился.
Если репликация начнёт вести себя странно, эти события могут помочь восстановить
картину после инцидента.

## Kibana, Terraform и роли

Для самой доставки событий новые роли Kibana не нужны. Logstash пишет в индекс
`app-minio-audit-prod` существующим пользователем из секрета Logstash.

Если нужен отдельный просмотр логов в Kibana:

- space `s3stor` и data view `app-minio-audit-prod` описаны в `terraform/elasticstack/s3stor.tf`;
- роль `user_s3stor_prod` описана в `fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.snippet.yaml`;
- AD/SSO-группа `sbl_kub_kibana_s3stor_prod` описана в `fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.snippet.yaml`.

Terraform применять отдельно от Logstash-правки. В plan должны быть только
новые `create`; любые `update`, `delete` или `replace` по чужим объектам — стоп.

## Как применить

Короткий путь описан в `MINIO_LOGSTASH_PROD_INSTRUCTION.md`.

Минимальный набор команд:

```bash
mkdir -p /tmp/logstash-minio-prod-package
unzip -o /path/to/logstash-minio-prod-package.zip -d /tmp/logstash-minio-prod-package

cd ~/devops/devops-repos/fluxcd

git apply --check /tmp/logstash-minio-prod-package/logstash-minio-prod.patch
git apply /tmp/logstash-minio-prod-package/logstash-minio-prod.patch

git diff --check -- infra/kub-sbl-mon/logstash/logstash-release-values.yaml

bash /path/to/bpmmq/tools/check-logstash-values.sh \
  --values-file ./infra/kub-sbl-mon/logstash/logstash-release-values.yaml \
  --logstash-image docker.elastic.co/logstash/logstash:8.19.0
```

## Настройка MinIO

На каждой MinIO-ноде в `/etc/default/minio`:

```bash
MINIO_AUDIT_WEBHOOK_ENABLE=on
MINIO_AUDIT_WEBHOOK_ENDPOINT=https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod
MINIO_AUDIT_WEBHOOK_QUEUE_DIR=/var/lib/minio/audit-webhook-queue
MINIO_AUDIT_WEBHOOK_QUEUE_SIZE=100000
```

Применить:

```bash
sudo install -o minio-user -g minio-user -m 0750 -d /var/lib/minio/audit-webhook-queue
sudo systemctl restart minio
sudo systemctl status minio --no-pager
```

Проверить:

```bash
sudo sh -c 'tr "\0" "\n" < /proc/$(pidof minio)/environ | grep MINIO_AUDIT_WEBHOOK'
```

## Проверка endpoint

```bash
curl -k -X POST 'https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod' \
  -H 'Content-Type: application/json' \
  -d '{"version":"1","deploymentid":"smoke","time":"2026-06-08T09:00:00Z","api":{"name":"PutObject","status":"OK","statusCode":200,"bucket":"audit-smoke","object":"smoke.txt"},"remotehost":"10.10.10.10","requestID":"smoke-1","accessKey":"minio-smoke"}'
```

Потом в Kibana проверить:

- событие есть в `app-minio-audit-prod*`;
- событие не попало в общий индекс `logstash`;
- поля `event_source`, `component`, `env`, `minio_api_name`,
  `minio_bucket`, `minio_object`, `minio_remotehost` заполнены.

## Если события не пришли

Проверить по порядку:

1. `kubectl -n logstash get pods` — Logstash pod живой.
2. `kubectl -n logstash logs statefulset/logstash-logstash --tail=200` — нет ошибок pipeline.
3. `kubectl -n logstash get svc logstash-logstash -o yaml` — есть порт `8081`.
4. `kubectl -n logstash get ingress logstash-logstash -o yaml` — есть paths `/minio-audit/prod` и `/minio-audit`.
5. `curl` до endpoint отвечает.
6. В Kibana смотреть `app-minio-audit-prod*`, а не `app-minio-audit-*` без prod и не `logstash`.
7. На MinIO-ноде проверить переменные `MINIO_AUDIT_WEBHOOK_*` и состояние `systemctl status minio`.

## Если понадобятся dev/ift/psi

Тогда менять нужно не текущий prod patch, а брать multi-env комплект:

```text
logstash-minio-multi-env.patch
elk/logstash-minio-audit.multi-env.conf
elk/logstash-release-values.multi-env.prepared.yaml
terraform/elasticstack/s3stor.multi-env.tf
fluxcd/elastic/elasticsearch-roles.s3stor-bpmmq.multi-env.snippet.yaml
fluxcd/elastic/oicdproxy-groups.s3stor-bpmmq.multi-env.snippet.yaml
```

Multi-env endpoint'ы:

```text
https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/dev
https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/ift
https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/psi
https://logstash.sbl-mon.kub.rdleas.ru/minio-audit/prod
```

Индексы:

```text
app-minio-audit-dev
app-minio-audit-ift
app-minio-audit-psi
app-minio-audit-prod
```

## Источники

- MinIO audit webhook: https://docs.min.io/aistor/operations/monitoring/audit-logging/webhook-audit-logging/
- MinIO webhook audit settings: https://docs.min.io/aistor/reference/aistor-server/settings/metrics-and-logging/webhook-audit-logs/
- Logstash HTTP input: https://www.elastic.co/guide/en/logstash/current/plugins-inputs-http.html
- Logstash Beats input: https://www.elastic.co/docs/reference/logstash/plugins/plugins-inputs-beats

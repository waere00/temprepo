# Docker Rootless на Ubuntu 24.04 с AD/SSSD

Инструкция для общей рабочей станции или RDS-сервера, где пользователи приходят из
Active Directory через SSSD/NSS.

Цель: пользователи из разрешённых AD-групп могут запускать локальный Docker
Rootless, но не получают `sudo`, не попадают в группу `docker` и не имеют
доступа к rootful Docker socket.

## Итоговая схема

- Rootful `docker.service` и `docker.socket` остановлены и отключены.
- `/var/run/docker.sock` отсутствует.
- `containerd.service` по умолчанию не трогаем.
- Каждый пользователь запускает собственный user-level Docker daemon.
- `/etc/subuid` и `/etc/subgid` выдаёт root-owned allocator.
- Allocator проверяет конкретного пользователя через NSS/SSSD, без enumeration
  состава AD-групп.
- Пользователь получает один range, если входит хотя бы в одну разрешённую
  группу.
- Уже выданные ranges не отзываются автоматически при удалении пользователя из
  AD-группы. Отзыв - отдельная административная процедура.

Запрещённые варианты:

- добавлять пользователей в группу `docker`;
- делать `chmod 666 /var/run/docker.sock`;
- включать unauthenticated TCP Docker socket;
- использовать общую учётку для Docker;
- включать `loginctl enable-linger` всем пользователям.

## Рекомендуемый путь

Для внедрения на группу хостов используйте Ansible:

```bash
cd docker-rootless-ad-subid/ansible
ansible-playbook -i inventory.yml playbooks/docker_rootless_ad_subid.yml --check
ansible-playbook -i inventory.yml playbooks/docker_rootless_ad_subid.yml
```

Переменные и первый запуск роли описаны в `ansible/README.md`.

Дальше в этом документе описан ручной сценарий, операционные проверки и rollback.

## 1. Предварительные проверки

Проверить, что NSS/SSSD видит пользователя и группы:

```bash
getent passwd '<AD-user>'
id '<AD-user>'
id -G '<AD-user>'
getent group 'DOMAIN\Docker Rootless Users'
getent group 'docker-rootless@example.com'
```

Проверить текущие UID/GID и SSSD/AD id mapping policy перед выбором subordinate
ID pool:

```bash
getent passwd | awk -F: '{print $1 ":" $3 ":" $4}' | sort -t: -k2,2n | tail -50
getent group  | awk -F: '{print $1 ":" $3}'     | sort -t: -k2,2n | tail -50
sudo grep -RniE 'id_provider|ldap_id_mapping|min_id|max_id|ldap_idmap_range|uidNumber|gidNumber' /etc/sssd/sssd.conf /etc/sssd/conf.d 2>/dev/null
```

Если NSS enumeration выключен, `getent passwd` не покажет весь AD. Это нормально.
Pool выбирайте по реальной SSSD/AD политике, а не только по локальному выводу.

Базовый pool, с которого удобно начинать:

```json
{
  "pool_start": 2000000000,
  "pool_count": 536870912,
  "block_size": 65536
}
```

Перед внедрением подтвердите, что диапазон не пересекается с локальными UID/GID,
SSSD ranges, POSIX UID/GID в AD и уже существующими `/etc/subuid` /
`/etc/subgid`.

## 2. Docker-пакеты

Ansible-роль предполагает, что официальный Docker apt repository уже настроен.
Для ручной установки проверьте, что пакеты берутся именно из Docker repository,
а не из Ubuntu `docker.io`.

Удалить конфликтующие пакеты без purge:

```bash
sudo apt remove -y \
  docker docker-engine docker.io \
  docker-compose docker-compose-v2 docker-doc podman-docker \
  containerd runc
```

Установить нужные пакеты:

```bash
sudo apt update
sudo apt install -y \
  docker-ce docker-ce-cli containerd.io \
  docker-ce-rootless-extras uidmap dbus-user-session \
  slirp4netns fuse-overlayfs \
  docker-buildx-plugin docker-compose-plugin
```

Важно:

- `apt remove`, не `apt purge`: `/var/lib/docker` не должен исчезнуть как
  побочный эффект;
- не запускать `apt autoremove --purge` без отдельной проверки;
- `uidmap` нужен для `newuidmap` и `newgidmap`;
- `docker-ce-rootless-extras` содержит `rootlesskit`,
  `dockerd-rootless-setuptool.sh` и AppArmor profile для rootlesskit;
- `slirp4netns` и `fuse-overlayfs` ставятся явно;
- AppArmor на Ubuntu 24.04 вручную ослаблять не нужно, если используется
  `docker-ce-rootless-extras` из deb-пакета Docker.

Проверка:

```bash
command -v dockerd-rootless-setuptool.sh rootlesskit newuidmap newgidmap slirp4netns fuse-overlayfs
test -f /etc/apparmor.d/rootlesskit && echo 'rootlesskit AppArmor profile: ok'
```

## 3. User namespace sysctls

Docker Rootless не стартует, если hardening выключил user namespaces. Типовой
симптом:

```text
[ERROR] Missing system requirements
```

Проверить:

```bash
sysctl kernel.unprivileged_userns_clone user.max_user_namespaces
```

Рабочий минимум для Ubuntu 24.04:

```bash
sudo tee /etc/sysctl.d/99-z-docker-rootless-userns.conf >/dev/null <<'EOF'
kernel.unprivileged_userns_clone = 1
user.max_user_namespaces = 28633
EOF
sudo sysctl -p /etc/sysctl.d/99-z-docker-rootless-userns.conf
```

Нюанс с `user.max_user_namespaces`:

- если текущее значение выше `28633`, снижать его не нужно;
- если hardening уже выставил `0`, прежний runtime default автоматически не
  восстановить;
- в таком случае задаём явный минимум и проверяем активное значение после
  `sysctl -w`;
- для крупного RDS-хоста можно выбрать значение выше `28633` как локальную
  политику окружения.

Если hardening-файл содержит активную строку `user.max_user_namespaces = 0`,
есть два варианта.

Первый, консервативный: оставить hardening-файл как есть и применить поздний
override `99-z-docker-rootless-userns.conf`. Тогда важно, чтобы hardening не
применялся после Docker Rootless настройки.

Второй, явный: закомментировать активную строку в hardening-файле и оставить
рядом причину. Ansible-роль делает это только при opt-in:

```yaml
docker_rootless_ad_subid_comment_userns_zero_sysctls: true
docker_rootless_ad_subid_userns_zero_sysctl_scan_paths:
  - /etc/sysctl.conf
  - /etc/sysctl.d
```

Пример результата:

```conf
# user.max_user_namespaces = 0
# docker_rootless_ad_subid: disabled because Docker Rootless requires user namespaces; active value is managed in /etc/sysctl.d/99-z-docker-rootless-userns.conf.
```

Комментирование строки не меняет runtime-значение само по себе. После этого всё
равно нужен `sysctl -w` или применение override-файла.

Решение не требует настройки iptables/nftables. Если
`dockerd-rootless-setuptool.sh check` жалуется именно на iptables, это отдельная
локальная проблема хоста.

## 4. Отключить rootful Docker

Если rootful Docker никому не нужен:

```bash
sudo systemctl disable --now docker.service docker.socket
sudo rm -f /var/run/docker.sock
```

`mask` по умолчанию не нужен. Он усложняет rollback и полезен только если
локальная политика требует жёстко запретить ручной старт rootful systemd units.

Проверить:

```bash
systemctl is-enabled docker.service docker.socket || true
systemctl is-active docker.service docker.socket || true
test ! -S /var/run/docker.sock && echo 'rootful docker socket absent'
```

`containerd.service` по умолчанию оставляем как есть. System-wide `containerd`
не нужен самому Docker Rootless, но может быть нужен другим потребителям.
Отключать его стоит только по отдельной локальной политике:

```bash
systemctl status containerd.service
sudo lsof -nP /run/containerd/containerd.sock 2>/dev/null || true
```

Не удалять автоматически:

- `containerd.io`;
- `docker-ce-cli`;
- `docker-ce-rootless-extras`;
- `/var/lib/docker`;
- `/var/lib/containerd`.

## 5. Установить allocator

Скрипт:

```bash
sudo install -o root -g root -m 0755 bin/docker-rootless-subid /usr/local/sbin/docker-rootless-subid
```

Конфиг:

```bash
sudo install -o root -g root -m 0755 -d /etc/docker-rootless-ad-subid
sudo install -o root -g root -m 0644 config/config.example.json /etc/docker-rootless-ad-subid/config.json
sudoedit /etc/docker-rootless-ad-subid/config.json
```

Пример:

```json
{
  "allowed_groups": [
    "DOMAIN\\Docker Rootless Users",
    "docker-rootless@example.com"
  ],
  "pool_start": 2000000000,
  "pool_count": 536870912,
  "block_size": 65536,
  "fail_login_on_allocator_error": false,
  "backup_dir": "/var/backups/docker-rootless-ad-subid"
}
```

Права:

```bash
sudo chown root:root /usr/local/sbin/docker-rootless-subid /etc/docker-rootless-ad-subid/config.json
sudo chmod 0755 /usr/local/sbin/docker-rootless-subid
sudo chmod 0644 /etc/docker-rootless-ad-subid/config.json
```

Проверка:

```bash
sudo /usr/local/sbin/docker-rootless-subid diagnose
sudo /usr/local/sbin/docker-rootless-subid status --user '<AD-user>'
sudo /usr/local/sbin/docker-rootless-subid dry-run --user '<AD-user>'
sudo /usr/local/sbin/docker-rootless-subid ensure --user '<AD-user>'
grep -E '^(<AD-user>|<canonical-login-name>):' /etc/subuid /etc/subgid
```

Allocator:

- пишет login name, а не numeric UID;
- проверяет membership через numeric GID;
- использует lock `/run/docker-rootless-ad-subid/lock`;
- делает backup перед изменением `/etc/subuid` и `/etc/subgid`;
- переписывает файлы атомарно;
- не создаёт дубли при повторном запуске;
- не выдаёт один range двум пользователям при параллельных запусках;
- не принимает рабочие системные пути из environment variables.

На время массовых ручных правок `/etc/subuid` или `/etc/subgid` остановите
rollout/PAM hook или работайте в maintenance window.

## 6. Подключить PAM hook

Сначала проверьте allocator вручную. Потом добавьте hook в session stack,
который реально используется при входе пользователей.

Обычно это `/etc/pam.d/common-session`:

```pam
session optional pam_exec.so seteuid quiet type=open_session /usr/local/sbin/docker-rootless-subid --config /etc/docker-rootless-ad-subid/config.json --subuid /etc/subuid --subgid /etc/subgid --lock-file /run/docker-rootless-ad-subid/lock ensure --from-pam
```

Для GUI/RDS может потребоваться другой PAM service или
`/etc/pam.d/common-session-noninteractive`. Не добавляйте строку вслепую во все
файлы; сначала подтвердите фактический login path.

Рекомендуемый режим - fail-open:

```json
"fail_login_on_allocator_error": false
```

При ошибке allocator-а вход не ломается, ошибка уходит в логи.

Fail-closed включать только после стендовой проверки. Нужны оба изменения:

```json
"fail_login_on_allocator_error": true
```

```pam
session required pam_exec.so seteuid quiet type=open_session /usr/local/sbin/docker-rootless-subid --config /etc/docker-rootless-ad-subid/config.json --subuid /etc/subuid --subgid /etc/subgid --lock-file /run/docker-rootless-ad-subid/lock ensure --from-pam
```

## 7. Что делает пользователь

После первого логина пользователь из разрешённой AD-группы получает записи в
`/etc/subuid` и `/etc/subgid`.

Разовая настройка:

```bash
sysctl kernel.unprivileged_userns_clone user.max_user_namespaces
grep "^$(id -un | sed 's/\\/\\\\/g'):" /etc/subuid /etc/subgid
dockerd-rootless-setuptool.sh check
dockerd-rootless-setuptool.sh install
docker context use rootless
```

Быстрая проверка:

```bash
docker info | grep -i rootless
docker info --format 'Docker Root Dir: {{.DockerRootDir}}'
docker run --rm hello-world
docker compose version
docker buildx version
```

Ожидаемый socket:

```text
unix:///run/user/<uid>/docker.sock
```

Проверить:

```bash
docker context inspect rootless
test -S "/run/user/$(id -u)/docker.sock"
test "$(stat -c '%u' "/run/user/$(id -u)/docker.sock")" = "$(id -u)"
```

Если `systemctl --user` не видит user bus, войдите обычным session способом:
SSH, GUI/RDS login или `machinectl shell`. `sudo su - user` часто не создаёт
корректный `XDG_RUNTIME_DIR` и user systemd bus.

## 8. Linger

По умолчанию linger не включать.

Без linger user-level Docker daemon привязан к пользовательской session. Это
нормально для интерактивной рабочей станции.

С linger user services могут жить после logout и стартовать после reboot. Это
подходит только пользователям, которым нужны долгоживущие контейнеры.

Включить точечно:

```bash
sudo loginctl enable-linger '<AD-user>'
loginctl show-user '<AD-user>' | grep -E 'Linger|RuntimePath'
```

Отключить:

```bash
sudo loginctl disable-linger '<AD-user>'
```

## 9. Проверки администратора

Пользователь и группы:

```bash
getent passwd '<AD-user>'
id '<AD-user>'
id -G '<AD-user>'
getent group 'DOMAIN\Docker Rootless Users'
sudo /usr/local/sbin/docker-rootless-subid status --user '<AD-user>'
```

Subordinate IDs:

```bash
grep -E '^(<AD-user>|<canonical-login-name>):' /etc/subuid /etc/subgid
sudo /usr/local/sbin/docker-rootless-subid dry-run --user '<AD-user>'
```

Rootful Docker отключён:

```bash
if systemctl is-active --quiet docker.service docker.socket; then
  echo 'ERROR: rootful Docker unit is active'
  exit 1
fi

if systemctl is-enabled --quiet docker.service docker.socket 2>/dev/null; then
  echo 'ERROR: rootful Docker unit is enabled'
  exit 1
fi

if [ -S /var/run/docker.sock ]; then
  echo 'ERROR: rootful Docker socket exists'
  exit 1
fi

echo 'ok: rootful Docker service/socket disabled and socket absent'
```

Пользователь не в группе `docker`:

```bash
docker_gid="$(getent group docker | awk -F: '{print $3}' || true)"
if [ -n "$docker_gid" ] && id -G '<AD-user>' | tr ' ' '\n' | grep -Fxq "$docker_gid"; then
  echo 'ERROR: user is in local docker group'
else
  echo 'ok: no local docker group membership'
fi
```

Storage:

```bash
sudo du -sh /home/*/.local/share/docker 2>/dev/null | sort -h
df -h /home /var 2>/dev/null
```

От имени конкретного пользователя:

```bash
docker system df
docker info --format 'Docker Root Dir: {{.DockerRootDir}}'
```

## 10. Smoke-тест

Unit-тесты allocator-а:

```bash
python3 -m unittest tests/test_docker_rootless_subid.py
```

Acceptance smoke запускать только от пользователя с уже настроенным Docker
Rootless:

```bash
tests/rootless_acceptance_smoke.sh
```

Скрипт ожидает rootless socket текущего пользователя, `docker info` с
`name=rootless`, Docker Root Dir не в `/var/lib/docker`, отсутствие
`/var/run/docker.sock` и отсутствие membership в локальной группе `docker`.

Для WSL/Docker Desktop lab есть bypass-переменные в самом скрипте. Не
используйте их как проверку рабочего окружения.

## 11. Rollback

Отключить PAM hook. Сначала backup:

```bash
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
sudo cp -a /etc/pam.d/common-session "/etc/pam.d/common-session.${stamp}.bak"
sudo sed -i '\#pam_exec.so .*docker-rootless-subid#d' /etc/pam.d/common-session
```

Если hook добавлялся в другой PAM-файл, повторить для него. Не удалять строки
без backup.

Откатить sysctl:

```bash
sudo rm -f /etc/sysctl.d/99-z-docker-rootless-userns.conf
sudo sysctl --system
```

Если включали opt-in комментирование hardening-файлов, восстановите нужный файл
из backup Ansible или вручную раскомментируйте строку после согласования с
владельцами hardening-а.

Вернуть rootful Docker, если это действительно нужно:

```bash
sudo systemctl enable --now docker.socket docker.service
```

Если отдельно отключали `containerd.service`:

```bash
sudo systemctl enable --now containerd.service
```

Откатить rootless setup у пользователя:

```bash
dockerd-rootless-setuptool.sh uninstall
systemctl --user disable --now docker
docker context use default
```

Откат `/etc/subuid` и `/etc/subgid` делать осторожно. Full-file restore из
backup может стереть ranges, выданные после этого backup. Сначала diff, затем
maintenance window и lock allocator-а:

```bash
sudo ls -lt /var/backups/docker-rootless-ad-subid
sudo diff -u /var/backups/docker-rootless-ad-subid/subuid.<timestamp>.<pid>.bak /etc/subuid || true
sudo diff -u /var/backups/docker-rootless-ad-subid/subgid.<timestamp>.<pid>.bak /etc/subgid || true
```

`~/.local/share/docker`, `/var/lib/docker` и `/var/lib/containerd` удалять
только после отдельного подтверждения владельцев данных.

## 12. Ограничения и риски

- Rootless Docker снижает риск root-эскалации через daemon, но не является
  полноценной песочницей.
- Пользователь всё ещё может расходовать CPU/RAM/disk в рамках своих прав и
  quotas.
- Rootless networking имеет ограничения; низкие порты `<1024` не должны быть
  дефолтной целью для RDS/workstation.
- NFS home directories часто плохо подходят для rootless Docker storage. Если
  home на NFS, задайте локальный `data-root` в `~/.config/docker/daemon.json`.
- Массовый linger превращает рабочую станцию в multi-tenant container host.
  Включайте его только точечно.
- `subid: sss` не выбран как рабочий путь без отдельного подтверждения на
  конкретной Ubuntu/SSSD/AD инфраструктуре.

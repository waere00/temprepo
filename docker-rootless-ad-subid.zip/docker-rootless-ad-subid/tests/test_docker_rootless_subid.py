import importlib.util
import importlib.machinery
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "bin" / "docker-rootless-subid"
ROLE_ALLOCATOR = ROOT / "ansible" / "roles" / "docker_rootless_ad_subid" / "files" / "docker-rootless-subid"
BLOCK = 65536
POOL_START = 2_000_000_000


def load_allocator_module():
    loader = importlib.machinery.SourceFileLoader("docker_rootless_subid", str(SCRIPT))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class RolePackagingTests(unittest.TestCase):
    def test_ansible_role_contains_allocator_file(self):
        self.assertEqual(SCRIPT.read_bytes(), ROLE_ALLOCATOR.read_bytes())


class RootlessSubidCliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.subuid = self.root / "subuid"
        self.subgid = self.root / "subgid"
        self.lock = self.root / "docker-rootless-subid.lock"
        self.backup = self.root / "backup"
        self.identity = self.root / "identity.json"
        self.config = self.root / "config.json"
        self.write_identity()
        self.write_config()

    def tearDown(self):
        self.tmp.cleanup()

    def write_config(self, **overrides):
        data = {
            "allowed_groups": ["DOMAIN\\Docker Rootless Users", "docker-rootless@example.com"],
            "pool_start": POOL_START,
            "pool_count": BLOCK * 32,
            "block_size": BLOCK,
            "fail_login_on_allocator_error": False,
            "backup_dir": str(self.backup),
        }
        data.update(overrides)
        self.config.write_text(json.dumps(data), encoding="utf-8")

    def write_identity(self, extra_users=None):
        users = {
            "alice": {"uid": 10001, "gid": 10001, "login_name": "alice", "groups": [10001, 2001]},
            "bob": {"uid": 10002, "gid": 10002, "login_name": "bob", "groups": [10002, 2002]},
            "carol": {"uid": 10003, "gid": 10003, "login_name": "carol", "groups": [10003, 2001, 2002]},
            "mallory": {"uid": 10004, "gid": 10004, "login_name": "mallory", "groups": [10004]},
            "existing": {"uid": 10005, "gid": 10005, "login_name": "existing", "groups": [10005, 2001]},
        }
        if extra_users:
            users.update(extra_users)
        data = {
            "groups": {
                "DOMAIN\\Docker Rootless Users": 2001,
                "docker-rootless@example.com": 2002,
            },
            "users": users,
        }
        self.identity.write_text(json.dumps(data), encoding="utf-8")

    def run_cli(self, *args, check=True, env=None):
        cmd = [
            sys.executable,
            str(SCRIPT),
            "--config",
            str(self.config),
            "--allow-insecure-config",
            "--subuid",
            str(self.subuid),
            "--subgid",
            str(self.subgid),
            "--lock-file",
            str(self.lock),
            "--identity-file",
            str(self.identity),
            *args,
        ]
        completed = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        if check and completed.returncode != 0:
            self.fail(f"command failed rc={completed.returncode}\nstdout={completed.stdout}\nstderr={completed.stderr}")
        return completed

    def lines(self, path):
        if not path.exists():
            return []
        return [line for line in path.read_text(encoding="utf-8").splitlines() if line]

    def test_allowed_users_from_either_group_get_unique_ranges(self):
        self.run_cli("ensure", "--user", "alice")
        self.run_cli("ensure", "--user", "bob")
        self.run_cli("ensure", "--user", "carol")

        self.assertEqual(
            self.lines(self.subuid),
            [
                f"alice:{POOL_START}:{BLOCK}",
                f"bob:{POOL_START + BLOCK}:{BLOCK}",
                f"carol:{POOL_START + 2 * BLOCK}:{BLOCK}",
            ],
        )
        self.assertEqual(self.lines(self.subuid), self.lines(self.subgid))

    def test_user_outside_allowed_groups_is_noop(self):
        result = self.run_cli("ensure", "--user", "mallory")

        self.assertIn("not-allowed", result.stdout)
        self.assertEqual(self.lines(self.subuid), [])
        self.assertEqual(self.lines(self.subgid), [])

    def test_missing_allowed_group_does_not_break_or_membership(self):
        self.write_config(allowed_groups=["missing@example.com", "docker-rootless@example.com"])

        result = self.run_cli("ensure", "--user", "bob")

        self.assertIn("changed", result.stdout)
        self.assertIn("allowed group resolution failed", result.stderr)
        self.assertEqual(self.lines(self.subuid), [f"bob:{POOL_START}:{BLOCK}"])
        self.assertEqual(self.lines(self.subgid), [f"bob:{POOL_START}:{BLOCK}"])

    def test_repeated_run_is_idempotent(self):
        self.run_cli("ensure", "--user", "alice")
        second = self.run_cli("ensure", "--user", "alice")

        self.assertIn("existing subordinate id range is usable", second.stdout)
        self.assertEqual(self.lines(self.subuid), [f"alice:{POOL_START}:{BLOCK}"])
        self.assertEqual(self.lines(self.subgid), [f"alice:{POOL_START}:{BLOCK}"])

    def test_existing_matching_range_is_kept(self):
        self.subuid.write_text(f"existing:{POOL_START + BLOCK}:{BLOCK}\n", encoding="utf-8")
        self.subgid.write_text(f"existing:{POOL_START + BLOCK}:{BLOCK}\n", encoding="utf-8")

        self.run_cli("ensure", "--user", "existing")

        self.assertEqual(self.lines(self.subuid), [f"existing:{POOL_START + BLOCK}:{BLOCK}"])
        self.assertEqual(self.lines(self.subgid), [f"existing:{POOL_START + BLOCK}:{BLOCK}"])

    def test_existing_matching_range_with_external_overlap_fails(self):
        self.subuid.write_text(
            f"alice:{POOL_START}:{BLOCK}\n"
            f"bob:{POOL_START}:{BLOCK}\n",
            encoding="utf-8",
        )
        self.subgid.write_text(
            f"alice:{POOL_START}:{BLOCK}\n"
            f"bob:{POOL_START}:{BLOCK}\n",
            encoding="utf-8",
        )

        result = self.run_cli("ensure", "--user", "alice", check=False)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("overlaps subuid owner 'bob'", result.stderr)

    def test_existing_single_sided_range_is_mirrored(self):
        self.subuid.write_text(f"alice:{POOL_START + BLOCK}:{BLOCK}\n", encoding="utf-8")

        self.run_cli("ensure", "--user", "alice")

        self.assertEqual(self.lines(self.subuid), [f"alice:{POOL_START + BLOCK}:{BLOCK}"])
        self.assertEqual(self.lines(self.subgid), [f"alice:{POOL_START + BLOCK}:{BLOCK}"])

    def test_existing_single_sided_range_with_same_file_overlap_fails(self):
        self.subuid.write_text(
            f"alice:{POOL_START}:{BLOCK}\n"
            f"other:{POOL_START}:{BLOCK}\n",
            encoding="utf-8",
        )

        result = self.run_cli("ensure", "--user", "alice", check=False)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("overlaps subuid owner 'other'", result.stderr)
        self.assertFalse(self.subgid.exists())

    def test_allocator_skips_overlapping_existing_ranges(self):
        self.subuid.write_text(f"other:{POOL_START}:{BLOCK}\n", encoding="utf-8")

        self.run_cli("ensure", "--user", "alice")

        self.assertEqual(self.lines(self.subuid), [f"other:{POOL_START}:{BLOCK}", f"alice:{POOL_START + BLOCK}:{BLOCK}"])
        self.assertEqual(self.lines(self.subgid), [f"alice:{POOL_START + BLOCK}:{BLOCK}"])

    def test_exhausted_pool_fails_without_writing(self):
        self.write_config(pool_count=BLOCK)
        self.subuid.write_text(f"other:{POOL_START}:{BLOCK}\n", encoding="utf-8")
        self.subgid.write_text(f"other:{POOL_START}:{BLOCK}\n", encoding="utf-8")

        result = self.run_cli("ensure", "--user", "alice", check=False)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("no free subordinate id block", result.stderr)
        self.assertEqual(self.lines(self.subuid), [f"other:{POOL_START}:{BLOCK}"])
        self.assertEqual(self.lines(self.subgid), [f"other:{POOL_START}:{BLOCK}"])

    def test_invalid_user_name_is_rejected(self):
        result = self.run_cli("ensure", "--user", "bad:name", check=False)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("character that breaks", result.stderr)

    def test_secure_subid_validation_rejects_relative_path(self):
        module = load_allocator_module()

        with self.assertRaisesRegex(module.SubidError, "absolute"):
            module.validate_secure_subid_path("subuid")

    def test_secure_subid_validation_rejects_untrusted_temp_parent(self):
        module = load_allocator_module()
        candidate = self.root / "subuid"
        candidate.write_text("", encoding="utf-8")

        with self.assertRaisesRegex(module.SubidError, "subid parent directory"):
            module.validate_secure_subid_path(str(candidate))

    def test_numeric_login_name_is_rejected(self):
        self.write_identity(
            extra_users={
                "numeric": {"uid": 12001, "gid": 12001, "login_name": "12345", "groups": [12001, 2001]},
            }
        )

        result = self.run_cli("ensure", "--user", "numeric", check=False)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("must not be all-numeric", result.stderr)

    def test_login_name_starting_with_comment_marker_is_rejected(self):
        self.write_identity(
            extra_users={
                "comment": {"uid": 12002, "gid": 12002, "login_name": "#comment", "groups": [12002, 2001]},
            }
        )

        result = self.run_cli("ensure", "--user", "comment", check=False)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("must not start with #", result.stderr)

    def test_dry_run_does_not_write(self):
        result = self.run_cli("dry-run", "--user", "alice")

        self.assertIn("would-change", result.stdout)
        self.assertEqual(self.lines(self.subuid), [])
        self.assertEqual(self.lines(self.subgid), [])

    def test_status_reports_membership_and_ranges(self):
        self.run_cli("ensure", "--user", "carol")

        result = self.run_cli("status", "--user", "carol")
        data = json.loads(result.stdout)

        self.assertTrue(data["allowed"])
        self.assertEqual(data["matching_group_gids"], [2001, 2002])
        self.assertEqual(data["subuid"][0]["owner"], "carol")
        self.assertEqual(data["subgid"][0]["owner"], "carol")

    def test_from_pam_uses_pam_user(self):
        env = dict(**__import__("os").environ, PAM_TYPE="open_session", PAM_USER="alice")

        self.run_cli("ensure", "--from-pam", env=env)

        self.assertEqual(self.lines(self.subuid), [f"alice:{POOL_START}:{BLOCK}"])
        self.assertEqual(self.lines(self.subgid), [f"alice:{POOL_START}:{BLOCK}"])

    def test_pam_mode_fail_open_returns_zero_on_allocator_error(self):
        self.write_config(allowed_groups=["missing@example.com"], fail_login_on_allocator_error=False)
        env = dict(**os.environ, PAM_TYPE="open_session", PAM_USER="alice")

        result = self.run_cli("ensure", "--from-pam", check=False, env=env)

        self.assertEqual(result.returncode, 0)
        self.assertIn("failed to resolve allowed groups", result.stderr)
        self.assertEqual(self.lines(self.subuid), [])
        self.assertEqual(self.lines(self.subgid), [])

    def test_pam_mode_fail_closed_returns_nonzero_on_allocator_error(self):
        self.write_config(allowed_groups=["missing@example.com"], fail_login_on_allocator_error=True)
        env = dict(**os.environ, PAM_TYPE="open_session", PAM_USER="alice")

        result = self.run_cli("ensure", "--from-pam", check=False, env=env)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("failed to resolve allowed groups", result.stderr)
        self.assertEqual(self.lines(self.subuid), [])
        self.assertEqual(self.lines(self.subgid), [])

    def test_environment_cannot_select_identity_file(self):
        env = dict(
            **__import__("os").environ,
            DOCKER_ROOTLESS_SUBID_IDENTITY_FILE=str(self.identity),
            DOCKER_ROOTLESS_SUBID_SUBUID=str(self.subuid),
            DOCKER_ROOTLESS_SUBID_SUBGID=str(self.subgid),
        )
        cmd = [
            sys.executable,
            str(SCRIPT),
            "--config",
            str(self.config),
            "--allow-insecure-config",
            "--subuid",
            str(self.subuid),
            "--subgid",
            str(self.subgid),
            "--lock-file",
            str(self.lock),
            "dry-run",
            "--user",
            "alice",
        ]

        completed = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn("getent passwd alice", completed.stderr)
        self.assertEqual(self.lines(self.subuid), [])
        self.assertEqual(self.lines(self.subgid), [])

    def test_diagnose_returns_nonzero_for_unresolved_group(self):
        self.write_config(allowed_groups=["missing@example.com"])

        result = self.run_cli("diagnose", check=False)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("error group='missing@example.com'", result.stdout)

    def test_parallel_different_users_get_unique_ranges(self):
        users = {
            f"user{i}": {"uid": 11000 + i, "gid": 11000 + i, "login_name": f"user{i}", "groups": [11000 + i, 2001]}
            for i in range(20)
        }
        self.write_identity(extra_users=users)
        processes = [self._popen("ensure", "--user", f"user{i}") for i in range(20)]
        results = [proc.communicate(timeout=30) + (proc.returncode,) for proc in processes]

        for stdout, stderr, rc in results:
            self.assertEqual(rc, 0, f"stdout={stdout}\nstderr={stderr}")
        uid_lines = self.lines(self.subuid)
        gid_lines = self.lines(self.subgid)
        self.assertEqual(len(uid_lines), 20)
        self.assertEqual(uid_lines, gid_lines)
        starts = sorted(int(line.split(":")[1]) for line in uid_lines)
        self.assertEqual(starts, [POOL_START + i * BLOCK for i in range(20)])

    def test_parallel_same_user_creates_single_range(self):
        processes = [self._popen("ensure", "--user", "alice") for _ in range(20)]
        results = [proc.communicate(timeout=30) + (proc.returncode,) for proc in processes]

        for stdout, stderr, rc in results:
            self.assertEqual(rc, 0, f"stdout={stdout}\nstderr={stderr}")
        self.assertEqual(self.lines(self.subuid), [f"alice:{POOL_START}:{BLOCK}"])
        self.assertEqual(self.lines(self.subgid), [f"alice:{POOL_START}:{BLOCK}"])

    def _popen(self, *args):
        cmd = [
            sys.executable,
            str(SCRIPT),
            "--config",
            str(self.config),
            "--allow-insecure-config",
            "--subuid",
            str(self.subuid),
            "--subgid",
            str(self.subgid),
            "--lock-file",
            str(self.lock),
            "--identity-file",
            str(self.identity),
            *args,
        ]
        return subprocess.Popen(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


if __name__ == "__main__":
    unittest.main()

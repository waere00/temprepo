#!/usr/bin/env bash
set -euo pipefail

TMPDIRS=()
IMAGES=()
COMPOSE_PROJECTS=()
CREATED_NEGATIVE_DIR=""

cleanup() {
  local pair project file image dir
  for pair in "${COMPOSE_PROJECTS[@]}"; do
    project="${pair%%:*}"
    file="${pair#*:}"
    docker compose -p "${project}" -f "${file}" down --volumes --remove-orphans >/dev/null 2>&1 || true
  done
  for image in "${IMAGES[@]}"; do
    docker image rm -f "${image}" >/dev/null 2>&1 || true
  done
  for dir in "${TMPDIRS[@]}"; do
    rm -rf "${dir}" >/dev/null 2>&1 || true
  done
  if [ -n "${CREATED_NEGATIVE_DIR}" ]; then
    sudo rmdir "${CREATED_NEGATIVE_DIR}" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

new_tmpdir() {
  local dir
  dir="$(mktemp -d /tmp/rootless-docker-smoke.XXXXXX)"
  TMPDIRS+=("${dir}")
  echo "${dir}"
}

normalize_docker_host() {
  local host="$1"
  case "${host}" in
    unix://*)
      printf 'unix://%s\n' "$(readlink -m "${host#unix://}")"
      ;;
    *)
      printf '%s\n' "${host}"
      ;;
  esac
}

require_non_root_user() {
  if [ "$(id -u)" -eq 0 ]; then
    echo "ERROR: rootless acceptance smoke must be run as the target non-root user" >&2
    return 1
  fi
}

require_expected_docker_endpoint() {
  if [ "${ALLOW_DOCKER_ENDPOINT_OVERRIDE:-0}" = "1" ]; then
    echo "WARN: Docker endpoint check is disabled by ALLOW_DOCKER_ENDPOINT_OVERRIDE=1"
    return 0
  fi

  local uid runtime_dir expected_host socket_path context_host context
  uid="$(id -u)"
  runtime_dir="${XDG_RUNTIME_DIR:-/run/user/${uid}}"
  runtime_dir="${runtime_dir%/}"
  socket_path="${runtime_dir}/docker.sock"
  expected_host="$(normalize_docker_host "unix://${socket_path}")"

  if [ -n "${DOCKER_HOST:-}" ] && [ "$(normalize_docker_host "${DOCKER_HOST}")" != "${expected_host}" ]; then
    echo "ERROR: DOCKER_HOST points to ${DOCKER_HOST}, expected ${expected_host}" >&2
    return 1
  fi

  if [ -z "${DOCKER_HOST:-}" ]; then
    context="$(docker context show 2>/dev/null || true)"
    context_host="$(docker context inspect "${context}" --format '{{.Endpoints.docker.Host}}' 2>/dev/null || true)"
    if [ "$(normalize_docker_host "${context_host}")" != "${expected_host}" ]; then
      echo "ERROR: Docker context ${context:-<unknown>} points to ${context_host:-<empty>}, expected ${expected_host}" >&2
      return 1
    fi
  fi

  if [ ! -S "${socket_path}" ]; then
    echo "ERROR: expected rootless Docker socket is absent: ${socket_path}" >&2
    return 1
  fi
  if [ "$(stat -c '%u' "${socket_path}")" != "${uid}" ]; then
    echo "ERROR: rootless Docker socket is not owned by current uid ${uid}: ${socket_path}" >&2
    return 1
  fi
}

require_rootless_security_option() {
  local security_options
  security_options="$(docker info --format '{{range .SecurityOptions}}{{println .}}{{end}}')"
  echo "SecurityOptions=${security_options}"
  if ! printf '%s\n' "${security_options}" | grep -Fxq "name=rootless"; then
    echo "ERROR: Docker daemon is not rootless; refusing acceptance smoke" >&2
    return 1
  fi
}

require_rootless_storage() {
  local root_dir uid
  uid="$(id -u)"
  root_dir="$(docker info --format '{{.DockerRootDir}}')"
  echo "DockerRootDir=${root_dir}"
  case "${root_dir}" in
    /var/lib/docker|/var/lib/docker/*)
      echo "ERROR: Docker Root Dir points to rootful storage: ${root_dir}" >&2
      return 1
      ;;
  esac
  if [ ! -d "${root_dir}" ]; then
    echo "ERROR: Docker Root Dir is not a directory: ${root_dir}" >&2
    return 1
  fi
  if [ "$(stat -c '%u' "${root_dir}")" != "${uid}" ]; then
    echo "ERROR: Docker Root Dir is not owned by current uid ${uid}: ${root_dir}" >&2
    return 1
  fi
}

require_no_rootful_socket() {
  if [ "${ALLOW_ROOTFUL_SOCKET_PRESENT:-0}" = "1" ]; then
    echo "WARN: /var/run/docker.sock presence check is disabled by ALLOW_ROOTFUL_SOCKET_PRESENT=1"
    return 0
  fi
  if [ -S /var/run/docker.sock ]; then
    echo "ERROR: /var/run/docker.sock exists; rootful Docker socket should be absent in production" >&2
    return 1
  fi
}

require_not_in_docker_group() {
  if [ "${ALLOW_DOCKER_GROUP_MEMBERSHIP:-0}" = "1" ]; then
    echo "WARN: docker group membership check is disabled by ALLOW_DOCKER_GROUP_MEMBERSHIP=1"
    return 0
  fi
  local docker_gid
  docker_gid="$(getent group docker | awk -F: '{print $3}' || true)"
  if [ -n "${docker_gid}" ] && id -G | tr ' ' '\n' | grep -Fxq "${docker_gid}"; then
    echo "ERROR: current user is a member of local docker group gid=${docker_gid}" >&2
    return 1
  fi
}

smoke_compose() {
  local tmpdir project image
  tmpdir="$(new_tmpdir)"
  project="rootless-smoke-$$"
  image="rootless-compose-smoke:$$"
  IMAGES+=("${image}")
  COMPOSE_PROJECTS+=("${project}:${tmpdir}/compose.yaml")
  cat > "${tmpdir}/Dockerfile" <<'EOF'
FROM alpine:3.20
RUN echo rootless-compose-ok > /marker
CMD ["cat", "/marker"]
EOF
  cat > "${tmpdir}/compose.yaml" <<'EOF'
services:
  hello:
    build: .
    image: rootless-compose-smoke:PID_PLACEHOLDER
EOF
  sed -i "s/PID_PLACEHOLDER/$$/g" "${tmpdir}/compose.yaml"
  docker compose -p "${project}" -f "${tmpdir}/compose.yaml" up --build --abort-on-container-exit --exit-code-from hello
  docker compose -p "${project}" -f "${tmpdir}/compose.yaml" down --volumes --remove-orphans
}

smoke_buildx() {
  local tmpdir image
  tmpdir="$(new_tmpdir)"
  image="rootless-buildx-smoke:$$"
  IMAGES+=("${image}")
  cat > "${tmpdir}/Dockerfile" <<'EOF'
FROM alpine:3.20
RUN echo rootless-build-ok > /marker
CMD ["cat", "/marker"]
EOF
  docker buildx inspect --bootstrap
  docker buildx build --load -t "${image}" "${tmpdir}"
  docker run --rm "${image}" | grep -Fx rootless-build-ok
}

prepare_negative_dir() {
  local target
  if [ -n "${ROOTLESS_ACCEPTANCE_NEGATIVE_DIR:-}" ]; then
    target="${ROOTLESS_ACCEPTANCE_NEGATIVE_DIR}"
  elif sudo -n true >/dev/null 2>&1; then
    target="$(sudo mktemp -d /var/tmp/docker-rootless-negative.XXXXXX)"
    sudo chown root:root "${target}"
    sudo chmod 0755 "${target}"
    CREATED_NEGATIVE_DIR="${target}"
  else
    echo "SKIP: no ROOTLESS_ACCEPTANCE_NEGATIVE_DIR and passwordless sudo is unavailable; skipping bind-mount write negative test" >&2
    return 0
  fi

  if [ ! -d "${target}" ]; then
    echo "ERROR: negative test target is not a directory: ${target}" >&2
    return 1
  fi
  if [ "$(stat -c '%u' "${target}")" != "0" ]; then
    echo "ERROR: negative test target must be root-owned: ${target}" >&2
    return 1
  fi
  if [ -w "${target}" ]; then
    echo "ERROR: current host user can write to negative test target before Docker test: ${target}" >&2
    return 1
  fi
  printf '%s\n' "${target}"
}

smoke_negative_bind_mount() {
  local target marker
  target="$(prepare_negative_dir)"
  if [ -z "${target}" ]; then
    return 0
  fi
  marker="${target}/rootless-write-test.$$"
  set +e
  docker run --rm -v "${target}:/host" alpine:3.20 sh -c "id; touch '/host/$(basename "${marker}")'"
  local rc=$?
  set -e
  if [ "${rc}" -eq 0 ] || [ -e "${marker}" ]; then
    echo "ERROR: container wrote to protected host test directory through bind mount" >&2
    echo "Investigate daemon context before removing ${marker}" >&2
    return 1
  fi
  echo "HOST_PROTECTED_DIR_WRITE=blocked"
}

main() {
  require_non_root_user
  echo "context=$(docker context show 2>/dev/null || true)"
  echo "DOCKER_HOST=${DOCKER_HOST:-}"
  require_expected_docker_endpoint
  require_rootless_security_option
  require_no_rootful_socket
  require_not_in_docker_group
  require_rootless_storage
  docker info --format 'ServerVersion={{.ServerVersion}}'
  docker run --rm hello-world
  docker compose version
  docker buildx version
  smoke_compose
  smoke_buildx
  smoke_negative_bind_mount
}

main "$@"

# Docker Rootless для Ubuntu 24.04 + AD/SSSD

Набор для общей рабочей станции или RDS-сервера, где пользователи приходят из
Active Directory через SSSD/NSS, а доступ к Docker должен быть без `sudo`, без
группы `docker` и без rootful Docker socket.

Итоговая схема:

- rootful `docker.service` и `docker.socket` остановлены и отключены;
- `/var/run/docker.sock` не используется пользователями;
- каждый пользователь запускает свой Docker Rootless daemon;
- `/etc/subuid` и `/etc/subgid` выдаются автоматически только пользователям из
  разрешённых AD-групп;
- доступ проверяется через уже настроенный NSS/SSSD, без enumeration состава
  групп.

## Что здесь лежит

- `ansible/` - основная точка внедрения: одна роль и один playbook.
- `bin/docker-rootless-subid` - allocator для `/etc/subuid` и `/etc/subgid`.
- `config/config.example.json` - пример конфига allocator-а.
- `pam/docker-rootless-subid.pam` - пример PAM `open_session` hook.
- `docs/runbook.md` - ручная установка, проверки, rollback и ограничения.
- `tests/test_docker_rootless_subid.py` - unit/concurrency тесты allocator-а.
- `tests/rootless_acceptance_smoke.sh` - ручной smoke-тест уже настроенного
  rootless Docker.

## Быстрый старт через Ansible

Docker apt repository на целевых Ubuntu-хостах должен быть уже подключён.

Задайте AD-группы в inventory, `group_vars`, `host_vars` или через
`--extra-vars`. В самой роли группы намеренно не хардкодятся.

Пример `group_vars/docker_rootless_hosts.yml`:

```yaml
docker_rootless_ad_subid_allowed_groups:
  - 'DOMAIN\Docker Rootless Users'
  - 'docker-rootless@example.com'
```

Проверочный прогон:

```bash
cd docker-rootless-ad-subid/ansible
ansible-playbook -i inventory.yml playbooks/docker_rootless_ad_subid.yml --check
```

Применение:

```bash
ansible-playbook -i inventory.yml playbooks/docker_rootless_ad_subid.yml
```

Подробности по переменным и поведению роли: `ansible/README.md`.

## Ручной сценарий

Если Ansible не используется, последовательность описана в `docs/runbook.md`.
Минимальные шаги:

1. Установить Docker Rootless пакеты.
2. Отключить rootful Docker service/socket и убрать `/var/run/docker.sock`.
3. Настроить user namespace sysctls.
4. Установить `/usr/local/sbin/docker-rootless-subid`.
5. Заполнить `/etc/docker-rootless-ad-subid/config.json`.
6. Проверить allocator вручную.
7. Подключить PAM hook.
8. Пользователь один раз запускает `dockerd-rootless-setuptool.sh install`.

## Локальные тесты

Unit-тесты не трогают системные `/etc/subuid`, `/etc/subgid`, PAM или systemd:

```bash
python3 -m unittest tests/test_docker_rootless_subid.py
```

Smoke-тест запускать только от пользователя, у которого уже настроен Docker
Rootless:

```bash
tests/rootless_acceptance_smoke.sh
```

## Важные ограничения

- Не добавлять пользователей в группу `docker`.
- Не открывать `/var/run/docker.sock` через права `666`.
- Не включать unauthenticated TCP Docker socket.
- Не использовать общую учётку для Docker.
- Не включать `loginctl enable-linger` массово.
- Не удалять `/var/lib/docker` или пользовательский `~/.local/share/docker`
  без отдельного подтверждения владельцев данных.

# Ansible: Docker Rootless AD/SSSD

Один playbook применяет одну самодостаточную роль:

```text
playbooks/docker_rootless_ad_subid.yml
roles/docker_rootless_ad_subid/
```

Роль не читает файлы из соседних `bin/`, `tests/` или других директорий
проекта. Всё, что ставится на хост, лежит внутри самой роли: `files/`,
`templates/`, `tasks/`, `defaults/`.

## Что делает роль

По умолчанию роль:

- проверяет, что задан список разрешённых AD-групп;
- устанавливает пакеты Docker из официального Docker apt repository;
- удаляет конфликтующие пакеты Docker из Ubuntu, включая `docker.io`, через
  `state=absent` без `purge`;
- сохраняет `/var/lib/docker` и `/var/lib/containerd`, если они уже были;
- не даёт установочным скриптам пакетов кратковременно запустить rootful Docker при
  установке пакетов;
- останавливает и отключает `docker.service` и `docker.socket`;
- не делает `mask`;
- удаляет оставшийся `/var/run/docker.sock`;
- оставляет `containerd.service` как есть;
- настраивает sysctl, нужные для user namespaces;
- ставит allocator `/usr/local/sbin/docker-rootless-subid`;
- пишет `/etc/docker-rootless-ad-subid/config.json`;
- подключает PAM `open_session` hook;
- запускает `docker-rootless-subid diagnose`.

Роль не выдаёт `/etc/subuid` и `/etc/subgid` всем пользователям при установке.
Диапазон появляется при следующем логине пользователя через PAM hook или вручную:

```bash
sudo /usr/local/sbin/docker-rootless-subid ensure --user '<AD-user>'
```

## Перед запуском

На целевых Ubuntu-хостах уже должен работать официальный Docker apt repository.
Роль не настраивает repository и ключи.

Проверьте, что SSSD/NSS видит пользователей и группы:

```bash
getent passwd '<AD-user>'
id '<AD-user>'
getent group 'DOMAIN\Docker Rootless Users'
```

Проверьте, что выбранный pool subordinate IDs не пересекается с локальными
UID/GID и SSSD/AD id mapping ranges. Дефолт роли:

```yaml
docker_rootless_ad_subid_pool_start: 2000000000
docker_rootless_ad_subid_pool_count: 536870912
docker_rootless_ad_subid_block_size: 65536
```

## Где задавать AD-группы

В роли нет дефолтных групп:

```yaml
docker_rootless_ad_subid_allowed_groups: []
```

Это сделано специально: роль падает, если список не задан. Передавайте группы в
inventory, `group_vars`, `host_vars` или через `--extra-vars`.

Пример inventory:

```yaml
docker_rootless_hosts:
  hosts:
    rds01.example.com:
    rds02.example.com:
```

Пример `group_vars/docker_rootless_hosts.yml`:

```yaml
docker_rootless_ad_subid_allowed_groups:
  - 'DOMAIN\Docker Rootless Users'
  - 'docker-rootless@example.com'
```

Разовый запуск через `--extra-vars`:

```bash
ansible-playbook \
  -i inventory.yml \
  playbooks/docker_rootless_ad_subid.yml \
  -e '{"docker_rootless_ad_subid_allowed_groups":["DOMAIN\\Docker Rootless Users","docker-rootless@example.com"]}'
```

Для повторяемого запуска в рабочем окружении лучше использовать `group_vars`, чтобы
playbook оставался одинаковым для всех окружений.

## Первый запуск

Проверочный прогон:

```bash
cd docker-rootless-ad-subid/ansible
ansible-playbook -i inventory.yml playbooks/docker_rootless_ad_subid.yml --check
```

Применение:

```bash
ansible-playbook -i inventory.yml playbooks/docker_rootless_ad_subid.yml
```

После успешного прогона пользователь из разрешённой AD-группы должен перелогиниться.
PAM hook выдаст ему subordinate ID range, после чего пользователь один раз
настраивает Docker Rootless:

```bash
sysctl kernel.unprivileged_userns_clone user.max_user_namespaces
grep "^$(id -un | sed 's/\\/\\\\/g'):" /etc/subuid /etc/subgid
dockerd-rootless-setuptool.sh check
dockerd-rootless-setuptool.sh install
docker context use rootless
docker run --rm hello-world
```

## User namespace sysctls

Docker Rootless не стартует, если hardening выключил user namespaces. Роль
управляет только этими sysctl:

```text
kernel.unprivileged_userns_clone = 1
user.max_user_namespaces >= docker_rootless_ad_subid_user_max_user_namespaces_min
```

Дефолтный override-файл:

```yaml
docker_rootless_ad_subid_sysctl_file: /etc/sysctl.d/99-z-docker-rootless-userns.conf
docker_rootless_ad_subid_user_max_user_namespaces_min: 28633
```

Если текущее `user.max_user_namespaces` выше минимума, роль его не снижает.
Если hardening уже выставил `0`, прежний runtime default восстановить нельзя;
роль применяет заданный floor и проверяет активное значение после `sysctl -w`.

По умолчанию роль не редактирует чужие hardening-файлы. Если нужно убрать
активные строки `user.max_user_namespaces=0` из sysctl-файлов, включите явный
режим:

```yaml
docker_rootless_ad_subid_comment_userns_zero_sysctls: true
docker_rootless_ad_subid_userns_zero_sysctl_scan_paths:
  - /etc/sysctl.conf
  - /etc/sysctl.d
```

Роль найдёт активные присваивания `user.max_user_namespaces = 0`, сделает backup,
закомментирует их и рядом оставит причину. Этот режим не привязан к имени
hardening-файла.

Роль не устанавливает и не настраивает iptables/nftables.

## Основные переменные

```yaml
# Обязательно
docker_rootless_ad_subid_allowed_groups: []

# Subordinate ID pool
docker_rootless_ad_subid_pool_start: 2000000000
docker_rootless_ad_subid_pool_count: 536870912
docker_rootless_ad_subid_block_size: 65536

# Rootful Docker
docker_rootless_ad_subid_manage_rootful_docker: true
docker_rootless_ad_subid_mask_rootful_docker: false
docker_rootless_ad_subid_remove_rootful_socket: true

# containerd.service
docker_rootless_ad_subid_containerd_policy: leave

# PAM
docker_rootless_ad_subid_manage_pam: true
docker_rootless_ad_subid_pam_session_files:
  - /etc/pam.d/common-session
docker_rootless_ad_subid_pam_control: optional
docker_rootless_ad_subid_fail_login_on_allocator_error: false
```

`docker_rootless_ad_subid_containerd_policy` принимает `leave` или
`stopped_disabled`. Дефолт `leave`: не отключать `containerd.service` без
отдельной локальной политики.

Для настоящего fail-closed PAM нужны обе настройки:

```yaml
docker_rootless_ad_subid_pam_control: required
docker_rootless_ad_subid_fail_login_on_allocator_error: true
```

Включать это стоит только после стендовой проверки, иначе ошибка allocator-а
может блокировать вход.

## Что роль не делает

- Не добавляет пользователей в группу `docker`.
- Не даёт пользователям `sudo`.
- Не включает TCP Docker socket.
- Не удаляет `/var/lib/docker`.
- Не включает `loginctl enable-linger`.
- Не ставит smoke/test scripts на целевой хост.
- Не создаёт отдельный standalone PAM service file.
- Не отзывает уже выданные ranges при удалении пользователя из AD-группы.

## Rollback роли

Отключить PAM hook:

```bash
ansible-playbook \
  -i inventory.yml \
  playbooks/docker_rootless_ad_subid.yml \
  -e docker_rootless_ad_subid_pam_state=absent
```

Вернуть rootful Docker, если это действительно нужно:

```bash
sudo systemctl enable --now docker.socket docker.service
```

Пользовательский rootless daemon откатывается от имени пользователя:

```bash
dockerd-rootless-setuptool.sh uninstall
systemctl --user disable --now docker
docker context use default
```

`/etc/subuid`, `/etc/subgid`, `/var/lib/docker` и `~/.local/share/docker`
удалять или откатывать только после отдельной сверки данных.
